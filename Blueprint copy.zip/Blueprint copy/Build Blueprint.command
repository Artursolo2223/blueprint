#!/bin/zsh
# Double-click in Finder: rebuilds Blueprint.app from the source and opens it.
cd "$(dirname "$0")"
pkill -x Blueprint 2>/dev/null
./build.sh && open ../Blueprint.app
