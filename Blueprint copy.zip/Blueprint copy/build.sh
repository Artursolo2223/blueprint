#!/bin/zsh
# Builds "Blueprint.app" (a Visual Paradigm style UML and diagram tool) next to this folder.
set -e
cd "$(dirname "$0")"
mkdir -p build

swiftc -O -target arm64-apple-macos14.0 -swift-version 5 Sources/*.swift -o build/Blueprint

if [ ! -f build/AppIcon.icns ]; then
    swift Helper/make_icon.swift build/icon.png
    mkdir -p build/AppIcon.iconset
    for s in 16 32 128 256 512; do
        sips -z $s $s build/icon.png --out build/AppIcon.iconset/icon_${s}x${s}.png >/dev/null
        sips -z $((s*2)) $((s*2)) build/icon.png --out build/AppIcon.iconset/icon_${s}x${s}@2x.png >/dev/null
    done
    iconutil -c icns build/AppIcon.iconset -o build/AppIcon.icns
fi

APP="../Blueprint.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp build/Blueprint "$APP/Contents/MacOS/"
cp build/AppIcon.icns "$APP/Contents/Resources/"
cat > "$APP/Contents/Info.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Blueprint</string>
<key>CFBundleDisplayName</key><string>Blueprint</string>
<key>CFBundleIdentifier</key><string>com.artur.blueprint</string>
<key>CFBundleExecutable</key><string>Blueprint</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>1.0</string>
<key>CFBundleVersion</key><string>1</string>
<key>LSMinimumSystemVersion</key><string>14.0</string>
<key>NSHighResolutionCapable</key><true/>
<key>NSPrincipalClass</key><string>NSApplication</string>
<key>NSHumanReadableCopyright</key><string>UML, ER, BPMN and more – with Java code engineering</string>
<key>CFBundleDocumentTypes</key>
<array><dict>
  <key>CFBundleTypeName</key><string>Blueprint Project</string>
  <key>CFBundleTypeRole</key><string>Editor</string>
  <key>LSHandlerRank</key><string>Owner</string>
  <key>CFBundleTypeIconFile</key><string>AppIcon</string>
  <key>LSItemContentTypes</key><array><string>com.artur.blueprint.project</string></array>
</dict></array>
<key>UTExportedTypeDeclarations</key>
<array><dict>
  <key>UTTypeIdentifier</key><string>com.artur.blueprint.project</string>
  <key>UTTypeDescription</key><string>Blueprint Project</string>
  <key>UTTypeConformsTo</key><array><string>public.json</string></array>
  <key>UTTypeTagSpecification</key><dict><key>public.filename-extension</key><array><string>blueprint</string></array></dict>
</dict></array>
</dict></plist>
PL
codesign --force --sign - -r='designated => identifier "com.artur.blueprint"' "$APP"
echo "Built $APP"
