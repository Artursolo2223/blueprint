// Draws the 1024px app icon in the TypeLearn colours: swift make_icon.swift out.png
import AppKit

let size: CGFloat = 1024
let img = NSImage(size: NSSize(width: size, height: size), flipped: false) { r in
    let rect = r.insetBy(dx: 100, dy: 100)
    let shape = NSBezierPath(roundedRect: rect, xRadius: 185, yRadius: 185)
    NSGraphicsContext.current?.saveGraphicsState()
    let shadow = NSShadow()
    shadow.shadowColor = NSColor.black.withAlphaComponent(0.35)
    shadow.shadowBlurRadius = 28
    shadow.shadowOffset = NSSize(width: 0, height: -12)
    shadow.set()
    NSColor(calibratedRed: 0.09, green: 0.10, blue: 0.13, alpha: 1).setFill()
    shape.fill()
    NSGraphicsContext.current?.restoreGraphicsState()

    // blue glow top-left, orange glow bottom-right
    shape.addClip()
    NSGradient(colors: [NSColor.systemBlue.withAlphaComponent(0.75), NSColor.systemBlue.withAlphaComponent(0)])!
        .draw(fromCenter: NSPoint(x: rect.minX, y: rect.maxY), radius: 0, toCenter: NSPoint(x: rect.minX, y: rect.maxY), radius: 620, options: [])
    NSGradient(colors: [NSColor.systemOrange.withAlphaComponent(0.7), NSColor.systemOrange.withAlphaComponent(0)])!
        .draw(fromCenter: NSPoint(x: rect.maxX, y: rect.minY), radius: 0, toCenter: NSPoint(x: rect.maxX, y: rect.minY), radius: 640, options: [])

    // a small class diagram: a superclass and two subclasses joined by an inheritance arrow
    func classBox(_ b: NSRect, alpha: CGFloat) {
        let p = NSBezierPath(roundedRect: b, xRadius: 26, yRadius: 26)
        NSColor.white.withAlphaComponent(alpha).setFill()
        p.fill()
        NSColor(calibratedRed: 0.09, green: 0.10, blue: 0.13, alpha: 0.55).setStroke()
        for f in [0.62, 0.36] {
            let l = NSBezierPath()
            let y = b.minY + b.height * f
            l.move(to: NSPoint(x: b.minX, y: y)); l.line(to: NSPoint(x: b.maxX, y: y))
            l.lineWidth = 9
            l.stroke()
        }
    }
    let top = NSRect(x: 362, y: 560, width: 300, height: 210)
    let left = NSRect(x: 190, y: 220, width: 270, height: 190)
    let right = NSRect(x: 564, y: 220, width: 270, height: 190)
    let line = NSBezierPath()
    line.lineWidth = 16
    line.lineCapStyle = .round
    line.move(to: NSPoint(x: left.midX, y: left.maxY)); line.line(to: NSPoint(x: left.midX, y: 480))
    line.line(to: NSPoint(x: right.midX, y: 480)); line.line(to: NSPoint(x: right.midX, y: right.maxY))
    line.move(to: NSPoint(x: top.midX, y: 480)); line.line(to: NSPoint(x: top.midX, y: top.minY - 40))
    NSColor.white.withAlphaComponent(0.85).setStroke()
    line.stroke()
    let tri = NSBezierPath()
    tri.move(to: NSPoint(x: top.midX, y: top.minY)); tri.line(to: NSPoint(x: top.midX - 38, y: top.minY - 56)); tri.line(to: NSPoint(x: top.midX + 38, y: top.minY - 56)); tri.close()
    NSColor(calibratedRed: 0.09, green: 0.10, blue: 0.13, alpha: 1).setFill()
    tri.fill()
    tri.lineWidth = 12
    tri.stroke()
    classBox(top, alpha: 0.97)
    classBox(left, alpha: 0.78)
    classBox(right, alpha: 0.78)
    return true
}

let rep = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: Int(size), pixelsHigh: Int(size), bitsPerSample: 8,
                           samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB,
                           bytesPerRow: 0, bitsPerPixel: 0)!
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
img.draw(in: NSRect(x: 0, y: 0, width: size, height: size))
NSGraphicsContext.restoreGraphicsState()
try! rep.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
