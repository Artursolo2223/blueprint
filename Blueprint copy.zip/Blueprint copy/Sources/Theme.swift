import SwiftUI
import AppKit

// The TypeLearn look: dark window, blue glow top-left, orange glow bottom-right, rounded glass cards, capsule buttons.

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 255) / 255,
                  green: Double((hex >> 8) & 255) / 255,
                  blue: Double(hex & 255) / 255,
                  opacity: opacity)
    }
}

/// system colours so the app follows light and dark mode
enum T {
    static let bg = Color(nsColor: .windowBackgroundColor)
    static let card = Color(nsColor: .controlBackgroundColor)
    static let ink = Color.primary
    static let muted = Color.secondary
    static let line = Color(nsColor: .separatorColor)
    static let track = Color.primary.opacity(0.08)
    static let accent = Color.accentColor
    static let orange = Color(nsColor: .systemOrange)
    static let red = Color(nsColor: .systemRed)
    static let yellow = Color(nsColor: .systemYellow)
    static let green = Color(nsColor: .systemGreen)
    static let blue = Color(nsColor: .systemBlue)
}

/// stand-in for @State (the @State macro needs Xcode's plugins, which a command line build does not have)
final class Box<V>: ObservableObject {
    @Published var v: V
    init(_ v: V) { self.v = v }
}

private struct ReduceGlassKey: EnvironmentKey { static let defaultValue = false }
extension EnvironmentValues {
    var reduceGlass: Bool {
        get { self[ReduceGlassKey.self] }
        set { self[ReduceGlassKey.self] = newValue }
    }
}

struct CardBackground: ViewModifier {
    var pad: CGFloat
    var solid: Bool
    @Environment(\.reduceGlass) private var reduce

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 16, style: .continuous)
        if #available(macOS 26.0, *), !solid, !reduce {
            content.padding(pad).glassEffect(.regular, in: shape)
        } else {
            content.padding(pad)
                .background(T.card, in: shape)
                .overlay(shape.stroke(T.line, lineWidth: 0.5))
        }
    }
}

extension View {
    /// Liquid Glass on macOS 26 and later, a plain card before that
    func card(_ pad: CGFloat = 16, solid: Bool = false) -> some View { modifier(CardBackground(pad: pad, solid: solid)) }
}

struct LiquidGlass<S: Shape>: ViewModifier {
    var shape: S
    var tint: Color?
    @Environment(\.reduceGlass) private var reduce

    func body(content: Content) -> some View {
        if #available(macOS 26.0, *), !reduce {
            if let tint { content.glassEffect(.regular.tint(tint), in: shape) }
            else { content.glassEffect(.regular, in: shape) }
        } else {
            content.background(tint ?? T.card, in: shape)
        }
    }
}

extension View {
    func liquidGlass<S: Shape>(_ shape: S, tint: Color? = nil) -> some View { modifier(LiquidGlass(shape: shape, tint: tint)) }
}

/// soft colour behind the glass so it has something to refract
struct AppBackground: View {
    var body: some View {
        ZStack {
            T.bg
            RadialGradient(colors: [T.accent.opacity(0.22), .clear], center: .topLeading, startRadius: 0, endRadius: 520)
            RadialGradient(colors: [T.orange.opacity(0.18), .clear], center: .bottomTrailing, startRadius: 0, endRadius: 560)
        }
        .ignoresSafeArea()
    }
}

// MARK: - buttons

struct PillStyle: ButtonStyle {
    var prominent = false
    func makeBody(configuration: Configuration) -> some View {
        PillBody(label: configuration.label, pressed: configuration.isPressed, prominent: prominent)
    }

    private struct PillBody<L: View>: View {
        let label: L
        let pressed: Bool
        let prominent: Bool
        @Environment(\.isEnabled) private var enabled
        var body: some View {
            label
                .font(.system(size: 12, weight: .medium))
                .lineLimit(1)
                .padding(.horizontal, 12)
                .frame(height: 26)
                .foregroundStyle(prominent ? Color.white : T.ink)
                .background(prominent ? AnyShapeStyle(T.accent) : AnyShapeStyle(Color.primary.opacity(pressed ? 0.15 : 0.075)), in: Capsule())
                .opacity(enabled ? (pressed ? 0.8 : 1) : 0.4)
                .contentShape(Capsule())
        }
    }
}

/// round glass button in the top bar
struct TopButton: View {
    let icon: String
    var text: String? = nil
    var help: String
    var on = false
    let action: () -> Void
    @Environment(\.isEnabled) private var enabled

    var body: some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 12, weight: .medium))
                if let text { Text(text).font(.system(size: 12, weight: .medium)) }
            }
            .padding(.horizontal, text == nil ? 0 : 11)
            .frame(minWidth: 30, minHeight: 28)
            .foregroundStyle(on ? T.accent : T.ink)
            .opacity(enabled ? 1 : 0.35)
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .liquidGlass(Capsule(), tint: on ? T.accent.opacity(0.18) : nil)
        .help(help)
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text.uppercased())
            .font(.system(size: 10, weight: .semibold))
            .tracking(0.6)
            .foregroundStyle(T.muted)
    }
}

// MARK: - text fields that commit when you press Return or leave them (one undo step per edit)

struct CommitField: NSViewRepresentable {
    var text: String
    var placeholder = ""
    var mono = false
    var onCommit: (String) -> Void

    func makeNSView(context: Context) -> NSTextField {
        let f = NSTextField(string: text)
        f.placeholderString = placeholder
        f.font = mono ? .monospacedSystemFont(ofSize: 11.5, weight: .regular) : .systemFont(ofSize: 12.5)
        f.bezelStyle = .roundedBezel
        f.isBezeled = true
        f.lineBreakMode = .byTruncatingTail
        f.usesSingleLineMode = true
        f.cell?.isScrollable = true
        f.cell?.wraps = false
        f.delegate = context.coordinator
        f.setContentHuggingPriority(.defaultLow, for: .horizontal)
        f.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        return f
    }

    func updateNSView(_ f: NSTextField, context: Context) {
        if context.coordinator.parent.text != text { context.coordinator.committed = nil }
        context.coordinator.parent = self
        f.placeholderString = placeholder
        if f.currentEditor() == nil && f.stringValue != text { f.stringValue = text }
    }

    func makeCoordinator() -> Coord { Coord(self) }

    final class Coord: NSObject, NSTextFieldDelegate {
        var parent: CommitField
        var committed: String?
        init(_ p: CommitField) { parent = p }

        func commit(_ f: NSTextField) {
            let v = f.stringValue
            guard v != parent.text, v != committed else { return }
            committed = v
            parent.onCommit(v)
        }
        func controlTextDidEndEditing(_ n: Notification) {
            if let f = n.object as? NSTextField { commit(f) }
        }
        func control(_ c: NSControl, textView: NSTextView, doCommandBy sel: Selector) -> Bool {
            guard let f = c as? NSTextField else { return false }
            if sel == #selector(NSResponder.insertNewline(_:)) {
                commit(f)
                return true
            }
            if sel == #selector(NSResponder.cancelOperation(_:)) {
                f.stringValue = parent.text
                f.window?.makeFirstResponder(nil)
                return true
            }
            return false
        }
    }
}

/// several lines of text, saved when you leave the field
struct CommitTextView: NSViewRepresentable {
    var text: String
    var onCommit: (String) -> Void

    func makeNSView(context: Context) -> NSScrollView {
        let sv = NSTextView.scrollableTextView()
        sv.borderType = .noBorder
        sv.drawsBackground = false
        let tv = sv.documentView as! NSTextView
        tv.string = text
        tv.font = .systemFont(ofSize: 12)
        tv.isRichText = false
        tv.drawsBackground = false
        tv.textContainerInset = NSSize(width: 4, height: 5)
        tv.isAutomaticQuoteSubstitutionEnabled = false
        tv.isAutomaticDashSubstitutionEnabled = false
        tv.allowsUndo = true
        tv.delegate = context.coordinator
        return sv
    }

    func updateNSView(_ sv: NSScrollView, context: Context) {
        context.coordinator.parent = self
        guard let tv = sv.documentView as? NSTextView else { return }
        if tv.window?.firstResponder !== tv && tv.string != text { tv.string = text }
    }

    func makeCoordinator() -> Coord { Coord(self) }

    final class Coord: NSObject, NSTextViewDelegate {
        var parent: CommitTextView
        init(_ p: CommitTextView) { parent = p }
        func textDidEndEditing(_ n: Notification) {
            guard let tv = n.object as? NSTextView, tv.string != parent.text else { return }
            parent.onCommit(tv.string)
        }
    }
}

/// plain-text code editor for pasting Java or SQL
struct CodeEditor: NSViewRepresentable {
    @Binding var text: String

    func makeNSView(context: Context) -> NSScrollView {
        let sv = NSTextView.scrollableTextView()
        sv.borderType = .noBorder
        let tv = sv.documentView as! NSTextView
        tv.string = text
        tv.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        tv.isRichText = false
        tv.isAutomaticQuoteSubstitutionEnabled = false
        tv.isAutomaticDashSubstitutionEnabled = false
        tv.isAutomaticTextReplacementEnabled = false
        tv.isAutomaticSpellingCorrectionEnabled = false
        tv.isContinuousSpellCheckingEnabled = false
        tv.allowsUndo = true
        tv.textContainerInset = NSSize(width: 8, height: 8)
        tv.delegate = context.coordinator
        return sv
    }

    func updateNSView(_ sv: NSScrollView, context: Context) {
        context.coordinator.parent = self
        guard let tv = sv.documentView as? NSTextView else { return }
        if tv.string != text { tv.string = text }
    }

    func makeCoordinator() -> Coord { Coord(self) }

    final class Coord: NSObject, NSTextViewDelegate {
        var parent: CodeEditor
        init(_ p: CodeEditor) { parent = p }
        func textDidChange(_ n: Notification) {
            if let tv = n.object as? NSTextView { parent.text = tv.string }
        }
    }
}

/// read-only, syntax coloured code
struct CodeView: View {
    let code: String
    let lang: CodeLang
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        ScrollView([.vertical, .horizontal]) {
            Text(Highlight.attributed(code, lang, dark: scheme == .dark))
                .font(.system(size: 11.5, design: .monospaced))
                .textSelection(.enabled)
                .fixedSize(horizontal: true, vertical: true)
                .padding(12)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .background(scheme == .dark ? Color(hex: 0x15171B) : Color(hex: 0xFBFBFC), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(T.line, lineWidth: 0.5))
    }
}

extension Color {
    init?(hexString: String?) {
        guard let h = hexString else { return nil }
        self.init(nsColor: NSColor(hex: h))
    }
    var hexString: String { NSColor(self).hex }
}
