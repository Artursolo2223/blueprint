import AppKit

// MARK: - fonts and text

struct F: Hashable {
    var size: CGFloat = 12
    var bold = false
    var italic = false
    var mono = false

    private static var cache: [F: NSFont] = [:]
    var ns: NSFont {
        if let f = F.cache[self] { return f }
        var f = mono ? NSFont.monospacedSystemFont(ofSize: size, weight: bold ? .semibold : .regular)
                     : NSFont.systemFont(ofSize: size, weight: bold ? .semibold : .regular)
        if italic { f = NSFontManager.shared.convert(f, toHaveTrait: .italicFontMask) }
        F.cache[self] = f
        return f
    }
    var lineHeight: CGFloat { ceil(ns.ascender - ns.descender + ns.leading) }
}

enum TextM {
    static func width(_ s: String, _ f: F) -> CGFloat {
        ceil((s as NSString).size(withAttributes: [.font: f.ns]).width)
    }

    /// word wrap to a width; long words are split
    static func wrap(_ s: String, _ f: F, _ w: CGFloat) -> [String] {
        var out: [String] = []
        for para in s.components(separatedBy: "\n") {
            var line = ""
            for word in para.split(separator: " ", omittingEmptySubsequences: false).map(String.init) {
                let cand = line.isEmpty ? word : line + " " + word
                if width(cand, f) <= w || line.isEmpty && width(word, f) <= w {
                    line = cand
                } else if line.isEmpty {
                    var chunk = ""
                    for ch in word {
                        if width(chunk + String(ch), f) > w && !chunk.isEmpty { out.append(chunk); chunk = "" }
                        chunk.append(ch)
                    }
                    line = chunk
                } else {
                    out.append(line)
                    if width(word, f) <= w { line = word } else {
                        var chunk = ""
                        for ch in word {
                            if width(chunk + String(ch), f) > w && !chunk.isEmpty { out.append(chunk); chunk = "" }
                            chunk.append(ch)
                        }
                        line = chunk
                    }
                }
            }
            out.append(line)
        }
        return out
    }
}

// MARK: - painters: one draws with Core Graphics, the other writes SVG

protocol Painter: AnyObject {
    func fill(_ path: CGPath, _ c: NSColor)
    func stroke(_ path: CGPath, _ c: NSColor, _ w: CGFloat, dash: [CGFloat])
    /// p is the top-left of the line; angle in degrees (rotates around p)
    func text(_ s: String, _ p: CGPoint, _ f: F, _ c: NSColor, angle: CGFloat)
}

extension Painter {
    func stroke(_ path: CGPath, _ c: NSColor, _ w: CGFloat) { stroke(path, c, w, dash: []) }
    func text(_ s: String, _ p: CGPoint, _ f: F, _ c: NSColor) { text(s, p, f, c, angle: 0) }
}

final class CGPainter: Painter {
    let ctx: CGContext
    init(_ ctx: CGContext) { self.ctx = ctx }

    func fill(_ path: CGPath, _ c: NSColor) {
        ctx.addPath(path)
        ctx.setFillColor(c.cgColor)
        ctx.fillPath()
    }

    func stroke(_ path: CGPath, _ c: NSColor, _ w: CGFloat, dash: [CGFloat]) {
        ctx.addPath(path)
        ctx.setStrokeColor(c.cgColor)
        ctx.setLineWidth(w)
        ctx.setLineJoin(.round)
        ctx.setLineCap(dash.isEmpty ? .round : .butt)
        ctx.setLineDash(phase: 0, lengths: dash)
        ctx.strokePath()
        ctx.setLineDash(phase: 0, lengths: [])
    }

    func text(_ s: String, _ p: CGPoint, _ f: F, _ c: NSColor, angle: CGFloat) {
        guard !s.isEmpty else { return }
        let a = NSAttributedString(string: s, attributes: [.font: f.ns, .foregroundColor: c])
        if angle == 0 {
            a.draw(at: p)
        } else {
            ctx.saveGState()
            ctx.translateBy(x: p.x, y: p.y)
            ctx.rotate(by: angle * .pi / 180)
            a.draw(at: .zero)
            ctx.restoreGState()
        }
    }
}

final class SVGPainter: Painter {
    var out = ""

    private func col(_ c: NSColor) -> String {
        let s = c.usingColorSpace(.sRGB) ?? c
        return String(format: "rgb(%d,%d,%d)", Int(round(s.redComponent * 255)), Int(round(s.greenComponent * 255)), Int(round(s.blueComponent * 255)))
    }
    private func alpha(_ c: NSColor) -> CGFloat { (c.usingColorSpace(.sRGB) ?? c).alphaComponent }

    private func d(_ path: CGPath) -> String {
        var s = ""
        func f(_ v: CGFloat) -> String { String(format: "%.1f", v) }
        path.applyWithBlock { e in
            let p = e.pointee.points
            switch e.pointee.type {
            case .moveToPoint: s += "M\(f(p[0].x)) \(f(p[0].y))"
            case .addLineToPoint: s += "L\(f(p[0].x)) \(f(p[0].y))"
            case .addQuadCurveToPoint: s += "Q\(f(p[0].x)) \(f(p[0].y)) \(f(p[1].x)) \(f(p[1].y))"
            case .addCurveToPoint: s += "C\(f(p[0].x)) \(f(p[0].y)) \(f(p[1].x)) \(f(p[1].y)) \(f(p[2].x)) \(f(p[2].y))"
            case .closeSubpath: s += "Z"
            @unknown default: break
            }
        }
        return s
    }

    func fill(_ path: CGPath, _ c: NSColor) {
        let a = alpha(c)
        guard a > 0 else { return }
        out += "<path d=\"\(d(path))\" fill=\"\(col(c))\"\(a < 1 ? " fill-opacity=\"\(String(format: "%.2f", a))\"" : "")/>\n"
    }

    func stroke(_ path: CGPath, _ c: NSColor, _ w: CGFloat, dash: [CGFloat]) {
        let dashAttr = dash.isEmpty ? "" : " stroke-dasharray=\"\(dash.map { String(format: "%.0f", $0) }.joined(separator: ","))\""
        let a = alpha(c)
        out += "<path d=\"\(d(path))\" fill=\"none\" stroke=\"\(col(c))\" stroke-width=\"\(String(format: "%.1f", w))\" stroke-linejoin=\"round\"\(dashAttr)\(a < 1 ? " stroke-opacity=\"\(String(format: "%.2f", a))\"" : "")/>\n"
    }

    func text(_ s: String, _ p: CGPoint, _ f: F, _ c: NSColor, angle: CGFloat) {
        guard !s.isEmpty else { return }
        let base = f.ns.ascender
        let family = f.mono ? "SF Mono, Menlo, monospace" : "-apple-system, Helvetica Neue, Helvetica, Arial, sans-serif"
        let tr = angle == 0 ? "" : " transform=\"rotate(\(String(format: "%.0f", angle)) \(String(format: "%.1f", p.x)) \(String(format: "%.1f", p.y)))\""
        out += "<text x=\"\(String(format: "%.1f", p.x))\" y=\"\(String(format: "%.1f", p.y + base))\" font-family=\"\(family)\" font-size=\"\(String(format: "%.1f", f.size))\"\(f.bold ? " font-weight=\"600\"" : "")\(f.italic ? " font-style=\"italic\"" : "") fill=\"\(col(c))\"\(tr) xml:space=\"preserve\">\(s.xmlEscaped)</text>\n"
    }
}

// MARK: - colours of the drawing surface

struct Palette {
    let dark: Bool
    let paper: NSColor
    let grid: NSColor
    let gridMajor: NSColor
    let ink: NSColor
    let muted: NSColor
    let accent: NSColor

    static let light = Palette(dark: false, paper: NSColor(rgb: 0xFCFCFD), grid: NSColor(rgb: 0xEEF0F4), gridMajor: NSColor(rgb: 0xE2E5EB),
                               ink: NSColor(rgb: 0x1F2329), muted: NSColor(rgb: 0x6B7280), accent: NSColor(rgb: 0x2F7BF6))
    static let dark = Palette(dark: true, paper: NSColor(rgb: 0x1B1D22), grid: NSColor(rgb: 0x24272D), gridMajor: NSColor(rgb: 0x2C3037),
                              ink: NSColor(rgb: 0xE6E8EC), muted: NSColor(rgb: 0x9AA1AC), accent: NSColor(rgb: 0x4C8DFF))

    struct Look { let fill: NSColor; let stroke: NSColor; let text: NSColor; let header: NSColor }

    func look(_ fam: Family) -> Look {
        func l(_ f: UInt32, _ s: UInt32, _ h: UInt32, _ df: UInt32, _ ds: UInt32, _ dh: UInt32) -> Look {
            dark ? Look(fill: NSColor(rgb: df), stroke: NSColor(rgb: ds), text: ink, header: NSColor(rgb: dh))
                 : Look(fill: NSColor(rgb: f), stroke: NSColor(rgb: s), text: ink, header: NSColor(rgb: h))
        }
        switch fam {
        case .structure: return l(0xEDF3FE, 0x4F7FD6, 0xD9E6FC, 0x1D2740, 0x7AA5F5, 0x25345A)
        case .behavior: return l(0xFFF5E1, 0xD48B2C, 0xFCE6BC, 0x362C1B, 0xEFAE55, 0x4A3A1E)
        case .note: return l(0xFFF8C7, 0xC4AE4E, 0xFFF1A6, 0x37331D, 0xA69A55, 0x433D20)
        case .container: return dark ? Look(fill: NSColor(white: 1, alpha: 0.035), stroke: NSColor(rgb: 0x7E8898), text: ink, header: NSColor(white: 1, alpha: 0.07))
                                   : Look(fill: NSColor(rgb: 0xF3F5F8, alpha: 0.7), stroke: NSColor(rgb: 0x8791A3), text: ink, header: NSColor(rgb: 0xE6EAF0))
        case .control: return Look(fill: ink, stroke: ink, text: ink, header: ink)
        case .flow: return l(0xE6F7F0, 0x2F9C76, 0xCDEFE2, 0x16322A, 0x4EC79D, 0x1D4437)
        case .data: return l(0xF3EDFE, 0x7C57D6, 0xE3D7FC, 0x271F3D, 0xA98AF5, 0x352953)
        case .event: return l(0xFFFFFF, 0x2F9C58, 0xFFFFFF, 0x1B1D22, 0x4ECB7D, 0x1B1D22)
        case .gateway: return l(0xFFF8E3, 0xCF9B18, 0xFFF0C2, 0x352E17, 0xE9B941, 0x453A18)
        case .component: return l(0xE8F5F9, 0x3A8EA7, 0xD2ECF3, 0x173039, 0x61B8D1, 0x1E3F4B)
        case .mind: return l(0xEDF3FE, 0x4F7FD6, 0xD9E6FC, 0x1D2740, 0x7AA5F5, 0x25345A)
        case .actor, .plain: return l(0xFFFFFF, 0x5C6470, 0xF1F3F6, 0x23262C, 0x9AA1AC, 0x2C3037)
        case .text: return Look(fill: .clear, stroke: muted, text: ink, header: .clear)
        }
    }

    static let mindColors: [UInt32] = [0x2F7BF6, 0xE0703B, 0x2F9C76, 0x9C5BD9, 0xD4A017, 0xD94C7F, 0x3A9FB8]
}

// MARK: - class box layout (also used by the canvas to find the row under the mouse)

struct ClassLayout {
    var stereo: String
    var name: String
    var headerH: CGFloat
    var rowH: CGFloat
    var attrTop: CGFloat
    var attrH: CGFloat
    var opTop: CGFloat
    var opH: CGFloat
    var showOps: Bool
    var size: CGSize

    static let pad: CGFloat = 6

    static func of(_ n: Node) -> ClassLayout {
        let fs = CGFloat(n.fontSize ?? 12)
        let nameF = F(size: fs + 0.5, bold: true, italic: n.isAbstract)
        let memF = F(size: fs - 0.5)
        let stF = F(size: fs - 1.5)
        var stereo = ""
        switch n.kind {
        case .interface: stereo = "«interface»"
        case .enumeration: stereo = "«enumeration»"
        default: stereo = n.stereotype.isEmpty ? "" : "«\(n.stereotype)»"
        }
        var name = n.name
        if n.kind == .object {
            let c = n.prop("classifier")
            name = c.isEmpty ? n.name : "\(n.name) : \(c)"
        }
        let rowH = ceil(memF.lineHeight + 3)
        var headerH = pad * 2 + nameF.lineHeight
        if !stereo.isEmpty { headerH += stF.lineHeight }
        let attrH = n.attrs.isEmpty ? 10 : CGFloat(n.attrs.count) * rowH + 8
        let showOps = n.kind != .object
        let opH = showOps ? (n.ops.isEmpty ? 10 : CGFloat(n.ops.count) * rowH + 8) : 0
        var w = max(TextM.width(name, nameF) + 28, stereo.isEmpty ? 0 : TextM.width(stereo, stF) + 24)
        for m in n.attrs { w = max(w, TextM.width(UMLText.attrLine(m, kind: n.kind), memF) + 22) }
        for m in n.ops { w = max(w, TextM.width(UMLText.opLine(m), memF) + 22) }
        w = max(w, 110)
        let h = headerH + attrH + opH
        return ClassLayout(stereo: stereo, name: name, headerH: headerH, rowH: rowH, attrTop: headerH, attrH: attrH,
                           opTop: headerH + attrH, opH: opH, showOps: showOps, size: CGSize(width: ceil(w), height: ceil(h)))
    }

    /// which member row a point (relative to the node) is on: (isOperation, index)
    func row(at y: CGFloat, attrs: Int, ops: Int) -> (Bool, Int)? {
        if y >= attrTop && y < attrTop + attrH {
            let i = Int((y - attrTop - 4) / rowH)
            return i >= 0 && i < attrs ? (false, i) : nil
        }
        if showOps && y >= opTop && y < opTop + opH {
            let i = Int((y - opTop - 4) / rowH)
            return i >= 0 && i < ops ? (true, i) : nil
        }
        return nil
    }
}

struct EntityLayout {
    var headerH: CGFloat
    var rowH: CGFloat
    var keyW: CGFloat
    var nameW: CGFloat
    var size: CGSize

    static func of(_ n: Node) -> EntityLayout {
        let fs = CGFloat(n.fontSize ?? 12)
        let f = F(size: fs - 0.5), fb = F(size: fs - 0.5, bold: true)
        let headerH = ceil(F(size: fs + 0.5, bold: true).lineHeight + 12)
        let rowH = ceil(f.lineHeight + 5)
        let keyW: CGFloat = 30
        var nameW: CGFloat = 40, typeW: CGFloat = 20
        for m in n.attrs {
            nameW = max(nameW, TextM.width(m.name, m.pk ? fb : f))
            typeW = max(typeW, TextM.width(m.type, f))
        }
        let w = max(keyW + nameW + 18 + typeW + 10, TextM.width(n.name, F(size: fs + 0.5, bold: true)) + 30, 140)
        let h = headerH + CGFloat(max(1, n.attrs.count)) * rowH + 6
        return EntityLayout(headerH: headerH, rowH: rowH, keyW: keyW, nameW: nameW, size: CGSize(width: ceil(w), height: ceil(h)))
    }

    func row(at y: CGFloat, count: Int) -> Int? {
        let i = Int((y - headerH - 3) / rowH)
        return y > headerH && i >= 0 && i < count ? i : nil
    }
}

// MARK: - the renderer

struct Renderer {
    let d: Diagram
    let pal: Palette
    let p: Painter
    let nodes: [UUID: Node]
    var mindColor: [UUID: Int] = [:]
    var messageNo: [UUID: Int] = [:]
    var spread: [UUID: CGFloat] = [:]

    init(_ d: Diagram, _ pal: Palette, _ p: Painter) {
        self.d = d
        self.pal = pal
        self.p = p
        var map: [UUID: Node] = [:]
        for n in d.nodes { map[n.id] = n }
        nodes = map
        if d.type == .mindMap { mindColor = Renderer.branchColors(d) }
        spread = Renderer.spreads(d)
        if d.type == .sequence {
            var i = 1
            for e in d.edges.filter({ $0.kind.isMessage }).sorted(by: { ($0.y ?? 0) < ($1.y ?? 0) }) {
                messageNo[e.id] = i
                i += 1
            }
        }
    }

    /// mind map: every first-level branch gets its own colour, inherited by its children
    static func branchColors(_ d: Diagram) -> [UUID: Int] {
        var out: [UUID: Int] = [:]
        var adj: [UUID: [UUID]] = [:]
        for e in d.edges where e.kind == .branch {
            adj[e.from, default: []].append(e.to)
            adj[e.to, default: []].append(e.from)
        }
        let roots = d.nodes.filter { $0.kind == .central }
        var seen = Set(roots.map(\.id))
        for r in roots {
            var i = 0
            for c in adj[r.id] ?? [] where !seen.contains(c) {
                var stack = [c]
                seen.insert(c)
                while let x = stack.popLast() {
                    out[x] = i
                    for y in adj[x] ?? [] where !seen.contains(y) { seen.insert(y); stack.append(y) }
                }
                i += 1
            }
        }
        return out
    }

    /// connectors that share both ends get different offsets: -0.5, 0.5 or -1, 0, 1 …
    static func spreads(_ d: Diagram) -> [UUID: CGFloat] {
        var groups: [String: [UUID]] = [:]
        for e in d.edges where !(d.type == .sequence && e.kind.isMessage) && e.points.isEmpty {
            let key = e.from.uuidString < e.to.uuidString ? "\(e.from)\(e.to)" : "\(e.to)\(e.from)"
            groups[key, default: []].append(e.id)
        }
        var out: [UUID: CGFloat] = [:]
        for ids in groups.values where ids.count > 1 {
            for (i, id) in ids.enumerated() { out[id] = CGFloat(i) - CGFloat(ids.count - 1) / 2 }
        }
        return out
    }

    func route(_ e: Edge) -> Route? { Geo.route(e, nodes, sequence: d.type == .sequence, spread: spread[e.id] ?? 0) }

    func drawAll(skip: Set<UUID> = []) {
        for n in d.nodes where !skip.contains(n.id) { drawNode(n) }
        if d.type == .sequence { drawActivations() }
        for e in d.edges where !skip.contains(e.id) { drawEdge(e) }
    }

    // MARK: colours per node

    func look(_ n: Node) -> Palette.Look {
        var lk = pal.look(n.kind.info.family)
        if n.kind == .topic, let i = mindColor[n.id] {
            let c = NSColor(rgb: Palette.mindColors[i % Palette.mindColors.count])
            lk = Palette.Look(fill: c.withAlphaComponent(pal.dark ? 0.22 : 0.12), stroke: c, text: pal.ink, header: c)
        }
        if n.kind == .central {
            lk = Palette.Look(fill: pal.accent, stroke: pal.accent, text: .white, header: pal.accent)
        }
        if n.kind == .startEvent { lk = Palette.Look(fill: pal.paper, stroke: NSColor(rgb: pal.dark ? 0x4ECB7D : 0x2F9C58), text: pal.ink, header: lk.header) }
        if n.kind == .interEvent { lk = Palette.Look(fill: pal.paper, stroke: NSColor(rgb: pal.dark ? 0xEFAE55 : 0xD48B2C), text: pal.ink, header: lk.header) }
        if n.kind == .endEvent { lk = Palette.Look(fill: pal.paper, stroke: NSColor(rgb: pal.dark ? 0xF26D6D : 0xD64545), text: pal.ink, header: lk.header) }
        var fill = lk.fill, stroke = lk.stroke, text = lk.text, header = lk.header
        if let h = n.fill {
            fill = NSColor(hex: h)
            header = fill.blended(withFraction: 0.12, of: .black) ?? fill
            text = fill.luminance > 0.55 ? NSColor(rgb: 0x1F2329) : .white
        }
        if let h = n.stroke { stroke = NSColor(hex: h) }
        if let h = n.textColor { text = NSColor(hex: h) }
        return Palette.Look(fill: fill, stroke: stroke, text: text, header: header)
    }

    // MARK: shape helpers

    static func rrect(_ r: CGRect, _ rad: CGFloat) -> CGPath {
        let k = max(0, min(rad, r.width / 2 - 0.01, r.height / 2 - 0.01))
        return k <= 0 ? CGPath(rect: r, transform: nil) : CGPath(roundedRect: r, cornerWidth: k, cornerHeight: k, transform: nil)
    }
    static func poly(_ pts: [CGPoint], close: Bool = true) -> CGPath {
        let p = CGMutablePath()
        p.addLines(between: pts)
        if close { p.closeSubpath() }
        return p
    }
    static func line(_ a: CGPoint, _ b: CGPoint) -> CGPath { poly([a, b], close: false) }
    static func diamond(_ r: CGRect) -> CGPath {
        poly([CGPoint(x: r.midX, y: r.minY), CGPoint(x: r.maxX, y: r.midY), CGPoint(x: r.midX, y: r.maxY), CGPoint(x: r.minX, y: r.midY)])
    }

    func dash(_ s: LineStyle) -> [CGFloat] {
        switch s {
        case .solid: return []
        case .dashed: return [7, 4]
        case .dotted: return [2, 3]
        }
    }

    /// one line of text centred at a point
    func centered(_ s: String, _ c: CGPoint, _ f: F, _ col: NSColor) {
        let w = TextM.width(s, f)
        p.text(s, CGPoint(x: c.x - w / 2, y: c.y - f.lineHeight / 2), f, col)
    }

    /// wrapped text in a box, centred both ways (or top-left)
    func block(_ s: String, _ r: CGRect, _ f: F, _ col: NSColor, center: Bool = true, top: Bool = false) {
        guard !s.isEmpty else { return }
        let lines = TextM.wrap(s, f, max(10, r.width))
        let lh = f.lineHeight
        let total = CGFloat(lines.count) * lh
        var y = top ? r.minY : r.midY - total / 2
        for l in lines {
            let w = TextM.width(l, f)
            let x = center ? r.midX - w / 2 : r.minX
            p.text(l, CGPoint(x: x, y: y), f, col)
            y += lh
        }
    }

    func underline(_ s: String, at pt: CGPoint, _ f: F, _ col: NSColor) {
        let w = TextM.width(s, f)
        let y = pt.y + f.ns.ascender + 2
        p.stroke(Renderer.line(CGPoint(x: pt.x, y: y), CGPoint(x: pt.x + w, y: y)), col, 0.8)
    }

    func stickFigure(_ r: CGRect, _ col: NSColor, _ fill: NSColor) {
        let cx = r.midX
        let h = r.height
        let head = min(r.width * 0.36, h * 0.24)
        let headR = CGRect(x: cx - head / 2, y: r.minY + 2, width: head, height: head)
        p.fill(CGPath(ellipseIn: headR, transform: nil), fill)
        p.stroke(CGPath(ellipseIn: headR, transform: nil), col, 1.5)
        let neck = headR.maxY
        let hip = r.minY + h * 0.62
        let body = CGMutablePath()
        body.move(to: CGPoint(x: cx, y: neck)); body.addLine(to: CGPoint(x: cx, y: hip))
        body.move(to: CGPoint(x: cx - r.width * 0.42, y: neck + h * 0.12)); body.addLine(to: CGPoint(x: cx + r.width * 0.42, y: neck + h * 0.12))
        body.move(to: CGPoint(x: cx, y: hip)); body.addLine(to: CGPoint(x: cx - r.width * 0.36, y: r.maxY - 2))
        body.move(to: CGPoint(x: cx, y: hip)); body.addLine(to: CGPoint(x: cx + r.width * 0.36, y: r.maxY - 2))
        p.stroke(body, col, 1.5)
    }

    // MARK: nodes

    func drawNode(_ n: Node) {
        let r = n.frame
        let lk = look(n)
        let fs = CGFloat(n.fontSize ?? 12)
        let nameF = F(size: fs)
        let boldF = F(size: fs, bold: true)

        switch n.kind {
        case .klass, .interface, .enumeration, .object:
            drawClassifier(n, lk)

        case .entity:
            drawEntity(n, lk)

        case .note:
            let fold: CGFloat = 12
            let path = Renderer.poly([CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.maxX - fold, y: r.minY), CGPoint(x: r.maxX, y: r.minY + fold),
                                      CGPoint(x: r.maxX, y: r.maxY), CGPoint(x: r.minX, y: r.maxY)])
            p.fill(path, lk.fill)
            p.stroke(path, lk.stroke, 1)
            p.stroke(Renderer.poly([CGPoint(x: r.maxX - fold, y: r.minY), CGPoint(x: r.maxX - fold, y: r.minY + fold), CGPoint(x: r.maxX, y: r.minY + fold)], close: false), lk.stroke, 1)
            block(n.name, r.insetBy(dx: 9, dy: 7), F(size: fs - 0.5), lk.text, center: false, top: true)

        case .text:
            block(n.name, r.insetBy(dx: 2, dy: 2), nameF, lk.text)

        case .annotation:
            let br = Renderer.poly([CGPoint(x: r.minX + 12, y: r.minY), CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.minX, y: r.maxY), CGPoint(x: r.minX + 12, y: r.maxY)], close: false)
            p.stroke(br, pal.muted, 1.2)
            block(n.name, r.insetBy(dx: 10, dy: 6), F(size: fs - 0.5), lk.text, center: false, top: true)

        case .rect:
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.2)
            block(n.name, r.insetBy(dx: 8, dy: 6), nameF, lk.text)

        case .ellipse:
            let path = CGPath(ellipseIn: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.2)
            block(n.name, r.insetBy(dx: r.width * 0.15, dy: r.height * 0.15), nameF, lk.text)

        case .actor:
            let fig = Geo.clipRect(n)
            stickFigure(fig, lk.stroke == pal.look(.actor).stroke ? pal.ink : lk.stroke, n.fill.map { NSColor(hex: $0) } ?? pal.paper)
            let w = max(r.width + 60, TextM.width(n.name, boldF))
            block(n.name, CGRect(x: r.midX - w / 2, y: fig.maxY + 2, width: w, height: Geo.actorLabel), boldF, lk.text)

        case .useCase:
            let path = CGPath(ellipseIn: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, r.insetBy(dx: r.width * 0.14, dy: 4), nameF, lk.text)

        case .boundary:
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            centered(n.name, CGPoint(x: r.midX, y: r.minY + 16), boldF, lk.text)

        case .package:
            let tabW = min(max(TextM.width(n.name, boldF) + 20, 70), r.width * 0.7)
            let tab = CGRect(x: r.minX, y: r.minY, width: tabW, height: 22)
            let body = CGRect(x: r.minX, y: r.minY + 22, width: r.width, height: r.height - 22)
            p.fill(CGPath(rect: tab, transform: nil), lk.header); p.stroke(CGPath(rect: tab, transform: nil), lk.stroke, 1.2)
            p.fill(CGPath(rect: body, transform: nil), lk.fill); p.stroke(CGPath(rect: body, transform: nil), lk.stroke, 1.2)
            centered(n.name, tab.center, boldF, lk.text)
            if !n.stereotype.isEmpty { centered("«\(n.stereotype)»", CGPoint(x: body.midX, y: body.minY + 12), F(size: fs - 1.5), pal.muted) }

        case .lifeline, .actorLifeline:
            let h = Geo.header(n)
            let lineCol = n.stroke.map { NSColor(hex: $0) } ?? pal.muted
            p.stroke(Renderer.line(CGPoint(x: r.midX, y: h.maxY), CGPoint(x: r.midX, y: r.maxY)), lineCol, 1.1, dash: [6, 4])
            let c = n.prop("classifier")
            let label = c.isEmpty ? n.name : (n.name.isEmpty ? ": \(c)" : "\(n.name) : \(c)")
            if n.kind == .lifeline {
                let path = Renderer.rrect(h, 5)
                p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
                let w = TextM.width(label, boldF)
                let pt = CGPoint(x: h.midX - w / 2, y: h.midY - boldF.lineHeight / 2)
                p.text(label, pt, boldF, lk.text)
            } else {
                let fig = CGRect(x: h.midX - 20, y: h.minY + 2, width: 40, height: h.height - 24)
                stickFigure(fig, pal.ink, n.fill.map { NSColor(hex: $0) } ?? pal.paper)
                let w = max(r.width + 40, TextM.width(label, boldF))
                block(label, CGRect(x: h.midX - w / 2, y: fig.maxY + 2, width: w, height: 20), boldF, lk.text)
            }

        case .fragment:
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, lk.fill.withAlphaComponent(pal.dark ? 0.03 : 0.35))
            p.stroke(path, lk.stroke, 1.2)
            let op = n.prop("operator").isEmpty ? "loop" : n.prop("operator")
            let opF = F(size: fs - 0.5, bold: true)
            let tw = TextM.width(op, opF) + 20
            let tab = Renderer.poly([CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.minX + tw, y: r.minY), CGPoint(x: r.minX + tw, y: r.minY + 12),
                                     CGPoint(x: r.minX + tw - 8, y: r.minY + 21), CGPoint(x: r.minX, y: r.minY + 21)])
            p.fill(tab, lk.header); p.stroke(tab, lk.stroke, 1.2)
            p.text(op, CGPoint(x: r.minX + 7, y: r.minY + 10.5 - opF.lineHeight / 2), opF, lk.text)
            if op == "ref" {
                block(n.name, r.insetBy(dx: 10, dy: 22), boldF, lk.text)
            } else {
                let guards = n.name.split(separator: "|", omittingEmptySubsequences: false).map { $0.trimmingCharacters(in: .whitespaces) }
                let parts = max(1, guards.count)
                let top = r.minY + 24
                let partH = (r.maxY - top) / CGFloat(parts)
                for (i, g) in guards.enumerated() {
                    let y = top + CGFloat(i) * partH
                    if i > 0 { p.stroke(Renderer.line(CGPoint(x: r.minX, y: y - 3), CGPoint(x: r.maxX, y: y - 3)), lk.stroke, 1, dash: [6, 4]) }
                    if !g.isEmpty { p.text("[\(g)]", CGPoint(x: r.minX + (i == 0 ? tw + 8 : 10), y: i == 0 ? r.minY + 4 : y + 1), F(size: fs - 1), lk.text) }
                }
            }

        case .initial:
            p.fill(CGPath(ellipseIn: r, transform: nil), lk.fill)

        case .final:
            p.fill(CGPath(ellipseIn: r, transform: nil), pal.paper)
            p.stroke(CGPath(ellipseIn: r.insetBy(dx: 0.75, dy: 0.75), transform: nil), lk.stroke, 1.5)
            p.fill(CGPath(ellipseIn: r.insetBy(dx: r.width * 0.22, dy: r.height * 0.22), transform: nil), lk.fill)

        case .flowFinal:
            p.fill(CGPath(ellipseIn: r, transform: nil), pal.paper)
            p.stroke(CGPath(ellipseIn: r.insetBy(dx: 0.75, dy: 0.75), transform: nil), lk.stroke, 1.5)
            let k = r.width * 0.146
            let x = CGMutablePath()
            x.move(to: CGPoint(x: r.minX + k, y: r.minY + k)); x.addLine(to: CGPoint(x: r.maxX - k, y: r.maxY - k))
            x.move(to: CGPoint(x: r.maxX - k, y: r.minY + k)); x.addLine(to: CGPoint(x: r.minX + k, y: r.maxY - k))
            p.stroke(x, lk.stroke, 1.5)

        case .action, .task:
            let path = Renderer.rrect(r, n.kind == .task ? 10 : 14)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, r.insetBy(dx: 10, dy: 5), nameF, lk.text)

        case .subProcess:
            let path = Renderer.rrect(r, 10)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, CGRect(x: r.minX + 10, y: r.minY + 4, width: r.width - 20, height: r.height - 26), nameF, lk.text)
            let b = CGRect(x: r.midX - 7, y: r.maxY - 18, width: 14, height: 14)
            p.stroke(CGPath(rect: b, transform: nil), lk.stroke, 1)
            let plus = CGMutablePath()
            plus.move(to: CGPoint(x: b.midX, y: b.minY + 3)); plus.addLine(to: CGPoint(x: b.midX, y: b.maxY - 3))
            plus.move(to: CGPoint(x: b.minX + 3, y: b.midY)); plus.addLine(to: CGPoint(x: b.maxX - 3, y: b.midY))
            p.stroke(plus, lk.stroke, 1.2)

        case .decision, .merge, .choice:
            let path = Renderer.diamond(r)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)

        case .fDecision:
            let path = Renderer.diamond(r)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, r.insetBy(dx: r.width * 0.22, dy: r.height * 0.2), nameF, lk.text)

        case .fork:
            p.fill(Renderer.rrect(r, 2), lk.fill)

        case .lane, .pool:
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            if r.width > r.height {
                let hdr = CGRect(x: r.minX, y: r.minY, width: 30, height: r.height)
                p.fill(CGPath(rect: hdr, transform: nil), lk.header); p.stroke(CGPath(rect: hdr, transform: nil), lk.stroke, 1.3)
                let w = TextM.width(n.name, boldF)
                p.text(n.name, CGPoint(x: hdr.midX - boldF.lineHeight / 2, y: hdr.midY + w / 2), boldF, lk.text, angle: -90)
            } else {
                let hdr = CGRect(x: r.minX, y: r.minY, width: r.width, height: 30)
                p.fill(CGPath(rect: hdr, transform: nil), lk.header); p.stroke(CGPath(rect: hdr, transform: nil), lk.stroke, 1.3)
                centered(n.name, hdr.center, boldF, lk.text)
            }

        case .objectNode, .process, .external:
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, n.kind == .external ? 2 : 1.3)
            block(n.name, r.insetBy(dx: 8, dy: 5), nameF, lk.text)

        case .sendSignal:
            let k = min(18, r.width / 4)
            let path = Renderer.poly([CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.maxX - k, y: r.minY), CGPoint(x: r.maxX, y: r.midY),
                                      CGPoint(x: r.maxX - k, y: r.maxY), CGPoint(x: r.minX, y: r.maxY)])
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, CGRect(x: r.minX + 8, y: r.minY, width: r.width - k - 12, height: r.height), nameF, lk.text)

        case .acceptEvent:
            let k = min(18, r.width / 4)
            let path = Renderer.poly([CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.maxX, y: r.minY), CGPoint(x: r.maxX, y: r.maxY),
                                      CGPoint(x: r.minX, y: r.maxY), CGPoint(x: r.minX + k, y: r.midY)])
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, CGRect(x: r.minX + k + 4, y: r.minY, width: r.width - k - 12, height: r.height), nameF, lk.text)

        case .state:
            let path = Renderer.rrect(r, 16)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            let acts = [("entry", n.prop("entry")), ("do", n.prop("do")), ("exit", n.prop("exit"))].filter { !$0.1.isEmpty }
            let big = r.height > 110 && r.width > 180
            if acts.isEmpty && !big {
                block(n.name, r.insetBy(dx: 10, dy: 4), boldF, lk.text)
            } else {
                centered(n.name, CGPoint(x: r.midX, y: r.minY + 14), boldF, lk.text)
                p.stroke(Renderer.line(CGPoint(x: r.minX, y: r.minY + 27), CGPoint(x: r.maxX, y: r.minY + 27)), lk.stroke, 1)
                var y = r.minY + 32
                let af = F(size: fs - 1)
                for (k, v) in acts {
                    p.text("\(k) / \(v)", CGPoint(x: r.minX + 10, y: y), af, lk.text)
                    y += af.lineHeight + 1
                }
            }

        case .history:
            p.fill(CGPath(ellipseIn: r, transform: nil), lk.fill)
            p.stroke(CGPath(ellipseIn: r, transform: nil), lk.stroke, 1.3)
            centered(n.prop("deep") == "true" ? "H*" : "H", r.center, F(size: fs, bold: true), lk.text)

        case .component:
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            let ic = CGRect(x: r.maxX - 26, y: r.minY + 8, width: 16, height: 18)
            p.fill(CGPath(rect: ic, transform: nil), lk.fill); p.stroke(CGPath(rect: ic, transform: nil), lk.stroke, 1)
            for dy in [CGFloat(3), 10] {
                let t = CGRect(x: ic.minX - 4, y: ic.minY + dy, width: 8, height: 4)
                p.fill(CGPath(rect: t, transform: nil), lk.fill); p.stroke(CGPath(rect: t, transform: nil), lk.stroke, 1)
            }
            let big = r.height > 120
            let st = n.stereotype.isEmpty ? "«component»" : "«\(n.stereotype)»"
            if big {
                centered(st, CGPoint(x: r.midX, y: r.minY + 14), F(size: fs - 1.5), pal.muted)
                centered(n.name, CGPoint(x: r.midX, y: r.minY + 30), boldF, lk.text)
            } else {
                centered(st, CGPoint(x: r.midX, y: r.midY - 9), F(size: fs - 1.5), pal.muted)
                centered(n.name, CGPoint(x: r.midX, y: r.midY + 8), boldF, lk.text)
            }

        case .provided:
            p.fill(CGPath(ellipseIn: r, transform: nil), lk.fill)
            p.stroke(CGPath(ellipseIn: r, transform: nil), lk.stroke, 1.5)

        case .artifact:
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            let ic = CGRect(x: r.maxX - 22, y: r.minY + 7, width: 13, height: 16)
            let doc = Renderer.poly([CGPoint(x: ic.minX, y: ic.minY), CGPoint(x: ic.maxX - 5, y: ic.minY), CGPoint(x: ic.maxX, y: ic.minY + 5),
                                     CGPoint(x: ic.maxX, y: ic.maxY), CGPoint(x: ic.minX, y: ic.maxY)])
            p.stroke(doc, lk.stroke, 1)
            centered(n.stereotype.isEmpty ? "«artifact»" : "«\(n.stereotype)»", CGPoint(x: r.midX, y: r.midY - 9), F(size: fs - 1.5), pal.muted)
            centered(n.name, CGPoint(x: r.midX, y: r.midY + 8), boldF, lk.text)

        case .node3d, .device, .execEnv:
            let dpt: CGFloat = n.kind == .execEnv ? 8 : 12
            let front = CGRect(x: r.minX, y: r.minY + dpt, width: r.width - dpt, height: r.height - dpt)
            let top = Renderer.poly([CGPoint(x: front.minX, y: front.minY), CGPoint(x: front.minX + dpt, y: r.minY), CGPoint(x: r.maxX, y: r.minY), CGPoint(x: front.maxX, y: front.minY)])
            let side = Renderer.poly([CGPoint(x: front.maxX, y: front.minY), CGPoint(x: r.maxX, y: r.minY), CGPoint(x: r.maxX, y: r.maxY - dpt), CGPoint(x: front.maxX, y: front.maxY)])
            p.fill(top, lk.header); p.stroke(top, lk.stroke, 1.2)
            p.fill(side, lk.header.blended(withFraction: 0.15, of: pal.dark ? .black : .gray) ?? lk.header); p.stroke(side, lk.stroke, 1.2)
            p.fill(CGPath(rect: front, transform: nil), lk.fill); p.stroke(CGPath(rect: front, transform: nil), lk.stroke, 1.2)
            let st = n.stereotype.isEmpty ? (n.kind == .device ? "«device»" : n.kind == .execEnv ? "«executionEnvironment»" : "") : "«\(n.stereotype)»"
            var y = front.minY + 6
            if !st.isEmpty { p.text(st, CGPoint(x: front.minX + 8, y: y), F(size: fs - 1.5), pal.muted); y += 14 }
            p.text(n.name, CGPoint(x: front.minX + 8, y: y), boldF, lk.text)

        case .terminator:
            let path = Renderer.rrect(r, r.height / 2)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, r.insetBy(dx: r.height / 3, dy: 3), nameF, lk.text)

        case .io:
            let k = min(18, r.width / 5)
            let path = Renderer.poly([CGPoint(x: r.minX + k, y: r.minY), CGPoint(x: r.maxX, y: r.minY), CGPoint(x: r.maxX - k, y: r.maxY), CGPoint(x: r.minX, y: r.maxY)])
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, r.insetBy(dx: k + 4, dy: 4), nameF, lk.text)

        case .predefined:
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            p.stroke(Renderer.line(CGPoint(x: r.minX + 10, y: r.minY), CGPoint(x: r.minX + 10, y: r.maxY)), lk.stroke, 1.2)
            p.stroke(Renderer.line(CGPoint(x: r.maxX - 10, y: r.minY), CGPoint(x: r.maxX - 10, y: r.maxY)), lk.stroke, 1.2)
            block(n.name, r.insetBy(dx: 14, dy: 4), nameF, lk.text)

        case .document:
            let path = CGMutablePath()
            let wave = min(10, r.height * 0.15)
            path.move(to: CGPoint(x: r.minX, y: r.minY))
            path.addLine(to: CGPoint(x: r.maxX, y: r.minY))
            path.addLine(to: CGPoint(x: r.maxX, y: r.maxY - wave))
            path.addCurve(to: CGPoint(x: r.minX, y: r.maxY - wave), control1: CGPoint(x: r.maxX - r.width * 0.3, y: r.maxY - wave * 3),
                          control2: CGPoint(x: r.minX + r.width * 0.3, y: r.maxY + wave))
            path.closeSubpath()
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, CGRect(x: r.minX + 6, y: r.minY + 2, width: r.width - 12, height: r.height - wave - 4), nameF, lk.text)

        case .database, .dataStore:
            let e = min(r.height * 0.22, 16)
            let body = CGMutablePath()
            body.move(to: CGPoint(x: r.minX, y: r.minY + e / 2))
            body.addLine(to: CGPoint(x: r.minX, y: r.maxY - e / 2))
            body.addCurve(to: CGPoint(x: r.maxX, y: r.maxY - e / 2), control1: CGPoint(x: r.minX, y: r.maxY + e * 0.17), control2: CGPoint(x: r.maxX, y: r.maxY + e * 0.17))
            body.addLine(to: CGPoint(x: r.maxX, y: r.minY + e / 2))
            body.closeSubpath()
            p.fill(body, lk.fill); p.stroke(body, lk.stroke, 1.3)
            let top = CGRect(x: r.minX, y: r.minY, width: r.width, height: e)
            p.fill(CGPath(ellipseIn: top, transform: nil), lk.header); p.stroke(CGPath(ellipseIn: top, transform: nil), lk.stroke, 1.3)
            if n.kind == .database { block(n.name, CGRect(x: r.minX + 4, y: r.minY + e, width: r.width - 8, height: r.height - e * 1.5), nameF, lk.text) }

        case .manualInput:
            let k = min(16, r.height * 0.35)
            let path = Renderer.poly([CGPoint(x: r.minX, y: r.minY + k), CGPoint(x: r.maxX, y: r.minY), CGPoint(x: r.maxX, y: r.maxY), CGPoint(x: r.minX, y: r.maxY)])
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, CGRect(x: r.minX + 6, y: r.minY + k / 2, width: r.width - 12, height: r.height - k / 2), nameF, lk.text)

        case .connector:
            p.fill(CGPath(ellipseIn: r, transform: nil), lk.fill); p.stroke(CGPath(ellipseIn: r, transform: nil), lk.stroke, 1.3)
            centered(n.name, r.center, boldF, lk.text)

        case .preparation:
            let k = min(18, r.width / 5)
            let path = Renderer.poly([CGPoint(x: r.minX + k, y: r.minY), CGPoint(x: r.maxX - k, y: r.minY), CGPoint(x: r.maxX, y: r.midY),
                                      CGPoint(x: r.maxX - k, y: r.maxY), CGPoint(x: r.minX + k, y: r.maxY), CGPoint(x: r.minX, y: r.midY)])
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            block(n.name, r.insetBy(dx: k + 2, dy: 4), nameF, lk.text)

        case .startEvent, .interEvent, .endEvent:
            let path = CGPath(ellipseIn: r, transform: nil)
            p.fill(path, lk.fill)
            p.stroke(path, lk.stroke, n.kind == .endEvent ? 3.2 : 1.8)
            if n.kind == .interEvent { p.stroke(CGPath(ellipseIn: r.insetBy(dx: 3.5, dy: 3.5), transform: nil), lk.stroke, 1.4) }
            let trig = n.prop("trigger")
            if !trig.isEmpty { drawTrigger(trig, r.insetBy(dx: r.width * 0.27, dy: r.height * 0.27), lk.stroke, filled: n.kind == .endEvent) }

        case .xorGateway, .andGateway, .orGateway:
            let path = Renderer.diamond(r)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.5)
            let k = r.width * 0.3
            let c = r.center
            if n.kind == .xorGateway {
                let x = CGMutablePath()
                x.move(to: CGPoint(x: c.x - k * 0.7, y: c.y - k * 0.7)); x.addLine(to: CGPoint(x: c.x + k * 0.7, y: c.y + k * 0.7))
                x.move(to: CGPoint(x: c.x + k * 0.7, y: c.y - k * 0.7)); x.addLine(to: CGPoint(x: c.x - k * 0.7, y: c.y + k * 0.7))
                p.stroke(x, lk.stroke, 3)
            } else if n.kind == .andGateway {
                let x = CGMutablePath()
                x.move(to: CGPoint(x: c.x, y: c.y - k)); x.addLine(to: CGPoint(x: c.x, y: c.y + k))
                x.move(to: CGPoint(x: c.x - k, y: c.y)); x.addLine(to: CGPoint(x: c.x + k, y: c.y))
                p.stroke(x, lk.stroke, 3)
            } else {
                p.stroke(CGPath(ellipseIn: CGRect(x: c.x - k * 0.75, y: c.y - k * 0.75, width: k * 1.5, height: k * 1.5), transform: nil), lk.stroke, 2.5)
            }

        case .dataObject:
            let fold: CGFloat = 10
            let path = Renderer.poly([CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.maxX - fold, y: r.minY), CGPoint(x: r.maxX, y: r.minY + fold),
                                      CGPoint(x: r.maxX, y: r.maxY), CGPoint(x: r.minX, y: r.maxY)])
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.3)
            p.stroke(Renderer.poly([CGPoint(x: r.maxX - fold, y: r.minY), CGPoint(x: r.maxX - fold, y: r.minY + fold), CGPoint(x: r.maxX, y: r.minY + fold)], close: false), lk.stroke, 1)

        case .central:
            let path = Renderer.rrect(r, r.height / 2)
            p.fill(path, lk.fill)
            block(n.name, r.insetBy(dx: 16, dy: 4), F(size: fs + 3, bold: true), lk.text)

        case .topic:
            let path = Renderer.rrect(r, 9)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.5)
            block(n.name, r.insetBy(dx: 10, dy: 3), nameF, lk.text)

        case .dfdProcess:
            let path = CGPath(ellipseIn: r, transform: nil)
            p.fill(path, lk.fill); p.stroke(path, lk.stroke, 1.5)
            block(n.name, r.insetBy(dx: r.width * 0.15, dy: r.height * 0.2), nameF, lk.text)

        case .dfdStore:
            p.fill(CGPath(rect: r, transform: nil), lk.fill)
            let path = CGMutablePath()
            path.move(to: CGPoint(x: r.maxX, y: r.minY)); path.addLine(to: CGPoint(x: r.minX, y: r.minY))
            path.addLine(to: CGPoint(x: r.minX, y: r.maxY)); path.addLine(to: CGPoint(x: r.maxX, y: r.maxY))
            path.move(to: CGPoint(x: r.minX + 34, y: r.minY)); path.addLine(to: CGPoint(x: r.minX + 34, y: r.maxY))
            p.stroke(path, lk.stroke, 1.5)
            let parts = n.name.split(separator: " ", maxSplits: 1, omittingEmptySubsequences: true).map(String.init)
            if parts.count == 2 && parts[0].count <= 4 {
                centered(parts[0], CGPoint(x: r.minX + 17, y: r.midY), boldF, lk.text)
                block(parts[1].trimmed, CGRect(x: r.minX + 40, y: r.minY, width: r.width - 44, height: r.height), nameF, lk.text, center: false)
            } else {
                block(n.name, CGRect(x: r.minX + 40, y: r.minY, width: r.width - 44, height: r.height), nameF, lk.text, center: false)
            }
        }

        // names written under small shapes
        if n.kind.info.labelBelow && !n.name.isEmpty {
            let f = F(size: fs - 0.5)
            let w = max(120, r.width + 60)
            let lines = TextM.wrap(n.name, f, w)
            var y = r.maxY + 3
            for l in lines {
                centered(l, CGPoint(x: r.midX, y: y + f.lineHeight / 2), f, lk.text)
                y += f.lineHeight
            }
        }
        if (n.kind == .history || n.kind == .initial || n.kind == .final) && !n.name.isEmpty {
            centered(n.name, CGPoint(x: r.midX, y: r.maxY + 10), F(size: fs - 1), pal.muted)
        }
    }

    func drawTrigger(_ t: String, _ r: CGRect, _ c: NSColor, filled: Bool) {
        switch t {
        case "message":
            let env = CGRect(x: r.minX, y: r.minY + r.height * 0.18, width: r.width, height: r.height * 0.64)
            if filled { p.fill(CGPath(rect: env, transform: nil), c) } else { p.stroke(CGPath(rect: env, transform: nil), c, 1.2) }
            p.stroke(Renderer.poly([CGPoint(x: env.minX, y: env.minY), CGPoint(x: env.midX, y: env.midY), CGPoint(x: env.maxX, y: env.minY)], close: false), filled ? pal.paper : c, 1.2)
        case "timer":
            p.stroke(CGPath(ellipseIn: r, transform: nil), c, 1.2)
            p.stroke(Renderer.poly([CGPoint(x: r.midX, y: r.minY + 3), r.center, CGPoint(x: r.maxX - 3, y: r.midY)], close: false), c, 1.2)
        case "error":
            let path = Renderer.poly([CGPoint(x: r.minX, y: r.maxY), CGPoint(x: r.minX + r.width * 0.3, y: r.minY + r.height * 0.2), CGPoint(x: r.midX + 2, y: r.midY + 1),
                                      CGPoint(x: r.maxX, y: r.minY), CGPoint(x: r.maxX - r.width * 0.3, y: r.maxY - r.height * 0.2), CGPoint(x: r.midX - 2, y: r.midY - 1)])
            if filled { p.fill(path, c) } else { p.stroke(path, c, 1.2) }
        default: break
        }
    }

    func drawClassifier(_ n: Node, _ lk: Palette.Look) {
        let r = n.frame
        let L = ClassLayout.of(n)
        let fs = CGFloat(n.fontSize ?? 12)
        let memF = F(size: fs - 0.5)
        let body = Renderer.rrect(r, 3)
        p.fill(body, lk.fill)
        // header band
        let hdr = CGMutablePath()
        let hr = CGRect(x: r.minX, y: r.minY, width: r.width, height: L.headerH)
        hdr.addPath(Renderer.rrect(hr, 3))
        p.fill(hdr, lk.header)
        p.stroke(body, lk.stroke, 1.3)
        var y = r.minY + ClassLayout.pad
        if !L.stereo.isEmpty {
            let sf = F(size: fs - 1.5)
            centered(L.stereo, CGPoint(x: r.midX, y: y + sf.lineHeight / 2), sf, lk.text.withAlphaComponent(0.75))
            y += sf.lineHeight
        }
        let nf = F(size: fs + 0.5, bold: true, italic: n.isAbstract)
        let nw = TextM.width(L.name, nf)
        let npt = CGPoint(x: r.midX - nw / 2, y: y)
        p.text(L.name, npt, nf, lk.text)
        if n.kind == .object { underline(L.name, at: npt, nf, lk.text) }

        let sep1 = r.minY + L.attrTop
        p.stroke(Renderer.line(CGPoint(x: r.minX, y: sep1), CGPoint(x: r.maxX, y: sep1)), lk.stroke, 1)
        var ry = sep1 + 4
        for m in n.attrs {
            let s = UMLText.attrLine(m, kind: n.kind)
            let pt = CGPoint(x: r.minX + 8, y: ry + (L.rowH - memF.lineHeight) / 2)
            p.text(s, pt, memF, lk.text)
            if m.isStatic { underline(s, at: pt, memF, lk.text) }
            ry += L.rowH
        }
        if L.showOps {
            let sep2 = r.minY + L.opTop
            p.stroke(Renderer.line(CGPoint(x: r.minX, y: sep2), CGPoint(x: r.maxX, y: sep2)), lk.stroke, 1)
            ry = sep2 + 4
            for m in n.ops {
                let s = UMLText.opLine(m)
                let f = F(size: fs - 0.5, italic: m.isAbstract)
                let pt = CGPoint(x: r.minX + 8, y: ry + (L.rowH - f.lineHeight) / 2)
                p.text(s, pt, f, lk.text)
                if m.isStatic { underline(s, at: pt, f, lk.text) }
                ry += L.rowH
            }
        }
    }

    func drawEntity(_ n: Node, _ lk: Palette.Look) {
        let r = n.frame
        let L = EntityLayout.of(n)
        let fs = CGFloat(n.fontSize ?? 12)
        let body = Renderer.rrect(r, 5)
        p.fill(body, lk.fill)
        let hr = CGRect(x: r.minX, y: r.minY, width: r.width, height: L.headerH)
        let hp = CGMutablePath()
        hp.addPath(Renderer.rrect(hr, 5))
        p.fill(hp, lk.header)
        p.stroke(Renderer.line(CGPoint(x: r.minX, y: hr.maxY), CGPoint(x: r.maxX, y: hr.maxY)), lk.stroke, 1)
        p.stroke(body, lk.stroke, 1.3)
        centered(n.name, hr.center, F(size: fs + 0.5, bold: true), lk.text)
        let f = F(size: fs - 0.5), fb = F(size: fs - 0.5, bold: true), kf = F(size: fs - 3.5, bold: true)
        var y = hr.maxY + 3
        let keyCol = NSColor(rgb: pal.dark ? 0xE9B941 : 0xB8860B)
        let fkCol = NSColor(rgb: pal.dark ? 0x7AA5F5 : 0x3F6FC4)
        for m in n.attrs {
            let ty = y + (L.rowH - f.lineHeight) / 2
            var kx = r.minX + 5
            if m.pk { p.text("PK", CGPoint(x: kx, y: y + (L.rowH - kf.lineHeight) / 2), kf, keyCol); kx += 13 }
            if m.fk { p.text("FK", CGPoint(x: m.pk ? kx : kx, y: y + (L.rowH - kf.lineHeight) / 2), kf, fkCol) }
            p.text(m.name, CGPoint(x: r.minX + L.keyW, y: ty), m.pk ? fb : f, lk.text)
            if m.pk { underline(m.name, at: CGPoint(x: r.minX + L.keyW, y: ty), fb, lk.text) }
            let t = m.type + (m.nullable || m.pk ? "" : " ·")
            let tw = TextM.width(t, f)
            p.text(t, CGPoint(x: r.maxX - tw - 8, y: ty), f, pal.muted)
            y += L.rowH
        }
    }

    // MARK: sequence activations

    /// bars on a lifeline from each incoming call until the matching return
    func activations() -> [CGRect] {
        var out: [CGRect] = []
        let msgs = d.edges.filter { $0.kind.isMessage }.sorted { ($0.y ?? 0) < ($1.y ?? 0) }
        for n in d.nodes where n.kind.isLifeline {
            let h = Geo.header(n)
            for m in msgs where m.to == n.id && (m.kind == .message || m.kind == .create) && m.from != m.to {
                guard let a = nodes[m.from] else { continue }
                let y1 = CGFloat(m.y ?? Double(Geo.defaultMessageY(a, n)))
                let ret = msgs.first { $0.from == n.id && $0.to == m.from && $0.kind == .reply && CGFloat($0.y ?? 0) > y1 }
                var y2 = ret.map { CGFloat($0.y ?? 0) } ?? y1 + 30
                // stay active while this lifeline keeps sending calls before its return
                if ret == nil {
                    for o in msgs where o.from == n.id && CGFloat(o.y ?? 0) > y1 {
                        let next = msgs.first { $0.to == n.id && $0.id != m.id && $0.kind != .reply && CGFloat($0.y ?? 0) > y1 && CGFloat($0.y ?? 0) < CGFloat(o.y ?? 0) }
                        if next != nil { break }
                        y2 = max(y2, CGFloat(o.y ?? 0) + 10)
                    }
                }
                let top = max(y1, h.maxY)
                out.append(CGRect(x: n.frame.midX - 5, y: top, width: 10, height: max(12, min(y2, n.frame.maxY) - top)))
            }
        }
        return out
    }

    func drawActivations() {
        for r in activations() {
            let path = CGPath(rect: r, transform: nil)
            p.fill(path, pal.dark ? NSColor(rgb: 0x2A2E36) : .white)
            p.stroke(path, pal.muted, 1)
        }
    }

    // MARK: connectors

    func drawEdge(_ e: Edge, highlight: NSColor? = nil) {
        guard let r = route(e) else { return }
        let st = e.kind.style
        var col = e.stroke.map { NSColor(hex: $0) } ?? pal.ink
        var w = CGFloat(e.width ?? (e.kind == .branch ? 3 : 1.2))
        if e.kind == .branch, e.stroke == nil {
            let other = mindColor[e.to] ?? mindColor[e.from]
            if let i = other { col = NSColor(rgb: Palette.mindColors[i % Palette.mindColors.count]) }
            if let a = nodes[e.from], a.kind == .central { w = CGFloat(e.width ?? 4) }
        }
        if e.kind == .anchor || e.kind == .bpmnAssoc { col = e.stroke.map { NSColor(hex: $0) } ?? pal.muted }
        if let h = highlight { col = h }
        p.stroke(r.cgPath, col, w, dash: dash(st.line))

        if e.kind == .relationship {
            crowFoot(e.fromMult, at: r.start, dir: r.startDir, col)
            crowFoot(e.toMult, at: r.end, dir: r.endDir, col)
        } else {
            marker(st.start, at: r.start, dir: r.startDir, col)
            marker(st.end, at: r.end, dir: r.endDir, col)
        }
        labels(e, r, col)
    }

    func marker(_ m: Marker, at tip: CGPoint, dir u: CGPoint, _ col: NSColor) {
        let v = u.perp
        switch m {
        case .none: break
        case .open:
            p.stroke(Renderer.poly([tip - u * 11 + v * 6, tip, tip - u * 11 - v * 6], close: false), col, 1.3)
        case .filled:
            p.fill(Renderer.poly([tip, tip - u * 11 + v * 5, tip - u * 11 - v * 5]), col)
        case .hollowTri:
            let path = Renderer.poly([tip, tip - u * 14 + v * 8, tip - u * 14 - v * 8])
            p.fill(path, pal.paper); p.stroke(path, col, 1.3)
        case .hollowDiamond, .filledDiamond:
            let path = Renderer.poly([tip, tip - u * 9 + v * 6, tip - u * 18, tip - u * 9 - v * 6])
            p.fill(path, m == .filledDiamond ? col : pal.paper); p.stroke(path, col, 1.3)
        case .circle:
            let c = tip - u * 5
            let path = CGPath(ellipseIn: CGRect(x: c.x - 4.5, y: c.y - 4.5, width: 9, height: 9), transform: nil)
            p.fill(path, pal.paper); p.stroke(path, col, 1.2)
        }
    }

    /// crow's foot notation from a multiplicity: 1, 0..1, 1..*, 0..*
    func crowFoot(_ mult: String, at tip: CGPoint, dir u: CGPoint, _ col: NSColor) {
        let v = u.perp
        let m = mult.replacingOccurrences(of: " ", with: "")
        let many = m.contains("*") || m.contains("n") || m.contains("N") || m.contains("m")
        let zero = m.hasPrefix("0")
        func bar(_ k: CGFloat) { p.stroke(Renderer.line(tip - u * k + v * 7, tip - u * k - v * 7), col, 1.3) }
        func ring(_ k: CGFloat) {
            let c = tip - u * k
            let path = CGPath(ellipseIn: CGRect(x: c.x - 4.5, y: c.y - 4.5, width: 9, height: 9), transform: nil)
            p.fill(path, pal.paper); p.stroke(path, col, 1.3)
        }
        if m.isEmpty { return }
        if many {
            let q = tip - u * 13
            let path = CGMutablePath()
            path.move(to: q); path.addLine(to: tip + v * 7)
            path.move(to: q); path.addLine(to: tip)
            path.move(to: q); path.addLine(to: tip - v * 7)
            p.stroke(path, col, 1.3)
            if zero { ring(20) } else { bar(17) }
        } else {
            bar(7)
            if zero { ring(16) } else { bar(12) }
        }
    }

    func labelBox(_ s: String, _ c: CGPoint, _ f: F, _ col: NSColor) {
        let w = TextM.width(s, f)
        let r = CGRect(x: c.x - w / 2 - 3, y: c.y - f.lineHeight / 2 - 1, width: w + 6, height: f.lineHeight + 2)
        p.fill(Renderer.rrect(r, 3), pal.paper.withAlphaComponent(0.88))
        p.text(s, CGPoint(x: c.x - w / 2, y: c.y - f.lineHeight / 2), f, col)
    }

    func labels(_ e: Edge, _ r: Route, _ col: NSColor) {
        let f = F(size: 11)
        let textCol = e.kind == .anchor ? pal.muted : pal.ink
        if e.kind.isMessage && d.type == .sequence {
            let no = messageNo[e.id].map { "\($0): " } ?? ""
            let st = e.kind.style.stereo.isEmpty ? "" : e.kind.style.stereo + " "
            let s = no + st + e.name
            let a = r.pts[0], b = r.pts[1]
            if r.pts.count > 2 {
                p.text(s, CGPoint(x: a.x + 50, y: a.y - 2), f, textCol)
            } else {
                let w = TextM.width(s, f)
                let room = abs(b.x - a.x)
                let x = w + 16 > room ? min(a.x, b.x) + 8 : (a.x + b.x) / 2 - w / 2
                p.text(s, CGPoint(x: x, y: a.y - f.lineHeight - 1), f, textCol)
            }
            return
        }
        let (mid, _) = r.middle
        let stereo = e.kind.style.stereo
        var text = e.name
        if e.kind == .transition || e.kind == .controlFlow || e.kind == .sequenceFlow || e.kind == .flow {
            text = e.name
        }
        if !stereo.isEmpty && !text.isEmpty {
            labelBox(stereo, CGPoint(x: mid.x, y: mid.y - 8), f, textCol)
            labelBox(text, CGPoint(x: mid.x, y: mid.y + 8), f, textCol)
        } else if !stereo.isEmpty {
            labelBox(stereo, mid, f, textCol)
        } else if !text.isEmpty {
            labelBox(text, mid, F(size: 11, italic: false), textCol)
        }
        if e.kind.hasEnds && e.kind != .relationship {
            endLabels(e.fromMult, e.fromRole, r.start, r.startDir, f)
            endLabels(e.toMult, e.toRole, r.end, r.endDir, f)
        } else if e.kind == .relationship {
            endLabels("", e.fromRole, r.start, r.startDir, f)
            endLabels("", e.toRole, r.end, r.endDir, f)
        }
    }

    /// multiplicity on one side of the line end, role name on the other
    func endLabels(_ mult: String, _ role: String, _ tip: CGPoint, _ u: CGPoint, _ f: F) {
        var v = u.perp
        if v.y > 0 || (abs(v.y) < 0.01 && v.x < 0) { v = v * -1 }
        let base = tip - u * 22
        if !mult.isEmpty {
            let c = base + v * 11
            let w = TextM.width(mult, f)
            p.text(mult, CGPoint(x: c.x - w / 2, y: c.y - f.lineHeight / 2), f, pal.ink)
        }
        if !role.isEmpty {
            let c = base - v * 11
            let w = TextM.width(role, f)
            p.text(role, CGPoint(x: c.x - w / 2, y: c.y - f.lineHeight / 2), f, pal.muted)
        }
    }
}

// MARK: - bounds of everything drawn in a diagram

extension Diagram {
    var contentBounds: CGRect {
        var r = CGRect.null
        var map: [UUID: Node] = [:]
        for n in nodes {
            map[n.id] = n
            var f = n.frame
            if n.kind.info.labelBelow && !n.name.isEmpty { f = f.union(CGRect(x: f.midX - 70, y: f.maxY, width: 140, height: 34)) }
            if n.kind == .actor { f = f.insetBy(dx: -30, dy: 0) }
            r = r.union(f)
        }
        let spread = Renderer.spreads(self)
        for e in edges {
            if let rt = Geo.route(e, map, sequence: type == .sequence, spread: spread[e.id] ?? 0) { r = r.union(rt.bounds.insetBy(dx: -30, dy: -16)) }
        }
        return r
    }
}
