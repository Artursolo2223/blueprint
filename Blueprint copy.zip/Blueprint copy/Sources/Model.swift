import AppKit

// MARK: - members: attributes, operations, enum literals and table columns

enum Visibility: String, Codable, CaseIterable {
    case pub = "+", priv = "-", prot = "#", pkg = "~"

    var word: String {
        switch self {
        case .pub: return "public"
        case .priv: return "private"
        case .prot: return "protected"
        case .pkg: return "package"
        }
    }
    /// the Java keyword ("" for package-private)
    var java: String { self == .pkg ? "" : word }
    var explain: String {
        switch self {
        case .pub: return "public – every class can use it"
        case .priv: return "private – only this class can use it"
        case .prot: return "protected – this class, its subclasses and its package"
        case .pkg: return "package-private – only classes in the same package"
        }
    }
}

struct Member: Codable, Identifiable, Equatable {
    var id = UUID()
    var name = ""
    var type = ""
    var vis: Visibility = .priv
    var isStatic = false
    var isAbstract = false
    var isFinal = false
    /// operations: "qty: int, price: double"
    var params = ""
    /// attributes: initial value, object slots: the value
    var value = ""
    // database columns
    var pk = false
    var fk = false
    var nullable = true
    var unique = false
    /// the column a foreign key points at, "customer.id"
    var ref = ""
    var doc = ""
}

enum Routing: String, Codable, CaseIterable {
    case straight, orthogonal, curved
    var title: String { rawValue.capitalized }
}

struct Node: Codable, Identifiable, Equatable {
    var id = UUID()
    var kind: NodeKind
    var frame: CGRect
    var name: String
    var stereotype = ""
    var attrs: [Member] = []
    var ops: [Member] = []
    var isAbstract = false
    var doc = ""
    var fill: String? = nil
    var stroke: String? = nil
    var textColor: String? = nil
    var fontSize: Double? = nil
    /// kind specific values: entry/do/exit (states), operator (fragments), classifier (lifelines, objects)
    var props: [String: String] = [:]

    func prop(_ k: String) -> String { props[k] ?? "" }
}

struct Edge: Codable, Identifiable, Equatable {
    var id = UUID()
    var kind: EdgeKind
    var from: UUID
    var to: UUID
    var name = ""
    var fromRole = ""
    var toRole = ""
    var fromMult = ""
    var toMult = ""
    var routing: Routing = .straight
    var points: [CGPoint] = []
    /// sequence diagrams: the height of the message
    var y: Double? = nil
    var stroke: String? = nil
    var width: Double? = nil
    var doc = ""
}

struct Diagram: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var type: DiagramType
    var nodes: [Node] = []
    var edges: [Edge] = []
    var doc = ""

    func node(_ id: UUID) -> Node? { nodes.first { $0.id == id } }
    func index(_ id: UUID) -> Int? { nodes.firstIndex { $0.id == id } }
    func edgeIndex(_ id: UUID) -> Int? { edges.firstIndex { $0.id == id } }
}

struct Project: Codable, Equatable {
    var id = UUID()
    var name = "Untitled Project"
    var author = ""
    var doc = ""
    var diagrams: [Diagram] = []
    var format = 1

    func diagram(_ id: UUID?) -> Diagram? { diagrams.first { $0.id == id } }
    func dindex(_ id: UUID?) -> Int? { diagrams.firstIndex { $0.id == id } }
}

// MARK: - tolerant decoding: files from older versions still open when fields are added

extension KeyedDecodingContainer {
    func v<T: Decodable>(_ k: Key, _ d: T) -> T { (try? decodeIfPresent(T.self, forKey: k)) ?? d }
}

extension Member {
    enum CodingKeys: String, CodingKey { case id, name, type, vis, isStatic, isAbstract, isFinal, params, value, pk, fk, nullable, unique, ref, doc }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: CodingKeys.self)
        id = c.v(.id, UUID()); name = c.v(.name, ""); type = c.v(.type, ""); vis = c.v(.vis, .priv)
        isStatic = c.v(.isStatic, false); isAbstract = c.v(.isAbstract, false); isFinal = c.v(.isFinal, false)
        params = c.v(.params, ""); value = c.v(.value, "")
        pk = c.v(.pk, false); fk = c.v(.fk, false); nullable = c.v(.nullable, true); unique = c.v(.unique, false)
        ref = c.v(.ref, ""); doc = c.v(.doc, "")
    }
}

extension Node {
    enum CodingKeys: String, CodingKey { case id, kind, frame, name, stereotype, attrs, ops, isAbstract, doc, fill, stroke, textColor, fontSize, props }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: CodingKeys.self)
        id = c.v(.id, UUID())
        kind = try c.decode(NodeKind.self, forKey: .kind)
        frame = c.v(.frame, CGRect(x: 40, y: 40, width: 120, height: 60))
        name = c.v(.name, ""); stereotype = c.v(.stereotype, "")
        attrs = c.v(.attrs, []); ops = c.v(.ops, []); isAbstract = c.v(.isAbstract, false); doc = c.v(.doc, "")
        fill = c.v(.fill, nil as String?); stroke = c.v(.stroke, nil as String?); textColor = c.v(.textColor, nil as String?)
        fontSize = c.v(.fontSize, nil as Double?); props = c.v(.props, [:])
    }
}

extension Edge {
    enum CodingKeys: String, CodingKey { case id, kind, from, to, name, fromRole, toRole, fromMult, toMult, routing, points, y, stroke, width, doc }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: CodingKeys.self)
        id = c.v(.id, UUID())
        kind = try c.decode(EdgeKind.self, forKey: .kind)
        from = try c.decode(UUID.self, forKey: .from)
        to = try c.decode(UUID.self, forKey: .to)
        name = c.v(.name, ""); fromRole = c.v(.fromRole, ""); toRole = c.v(.toRole, "")
        fromMult = c.v(.fromMult, ""); toMult = c.v(.toMult, "")
        routing = c.v(.routing, .straight); points = c.v(.points, [])
        y = c.v(.y, nil as Double?); stroke = c.v(.stroke, nil as String?); width = c.v(.width, nil as Double?)
        doc = c.v(.doc, "")
    }
}

extension Diagram {
    enum CodingKeys: String, CodingKey { case id, name, type, nodes, edges, doc }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: CodingKeys.self)
        id = c.v(.id, UUID()); name = c.v(.name, "Diagram")
        type = try c.decode(DiagramType.self, forKey: .type)
        nodes = c.v(.nodes, []); edges = c.v(.edges, []); doc = c.v(.doc, "")
    }
}

extension Project {
    enum CodingKeys: String, CodingKey { case id, name, author, doc, diagrams, format }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: CodingKeys.self)
        id = c.v(.id, UUID()); name = c.v(.name, "Untitled Project"); author = c.v(.author, "")
        doc = c.v(.doc, ""); diagrams = c.v(.diagrams, []); format = c.v(.format, 1)
    }
}

// MARK: - UML text for members ("- name : String = 0", "+ total(qty: int) : double"); Java syntax is understood too

enum UMLText {
    static let modifiers: Set<String> = ["public", "private", "protected", "static", "final", "abstract", "default", "synchronized", "transient", "volatile", "native"]

    private static func prefix(_ s: inout String, _ m: inout Member) {
        s = s.trimmingCharacters(in: .whitespaces)
        if s.hasSuffix(";") { s.removeLast() }
        if let f = s.first, let v = Visibility(rawValue: String(f)) {
            m.vis = v
            s.removeFirst()
            s = s.trimmingCharacters(in: .whitespaces)
        }
        while true {
            let word = s.prefix { !$0.isWhitespace }
            let w = String(word)
            guard modifiers.contains(w) || w == "{static}" || w == "{abstract}" else { break }
            switch w {
            case "public": m.vis = .pub
            case "private": m.vis = .priv
            case "protected": m.vis = .prot
            case "static", "{static}": m.isStatic = true
            case "final": m.isFinal = true
            case "abstract", "{abstract}": m.isAbstract = true
            default: break
            }
            s = String(s.dropFirst(word.count)).trimmingCharacters(in: .whitespaces)
        }
    }

    static func attr(_ text: String, vis: Visibility = .priv) -> Member {
        var m = Member(vis: vis)
        var s = text
        prefix(&s, &m)
        if let eq = s.firstIndex(of: "=") {
            m.value = s[s.index(after: eq)...].trimmingCharacters(in: .whitespaces)
            s = String(s[..<eq])
        }
        s = s.trimmingCharacters(in: .whitespaces)
        if let colon = s.firstIndex(of: ":") {
            m.name = s[..<colon].trimmingCharacters(in: .whitespaces)
            m.type = s[s.index(after: colon)...].trimmingCharacters(in: .whitespaces)
        } else {
            let (t, n) = splitJava(s)
            m.name = n; m.type = t
        }
        return m
    }

    static func op(_ text: String, vis: Visibility = .pub) -> Member {
        var m = Member(vis: vis)
        var s = text
        if let brace = s.firstIndex(of: "{"), !s.hasPrefix("{") { s = String(s[..<brace]) }
        prefix(&s, &m)
        guard let open = s.firstIndex(of: "(") else {
            let (t, n) = splitJava(s)
            m.name = n; m.type = t
            return m
        }
        var depth = 0
        var close = s.endIndex
        for i in s.indices[open...] {
            if s[i] == "(" { depth += 1 }
            if s[i] == ")" { depth -= 1; if depth == 0 { close = i; break } }
        }
        let head = s[..<open].trimmingCharacters(in: .whitespaces)
        let inside = close == s.endIndex ? String(s[s.index(after: open)...]) : String(s[s.index(after: open)..<close])
        var tail = close == s.endIndex ? "" : s[s.index(after: close)...].trimmingCharacters(in: .whitespaces)
        if let t = tail.range(of: "throws") { tail = String(tail[..<t.lowerBound]).trimmingCharacters(in: .whitespaces) }
        let (t, n) = splitJava(head)
        m.name = n
        if tail.hasPrefix(":") {
            m.type = tail.dropFirst().trimmingCharacters(in: .whitespaces)
        } else {
            m.type = t
        }
        m.params = splitTop(inside).map { p -> String in
            let p = p.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: "final ", with: "")
            if p.contains(":") {
                let parts = p.split(separator: ":", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
                return parts.count == 2 ? "\(parts[0]): \(parts[1])" : p
            }
            let (pt, pn) = splitJava(p)
            return pt.isEmpty ? pn : "\(pn): \(pt)"
        }.filter { !$0.isEmpty }.joined(separator: ", ")
        return m
    }

    /// "List<Order> orders" -> ("List<Order>", "orders"); "orders" -> ("", "orders")
    static func splitJava(_ s: String) -> (String, String) {
        let s = s.trimmingCharacters(in: .whitespaces)
        var depth = 0
        var lastSpace: String.Index? = nil
        for i in s.indices {
            let c = s[i]
            if c == "<" { depth += 1 } else if c == ">" { depth -= 1 }
            else if c == " " && depth == 0 { lastSpace = i }
        }
        guard let sp = lastSpace else { return ("", s) }
        return (s[..<sp].trimmingCharacters(in: .whitespaces), s[s.index(after: sp)...].trimmingCharacters(in: .whitespaces))
    }

    /// splits on commas that are not inside <> or ()
    static func splitTop(_ s: String) -> [String] {
        var out: [String] = []
        var cur = ""
        var depth = 0
        for c in s {
            if c == "<" || c == "(" || c == "[" { depth += 1 }
            if c == ">" || c == ")" || c == "]" { depth -= 1 }
            if c == "," && depth == 0 { out.append(cur); cur = "" } else { cur.append(c) }
        }
        if !cur.trimmingCharacters(in: .whitespaces).isEmpty { out.append(cur) }
        return out.map { $0.trimmingCharacters(in: .whitespaces) }
    }

    /// "PK id : INTEGER", "FK customer_id : INTEGER NN", "email : VARCHAR(120) UQ"
    static func column(_ text: String) -> Member {
        var m = Member(vis: .pub)
        var words = text.split(separator: " ").map(String.init)
        var flags: Set<String> = []
        while let f = words.first, ["PK", "FK", "NN", "UQ"].contains(f) { flags.insert(f); words.removeFirst() }
        while let l = words.last, ["PK", "FK", "NN", "UQ"].contains(l) { flags.insert(l); words.removeLast() }
        var rest = words.joined(separator: " ")
        if let arrow = rest.range(of: "->") {
            m.ref = rest[arrow.upperBound...].trimmingCharacters(in: .whitespaces)
            rest = String(rest[..<arrow.lowerBound])
        }
        if let colon = rest.firstIndex(of: ":") {
            m.name = rest[..<colon].trimmingCharacters(in: .whitespaces)
            m.type = rest[rest.index(after: colon)...].trimmingCharacters(in: .whitespaces)
        } else {
            m.name = rest.trimmingCharacters(in: .whitespaces)
        }
        m.pk = flags.contains("PK"); m.fk = flags.contains("FK")
        m.unique = flags.contains("UQ"); m.nullable = !(flags.contains("NN") || m.pk)
        return m
    }

    static func attrLine(_ m: Member, kind: NodeKind) -> String {
        switch kind {
        case .enumeration: return m.name
        case .object: return m.value.isEmpty ? m.name : "\(m.name) = \(m.value)"
        default:
            var s = "\(m.vis.rawValue) \(m.name)"
            if !m.type.isEmpty { s += " : \(m.type)" }
            if !m.value.isEmpty { s += " = \(m.value)" }
            return s
        }
    }

    static func opLine(_ m: Member) -> String {
        var s = "\(m.vis.rawValue) \(m.name)(\(m.params))"
        if !m.type.isEmpty { s += " : \(m.type)" }
        return s
    }

    /// the text you edit (visibility is shown separately)
    static func attrEdit(_ m: Member, kind: NodeKind) -> String {
        switch kind {
        case .enumeration: return m.name
        case .object: return m.value.isEmpty ? m.name : "\(m.name) = \(m.value)"
        case .entity: return m.type.isEmpty ? m.name : "\(m.name) : \(m.type)"
        default:
            var s = m.name
            if !m.type.isEmpty { s += " : \(m.type)" }
            if !m.value.isEmpty { s += " = \(m.value)" }
            return s
        }
    }

    static func opEdit(_ m: Member) -> String {
        var s = "\(m.name)(\(m.params))"
        if !m.type.isEmpty { s += " : \(m.type)" }
        return s
    }

    /// parses edited text back into a member, keeping id and flags the text doesn't show
    static func apply(_ text: String, to old: Member, op: Bool, kind: NodeKind) -> Member {
        var m: Member
        switch kind {
        case .enumeration:
            m = old; m.name = text.trimmingCharacters(in: .whitespaces)
        case .object:
            m = old
            let parts = text.split(separator: "=", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            m.name = parts.first ?? ""
            m.value = parts.count > 1 ? parts[1] : ""
        case .entity:
            let c = column(text)
            m = old; m.name = c.name; m.type = c.type
            if text.contains("PK") || text.contains("FK") || text.contains("NN") || text.contains("UQ") {
                m.pk = c.pk; m.fk = c.fk; m.nullable = c.nullable; m.unique = c.unique
            }
        default:
            let parsed = op ? UMLText.op(text, vis: old.vis) : UMLText.attr(text, vis: old.vis)
            m = parsed
            m.id = old.id
            m.doc = old.doc
            // keywords typed in the text win, otherwise keep what was set before
            m.isStatic = parsed.isStatic || old.isStatic
            m.isFinal = parsed.isFinal || old.isFinal
            m.isAbstract = parsed.isAbstract || old.isAbstract
        }
        return m
    }
}

// MARK: - colours stored as hex strings

extension NSColor {
    convenience init(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        let v = UInt32(s, radix: 16) ?? 0
        self.init(srgbRed: CGFloat((v >> 16) & 255) / 255, green: CGFloat((v >> 8) & 255) / 255, blue: CGFloat(v & 255) / 255, alpha: 1)
    }
    convenience init(rgb v: UInt32, alpha: CGFloat = 1) {
        self.init(srgbRed: CGFloat((v >> 16) & 255) / 255, green: CGFloat((v >> 8) & 255) / 255, blue: CGFloat(v & 255) / 255, alpha: alpha)
    }
    var hex: String {
        let c = usingColorSpace(.sRGB) ?? self
        return String(format: "#%02X%02X%02X", Int(round(c.redComponent * 255)), Int(round(c.greenComponent * 255)), Int(round(c.blueComponent * 255)))
    }
    var luminance: CGFloat {
        let c = usingColorSpace(.sRGB) ?? self
        return 0.299 * c.redComponent + 0.587 * c.greenComponent + 0.114 * c.blueComponent
    }
}

extension String {
    var lowerFirst: String { isEmpty ? self : prefix(1).lowercased() + dropFirst() }
    var upperFirst: String { isEmpty ? self : prefix(1).uppercased() + dropFirst() }
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
    /// "customer_id" -> "customerId", "Order Line" -> "orderLine"
    var camel: String {
        let parts = split { $0 == "_" || $0 == " " || $0 == "-" }.map(String.init)
        guard let first = parts.first else { return self }
        return first.lowerFirst + parts.dropFirst().map { $0.lowercased().upperFirst }.joined()
    }
    var pascal: String { camel.upperFirst }
    var xmlEscaped: String {
        replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;")
    }
}

extension CGRect {
    var center: CGPoint { CGPoint(x: midX, y: midY) }
}

extension CGPoint {
    static func + (a: CGPoint, b: CGPoint) -> CGPoint { CGPoint(x: a.x + b.x, y: a.y + b.y) }
    static func - (a: CGPoint, b: CGPoint) -> CGPoint { CGPoint(x: a.x - b.x, y: a.y - b.y) }
    static func * (a: CGPoint, k: CGFloat) -> CGPoint { CGPoint(x: a.x * k, y: a.y * k) }
    var length: CGFloat { sqrt(x * x + y * y) }
    var unit: CGPoint { let l = length; return l < 0.0001 ? CGPoint(x: 1, y: 0) : CGPoint(x: x / l, y: y / l) }
    var perp: CGPoint { CGPoint(x: -y, y: x) }
    func dist(_ o: CGPoint) -> CGFloat { (self - o).length }
}

extension Substring {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
