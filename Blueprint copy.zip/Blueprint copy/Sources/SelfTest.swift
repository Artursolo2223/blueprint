import AppKit
import SwiftUI

/// BP_SELFTEST=<folder> runs the app headless: renders every diagram type, generates and parses code,
/// drives the canvas with synthesized events and writes pictures plus a log. Nothing is shown on screen.
enum SelfTest {
    static var log = ""
    static var failures = 0

    static func say(_ s: String) { log += s + "\n" }
    static func check(_ ok: Bool, _ what: String) {
        say((ok ? "PASS " : "FAIL ") + what)
        if !ok { failures += 1 }
    }

    static func write(_ data: Data?, _ url: URL) {
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try? data?.write(to: url)
    }

    static func run(_ dir: String) {
        let out = URL(fileURLWithPath: dir)
        try? FileManager.default.createDirectory(at: out, withIntermediateDirectories: true)

        // 1. every example renders and is (mostly) valid
        for t in DiagramType.allCases {
            let d = Samples.make(t)
            write(Exporter.png(d), out.appendingPathComponent("sample-\(t.rawValue).png"))
            var laid = d
            Layout.apply(&laid, LayoutStyle.preferred(t))
            write(Exporter.png(laid), out.appendingPathComponent("layout-\(t.rawValue).png"))
            let issues = Validator.run(Project(diagrams: [d]))
            say("\(t.rawValue): \(d.nodes.count) nodes, \(d.edges.count) edges")
            for i in issues { say("    [\(i.level)] \(i.text)") }
        }
        write(Exporter.png(Samples.shopClasses(), scale: 2, dark: true), out.appendingPathComponent("dark-class.png"))
        write(Exporter.svg(Samples.shopClasses()).data(using: .utf8), out.appendingPathComponent("class.svg"))
        write(Exporter.pdf(DiagramType.allCases.map { Samples.make($0) }), out.appendingPathComponent("all.pdf"))
        write(Exporter.report(Samples.starterProject()).data(using: .utf8), out.appendingPathComponent("report.html"))

        // 2. Java generation for the examples and every lesson
        var p = Project(diagrams: [Samples.shopClasses(), Samples.packages()])
        p.diagrams += Lessons.all.map { $0.build() }.filter { $0.type == .classDiagram || $0.type == .package }
        var opts = JavaOptions()
        opts.allDiagrams = true
        var javaDirs: [URL] = []
        for (i, d) in p.diagrams.enumerated() {
            let files = JavaGen.generate(Project(diagrams: [d]), current: d, opts)
            let base = out.appendingPathComponent("java/\(i)")
            javaDirs.append(base)
            for f in files { write(f.code.data(using: .utf8), base.appendingPathComponent(f.path)) }
        }
        let erd = Samples.shopDatabase()
        let jpa = SQLGen.jpa(erd.nodes.map { ($0, erd) }, explain: true)
        for f in jpa { write(f.code.data(using: .utf8), out.appendingPathComponent("jpa/\(f.path)")) }
        write(SQLGen.ddl(erd.nodes.map { ($0, erd) }, .postgres, title: "shop").data(using: .utf8), out.appendingPathComponent("shop.sql"))
        write(StateGen.java(Samples.orderStates()).data(using: .utf8), out.appendingPathComponent("state/OrderLifecycle.java"))
        write(SequenceGen.java(Samples.placeOrder()).data(using: .utf8), out.appendingPathComponent("sequence.txt"))
        say("java dirs: \(javaDirs.count)")

        // 3. reverse engineering
        let (rj, nj) = JavaParser.diagram(from: ReverseSamples.java, name: "rev")
        check(nj == 6, "reverse Java finds 6 types (got \(nj))")
        say("  reverse edges: " + rj.edges.map { e in "\(rj.node(e.from)?.name ?? "?") -\(e.kind.rawValue)-> \(rj.node(e.to)?.name ?? "?") \(e.toRole)" }.joined(separator: ", "))
        write(Exporter.png(rj), out.appendingPathComponent("reverse-java.png"))
        let gen = JavaGen.generate(Project(diagrams: [Samples.shopClasses()]), current: nil, opts).map(\.code).joined(separator: "\n")
        let (round, nr) = JavaParser.diagram(from: gen, name: "round")
        check(nr == 9, "round trip: generated Java parses back into 9 types (got \(nr): \(round.nodes.map(\.name)))")
        write(Exporter.png(round), out.appendingPathComponent("roundtrip.png"))
        let (rs, ns) = SQLParse.parse(ReverseSamples.sql, name: "rev sql")
        check(ns == 4 && rs.edges.count == 3, "reverse SQL finds 4 tables and 3 relationships (got \(ns), \(rs.edges.count))")
        write(Exporter.png(rs), out.appendingPathComponent("reverse-sql.png"))
        let ddl = SQLGen.ddl(erd.nodes.map { ($0, erd) }, .standard, title: "x")
        let (back, nb) = SQLParse.parse(ddl, name: "back")
        check(nb == 4 && back.edges.count == 3, "SQL round trip keeps 4 tables and 3 relationships (got \(nb), \(back.edges.count))")

        // 4. member text parsing
        let a = UMLText.attr("- static count : int = 0")
        check(a.vis == .priv && a.isStatic && a.name == "count" && a.type == "int" && a.value == "0", "parse UML attribute")
        let j = UMLText.attr("private List<Order> orders = new ArrayList<>();")
        check(j.name == "orders" && j.type == "List<Order>", "parse Java field (\(j.name) / \(j.type))")
        let o = UMLText.op("+ total(qty: int, price: double) : double")
        check(o.name == "total" && o.params == "qty: int, price: double" && o.type == "double", "parse UML operation")
        let jo = UMLText.op("public static Map<String, Integer> count(List<String> words, int min)")
        check(jo.isStatic && jo.name == "count" && jo.type == "Map<String, Integer>" && jo.params == "words: List<String>, min: int", "parse Java method (\(jo.type) \(jo.params))")

        // 5. canvas interaction with synthesized events
        interactions(out)

        // 6. the whole window, rendered offscreen
        windowShot(out)

        say(failures == 0 ? "ALL PASSED" : "\(failures) FAILED")
        try? log.write(to: out.appendingPathComponent("log.txt"), atomically: true, encoding: .utf8)
        NSApp.terminate(nil)
    }

    static func interactions(_ out: URL) {
        let s = Store(project: Project())
        s.newDiagram(.classDiagram, example: false)
        let win = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1100, height: 760), styleMask: [.titled, .resizable], backing: .buffered, defer: false)
        let sv = CanvasHost.makeScrollView(s)
        win.contentView = sv
        guard let c = s.canvas else { check(false, "canvas exists"); return }
        c.updateSize()
        let wn = win.windowNumber

        func ev(_ type: NSEvent.EventType, _ p: CGPoint, clicks: Int = 1, flags: NSEvent.ModifierFlags = []) -> NSEvent {
            NSEvent.mouseEvent(with: type, location: c.convert(p, to: nil), modifierFlags: flags, timestamp: ProcessInfo.processInfo.systemUptime,
                               windowNumber: wn, context: nil, eventNumber: 0, clickCount: clicks, pressure: 1)!
        }
        func click(_ p: CGPoint, clicks: Int = 1, flags: NSEvent.ModifierFlags = []) {
            c.mouseDown(with: ev(.leftMouseDown, p, clicks: clicks, flags: flags))
            c.mouseUp(with: ev(.leftMouseUp, p, clicks: clicks, flags: flags))
        }
        func drag(_ a: CGPoint, _ b: CGPoint, flags: NSEvent.ModifierFlags = []) {
            c.mouseDown(with: ev(.leftMouseDown, a, flags: flags))
            for i in 1...6 {
                let t = CGFloat(i) / 6
                c.mouseDragged(with: ev(.leftMouseDragged, CGPoint(x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t), flags: flags))
            }
            c.mouseUp(with: ev(.leftMouseUp, b, flags: flags))
        }
        func key(_ code: UInt16, _ chars: String, flags: NSEvent.ModifierFlags = []) {
            let e = NSEvent.keyEvent(with: .keyDown, location: .zero, modifierFlags: flags, timestamp: 0, windowNumber: wn, context: nil,
                                     characters: chars, charactersIgnoringModifiers: chars, isARepeat: false, keyCode: code)!
            c.keyDown(with: e)
        }
        func type(_ text: String) {
            c.editor?.stringValue = text
            c.commitEditing()
        }
        func pump() { RunLoop.main.run(until: Date().addingTimeInterval(0.05)) }

        // place two classes with the tool and name them
        s.tool = .node(.klass)
        click(CGPoint(x: 200, y: 150))
        pump()
        check(c.editor != nil, "placing a class starts editing its name")
        type("Customer")
        s.tool = .node(.klass)
        click(CGPoint(x: 560, y: 150))
        pump()
        type("Order")
        var d = s.diagram!
        check(d.nodes.map(\.name) == ["Customer", "Order"], "two classes named (got \(d.nodes.map(\.name)))")
        let cust = d.nodes[0], order = d.nodes[1]

        // connect them with the association tool
        s.tool = .edge(.association)
        drag(cust.frame.center, order.frame.center)
        d = s.diagram!
        check(d.edges.count == 1 && d.edges[0].kind == .association, "association drawn with the tool")

        // connect with the round handle: Order -> new class via handle onto Customer gives a second edge
        s.selection = [order.id]
        let h = c.connectorHandleCenter(order)
        drag(h, cust.frame.center)
        d = s.diagram!
        check(d.edges.count == 2, "connector handle creates an edge (edges: \(d.edges.count))")

        // attributes with the keyboard shortcut and the inline editor
        s.selection = [cust.id]
        key(0, "Å", flags: [.option, .shift])
        pump()
        check(c.editor != nil, "⌥⇧A starts editing a new attribute")
        type("- name : String")
        s.addMember(op: true)
        pump()
        type("+ placeOrder(cart: Cart) : Order")
        d = s.diagram!
        let cu = d.node(cust.id)!
        check(cu.attrs.map(\.name) == ["name"] && cu.attrs.first?.type == "String", "attribute added (\(cu.attrs.map { $0.name + ":" + $0.type }))")
        check(cu.ops.first?.name == "placeOrder" && cu.ops.first?.params == "cart: Cart", "operation added")
        check(cu.frame.height > 60, "class grew to fit its members (\(cu.frame.height))")

        // double-click a member row edits it
        let L = ClassLayout.of(cu)
        click(CGPoint(x: cu.frame.minX + 30, y: cu.frame.minY + L.attrTop + 10), clicks: 2)
        pump()
        check(c.editor?.stringValue == "- name : String", "double-click edits the attribute row (\(c.editor?.stringValue ?? "nil"))")
        type("# fullName : String")
        check(s.node(cust.id)!.attrs.first?.vis == .prot && s.node(cust.id)!.attrs.first?.name == "fullName", "row edit applied")

        // move with snapping
        s.selection = []
        let before = s.node(order.id)!.frame
        drag(CGPoint(x: before.midX, y: before.minY + 10), CGPoint(x: before.midX + 103, y: before.minY + 57))
        let after = s.node(order.id)!.frame
        check(after.minX != before.minX && Int(after.minX) % 10 == 0 && Int(after.minY) % 10 == 0, "drag moves and snaps to the grid (\(before.origin) -> \(after.origin))")

        // resize the width with the right handle
        s.selection = [order.id]
        let o2 = s.node(order.id)!
        drag(CGPoint(x: o2.frame.maxX, y: o2.frame.midY), CGPoint(x: o2.frame.maxX + 80, y: o2.frame.midY))
        check(s.node(order.id)!.frame.width >= o2.frame.width + 70, "resize handle widens the class")

        // undo and redo
        let w1 = s.node(order.id)!.frame.width
        s.undo()
        check(s.node(order.id)!.frame.width < w1, "undo restores the width")
        s.redo()
        check(s.node(order.id)!.frame.width == w1, "redo re-applies it")

        // marquee selects both
        s.selection = []
        drag(CGPoint(x: 5, y: 5), CGPoint(x: 1050, y: 700))
        check(s.selection.count == 4, "marquee selects shapes and connectors (\(s.selection.count))")

        // duplicate, delete
        s.selection = [cust.id]
        s.duplicate()
        check(s.diagram!.nodes.count == 3, "duplicate")
        key(51, "\u{7f}")
        check(s.diagram!.nodes.count == 2, "backspace deletes")

        // generalization shows up as extends in Java
        s.tool = .node(.klass)
        click(CGPoint(x: 560, y: 450))
        pump()
        type("VipOrder")
        let vip = s.diagram!.nodes.last!
        s.tool = .edge(.generalization)
        drag(vip.frame.center, s.node(order.id)!.frame.center)
        let javaVip = JavaGen.file(for: vip.id, in: s.project, JavaOptions())?.code ?? ""
        check(javaVip.contains("public class VipOrder extends Order"), "generalization becomes extends")
        let javaCust = JavaGen.file(for: cust.id, in: s.project, JavaOptions())?.code ?? ""
        check(javaCust.contains("protected String fullName;") && javaCust.contains("public Order placeOrder(Cart cart)"), "class code has the members")
        snapshot(sv, out.appendingPathComponent("interact-class.png"))

        // sequence: dragging down a lifeline makes a message
        s.newDiagram(.sequence, example: false)
        s.tool = .node(.lifeline)
        click(CGPoint(x: 150, y: 100))
        pump()
        type("a : Shop")
        s.tool = .node(.lifeline)
        click(CGPoint(x: 400, y: 100))
        pump()
        type("b : Bank")
        d = s.diagram!
        check(d.nodes.count == 2 && d.nodes[0].prop("classifier") == "Shop" && d.nodes[0].name == "a", "lifeline name and class parsed")
        check(d.nodes[0].frame.minY == d.nodes[1].frame.minY, "second lifeline lines up with the first")
        let l1 = d.nodes[0], l2 = d.nodes[1]
        drag(CGPoint(x: l1.frame.midX, y: 220), CGPoint(x: l2.frame.midX, y: 224))
        d = s.diagram!
        check(d.edges.count == 1 && d.edges[0].kind == .message && abs((d.edges[0].y ?? 0) - 220) < 1, "message drawn between lifelines at the drag height")
        drag(CGPoint(x: l2.frame.midX, y: 270), CGPoint(x: l1.frame.midX, y: 270))
        s.updateEdge(s.diagram!.edges[1].id) { $0.kind = .reply; $0.name = "ok" }
        snapshot(sv, out.appendingPathComponent("interact-sequence.png"))

        // mind map: Tab adds a child, Return a sibling
        s.newDiagram(.mindMap, example: false)
        s.tool = .node(.central)
        click(CGPoint(x: 400, y: 300))
        pump()
        type("Java")
        key(48, "\t")
        pump()
        type("Syntax")
        key(36, "\r")
        pump()
        type("Tools")
        d = s.diagram!
        check(d.nodes.count == 3 && d.edges.count == 2, "mind map Tab and Return add topics (\(d.nodes.count) / \(d.edges.count))")
        snapshot(sv, out.appendingPathComponent("interact-mind.png"))

        // ER: a relationship adds the foreign key column
        s.newDiagram(.erd, example: false)
        s.tool = .node(.entity)
        click(CGPoint(x: 200, y: 150))
        pump()
        type("author")
        s.tool = .node(.entity)
        click(CGPoint(x: 550, y: 150))
        pump()
        type("book")
        d = s.diagram!
        s.tool = .edge(.relationship)
        drag(d.nodes[0].frame.center, d.nodes[1].frame.center)
        let book = s.diagram!.nodes[1]
        check(book.attrs.contains { $0.name == "author_id" && $0.fk && $0.ref == "author.id" }, "relationship adds author_id foreign key")
        snapshot(sv, out.appendingPathComponent("interact-erd.png"))

        // save and open again
        let file = out.appendingPathComponent("test.blueprint")
        s.fileURL = file
        check(s.save(), "save to file")
        if let loaded = try? Store.load(file) { check(loaded == s.project, "file opens again unchanged") } else { check(false, "file opens again") }

        // zoom
        c.setZoom(2)
        check(abs(c.mag - 2) < 0.01, "zoom to 200%")
        c.zoomToFit()
        check(c.mag > 0.1 && c.mag <= 1.25, "zoom to fit (\(c.mag))")
    }

    static func snapshot(_ v: NSView, _ url: URL) {
        v.layoutSubtreeIfNeeded()
        (v as? NSScrollView)?.documentView?.needsDisplay = true
        guard let rep = v.bitmapImageRepForCachingDisplay(in: v.bounds) else { return }
        v.cacheDisplay(in: v.bounds, to: rep)
        write(rep.representation(using: .png, properties: [:]), url)
    }

    static func windowShot(_ out: URL) {
        for (name, dark) in [("window-dark", true), ("window-light", false)] {
            let s = Store(project: Samples.starterProject())
            let win = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1440, height: 900), styleMask: [.titled, .fullSizeContentView], backing: .buffered, defer: false)
            win.appearance = NSAppearance(named: dark ? .darkAqua : .aqua)
            let host = NSHostingView(rootView: RootView(s: s))
            win.contentView = host
            RunLoop.main.run(until: Date().addingTimeInterval(0.6))
            if let first = s.project.diagrams.first { s.selection = [first.nodes[1].id] }
            RunLoop.main.run(until: Date().addingTimeInterval(0.6))
            snapshot(host, out.appendingPathComponent("\(name).png"))
        }
    }
}
