import AppKit
import UniformTypeIdentifiers

enum ExportFormat { case png, pdf, svg }

enum Exporter {
    static func drawing(_ d: Diagram, margin: CGFloat = 24) -> CGRect {
        let b = d.contentBounds
        return b.isNull ? CGRect(x: 0, y: 0, width: 240, height: 120) : b.insetBy(dx: -margin, dy: -margin).integral
    }

    static func render(_ d: Diagram, into ctx: CGContext, bounds b: CGRect, pal: Palette, background: Bool = true) {
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = NSGraphicsContext(cgContext: ctx, flipped: true)
        if background {
            ctx.setFillColor(pal.paper.cgColor)
            ctx.fill(b)
        }
        Renderer(d, pal, CGPainter(ctx)).drawAll()
        NSGraphicsContext.restoreGraphicsState()
    }

    static func png(_ d: Diagram, scale: CGFloat = 2, dark: Bool = false) -> Data? {
        let b = drawing(d)
        let w = Int(ceil(b.width * scale)), h = Int(ceil(b.height * scale))
        guard w > 0, h > 0, w < 30000, h < 30000,
              let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpace(name: CGColorSpace.sRGB)!, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        ctx.translateBy(x: 0, y: CGFloat(h))
        ctx.scaleBy(x: scale, y: -scale)
        ctx.translateBy(x: -b.minX, y: -b.minY)
        render(d, into: ctx, bounds: b, pal: dark ? .dark : .light)
        guard let img = ctx.makeImage() else { return nil }
        return NSBitmapImageRep(cgImage: img).representation(using: .png, properties: [:])
    }

    /// one page per diagram
    static func pdf(_ diagrams: [Diagram]) -> Data {
        let data = NSMutableData()
        guard let consumer = CGDataConsumer(data: data as CFMutableData) else { return Data() }
        var box = CGRect(x: 0, y: 0, width: 612, height: 792)
        guard let ctx = CGContext(consumer: consumer, mediaBox: &box, nil) else { return Data() }
        for d in diagrams {
            let b = drawing(d)
            var page = CGRect(origin: .zero, size: b.size)
            let info = [kCGPDFContextMediaBox as String: NSData(bytes: &page, length: MemoryLayout<CGRect>.size)] as CFDictionary
            ctx.beginPDFPage(info)
            ctx.saveGState()
            ctx.translateBy(x: 0, y: b.height)
            ctx.scaleBy(x: 1, y: -1)
            ctx.translateBy(x: -b.minX, y: -b.minY)
            render(d, into: ctx, bounds: b, pal: .light)
            ctx.restoreGState()
            ctx.endPDFPage()
        }
        ctx.closePDF()
        return data as Data
    }

    static func pdf(_ d: Diagram) -> Data { pdf([d]) }

    static func svg(_ d: Diagram) -> String {
        let b = drawing(d)
        let p = SVGPainter()
        p.fill(CGPath(rect: b, transform: nil), Palette.light.paper)
        Renderer(d, .light, p).drawAll()
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"\(Int(b.minX)) \(Int(b.minY)) \(Int(b.width)) \(Int(b.height))\" width=\"\(Int(b.width))\" height=\"\(Int(b.height))\">\n"
            + p.out + "</svg>\n"
    }

    /// picture of a diagram that fits a size (lessons, start page)
    static func image(_ d: Diagram, fit: CGSize, dark: Bool) -> NSImage {
        let b = drawing(d, margin: 14)
        let scale = min(fit.width / b.width, fit.height / b.height, 1.1)
        let size = NSSize(width: max(1, b.width * scale), height: max(1, b.height * scale))
        return NSImage(size: size, flipped: true) { _ in
            guard let ctx = NSGraphicsContext.current?.cgContext else { return false }
            ctx.scaleBy(x: scale, y: scale)
            ctx.translateBy(x: -b.minX, y: -b.minY)
            Renderer(d, dark ? .dark : .light, CGPainter(ctx)).drawAll()
            return true
        }
    }

    static func savePanel(_ name: String, _ ext: String) -> URL? {
        let p = NSSavePanel()
        p.nameFieldStringValue = name.replacingOccurrences(of: "/", with: "-") + "." + ext
        p.allowedContentTypes = [UTType(filenameExtension: ext) ?? .data]
        p.canCreateDirectories = true
        return p.runModal() == .OK ? p.url : nil
    }

    static func exportCurrent(_ s: Store, _ f: ExportFormat) {
        guard let d = s.diagram else { s.flash("Open a diagram first"); return }
        let ext = f == .png ? "png" : f == .pdf ? "pdf" : "svg"
        guard let url = savePanel(d.name, ext) else { return }
        let data: Data?
        switch f {
        case .png: data = png(d)
        case .pdf: data = pdf(d)
        case .svg: data = svg(d).data(using: .utf8)
        }
        do {
            try data?.write(to: url)
            s.flash("Exported \(url.lastPathComponent)")
        } catch { NSAlert(error: error).runModal() }
    }

    static func exportAllPDF(_ s: Store) {
        guard !s.project.diagrams.isEmpty else { s.flash("The project has no diagrams yet"); return }
        guard let url = savePanel(s.title, "pdf") else { return }
        do {
            try pdf(s.project.diagrams).write(to: url)
            s.flash("Exported \(s.project.diagrams.count) diagrams to \(url.lastPathComponent)")
        } catch { NSAlert(error: error).runModal() }
    }

    static func copyImage(_ s: Store) {
        guard let d = s.diagram else { return }
        let pb = NSPasteboard.general
        pb.clearContents()
        if let p = png(d) { pb.setData(p, forType: .png) }
        pb.setData(pdf(d), forType: .pdf)
        s.flash("Diagram copied as a picture")
    }

    // MARK: printing

    final class PrintView: NSView {
        let d: Diagram
        let b: CGRect
        init(_ d: Diagram) {
            self.d = d
            b = Exporter.drawing(d)
            super.init(frame: CGRect(origin: .zero, size: b.size))
        }
        required init?(coder: NSCoder) { fatalError() }
        override var isFlipped: Bool { true }
        override func draw(_ r: NSRect) {
            guard let ctx = NSGraphicsContext.current?.cgContext else { return }
            ctx.translateBy(x: -b.minX, y: -b.minY)
            Renderer(d, .light, CGPainter(ctx)).drawAll()
        }
    }

    static func printDiagram(_ s: Store) {
        guard let d = s.diagram else { s.flash("Open a diagram first"); return }
        let v = PrintView(d)
        let info = (NSPrintInfo.shared.copy() as? NSPrintInfo) ?? NSPrintInfo()
        info.horizontalPagination = .fit
        info.verticalPagination = .fit
        info.isHorizontallyCentered = true
        info.isVerticallyCentered = true
        info.orientation = v.frame.width > v.frame.height ? .landscape : .portrait
        let op = NSPrintOperation(view: v, printInfo: info)
        op.jobTitle = d.name
        if let w = s.window { op.runModal(for: w, delegate: nil, didRun: nil, contextInfo: nil) } else { op.run() }
    }

    // MARK: HTML report

    static func report(_ p: Project) -> String {
        let date = DateFormatter.localizedString(from: Date(), dateStyle: .long, timeStyle: .short)
        var h = """
        <!doctype html><html><head><meta charset="utf-8"><title>\(p.name.xmlEscaped)</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
        :root { --ink:#1f2329; --muted:#6b7280; --line:#e3e6eb; --accent:#2f7bf6; --card:#fff; --bg:#f6f7f9; }
        body { font: 15px/1.55 -apple-system, Helvetica Neue, Arial, sans-serif; color: var(--ink); background: var(--bg); margin: 0; }
        main { max-width: 1100px; margin: 0 auto; padding: 40px 24px 80px; }
        h1 { font-size: 34px; margin: 0 0 4px; } h2 { margin: 48px 0 6px; font-size: 24px; }
        .muted { color: var(--muted); } .card { background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 18px; margin: 14px 0; overflow: auto; }
        .card svg { max-width: 100%; height: auto; } table { border-collapse: collapse; width: 100%; font-size: 14px; }
        th, td { text-align: left; padding: 7px 10px; border-bottom: 1px solid var(--line); vertical-align: top; }
        th { color: var(--muted); font-weight: 600; } code { font: 13px SF Mono, Menlo, monospace; }
        .pill { display: inline-block; padding: 2px 10px; border-radius: 99px; background: #e8f0fe; color: var(--accent); font-size: 12px; font-weight: 600; }
        ul.toc { columns: 2; } a { color: var(--accent); text-decoration: none; }
        </style></head><body><main>
        <h1>\(p.name.xmlEscaped)</h1>
        <div class="muted">\(p.author.isEmpty ? "" : "By \(p.author.xmlEscaped) · ")Generated \(date) · \(p.diagrams.count) diagrams</div>
        """
        if !p.doc.isEmpty { h += "<p>\(p.doc.xmlEscaped)</p>" }
        h += "<h2>Contents</h2><ul class=\"toc\">"
        for (i, d) in p.diagrams.enumerated() { h += "<li><a href=\"#d\(i)\">\(d.name.xmlEscaped)</a> <span class=\"muted\">\(d.type.short)</span></li>" }
        h += "</ul>"
        for (i, d) in p.diagrams.enumerated() {
            h += "<h2 id=\"d\(i)\">\(d.name.xmlEscaped)</h2><span class=\"pill\">\(d.type.title)</span>"
            if !d.doc.isEmpty { h += "<p>\(d.doc.xmlEscaped)</p>" }
            h += "<div class=\"card\">\(svg(d))</div>"
            let named = d.nodes.filter { !$0.name.trimmed.isEmpty && !$0.kind.isNoteLike }
            if !named.isEmpty {
                h += "<div class=\"card\"><table><tr><th>Element</th><th>Type</th><th>Details</th><th>Documentation</th></tr>"
                for n in named {
                    var det = ""
                    if n.kind.isClassifier {
                        det = (n.attrs.map { UMLText.attrLine($0, kind: n.kind) } + n.ops.map { UMLText.opLine($0) }).map { "<code>\($0.xmlEscaped)</code>" }.joined(separator: "<br>")
                    } else if n.kind == .entity {
                        det = n.attrs.map { "<code>\(($0.pk ? "PK " : "") + ($0.fk ? "FK " : "") + $0.name) \($0.type)</code>".replacingOccurrences(of: "&", with: "&amp;") }.joined(separator: "<br>")
                    } else if n.kind == .state {
                        det = ["entry", "do", "exit"].filter { !n.prop($0).isEmpty }.map { "\($0) / \(n.prop($0).xmlEscaped)" }.joined(separator: "<br>")
                    }
                    h += "<tr><td><b>\(n.name.xmlEscaped)</b></td><td>\(n.kind.title)</td><td>\(det)</td><td>\(n.doc.xmlEscaped)</td></tr>"
                }
                h += "</table></div>"
            }
            let names = Dictionary(uniqueKeysWithValues: d.nodes.map { ($0.id, $0.name.isEmpty ? $0.kind.title : $0.name) })
            let rels = d.edges.filter { $0.kind != .anchor }
            if !rels.isEmpty {
                h += "<div class=\"card\"><table><tr><th>From</th><th>Relationship</th><th>To</th><th>Label</th></tr>"
                for e in rels {
                    let mult = [e.fromMult, e.toMult].contains { !$0.isEmpty } ? " (\(e.fromMult.isEmpty ? "–" : e.fromMult) : \(e.toMult.isEmpty ? "–" : e.toMult))" : ""
                    h += "<tr><td>\((names[e.from] ?? "?").xmlEscaped)</td><td>\(e.kind.title)\(mult)</td><td>\((names[e.to] ?? "?").xmlEscaped)</td><td>\(e.name.xmlEscaped)</td></tr>"
                }
                h += "</table></div>"
            }
        }
        h += "</main></body></html>"
        return h
    }

    static func exportReport(_ s: Store) {
        guard !s.project.diagrams.isEmpty else { s.flash("The project has no diagrams yet"); return }
        guard let url = savePanel(s.title + " report", "html") else { return }
        do {
            try report(s.project).write(to: url, atomically: true, encoding: .utf8)
            NSWorkspace.shared.open(url)
        } catch { NSAlert(error: error).runModal() }
    }
}

// MARK: - toolbox pictures, drawn with the real renderer

enum Thumbs {
    private static var cache: [String: NSImage] = [:]

    static func sampleSize(_ k: NodeKind) -> CGSize {
        switch k {
        case .lifeline: return CGSize(width: 90, height: 120)
        case .actorLifeline: return CGSize(width: 80, height: 130)
        case .lane: return CGSize(width: 100, height: 130)
        case .pool: return CGSize(width: 200, height: 90)
        case .boundary: return CGSize(width: 110, height: 130)
        case .fragment: return CGSize(width: 150, height: 100)
        case .package: return CGSize(width: 130, height: 100)
        case .node3d, .device: return CGSize(width: 130, height: 100)
        case .execEnv: return CGSize(width: 130, height: 90)
        case .fork: return CGSize(width: 100, height: 10)
        case .klass, .interface, .enumeration, .entity, .object: return CGSize(width: 110, height: 90)
        default: return k.info.size
        }
    }

    static func node(_ k: NodeKind, _ dark: Bool, size: CGFloat = 34) -> NSImage {
        let key = "\(k.rawValue)-\(dark)-\(size)"
        if let i = cache[key] { return i }
        var n = Node(kind: k, frame: CGRect(origin: CGPoint(x: 10, y: 10), size: sampleSize(k)), name: "")
        if k == .fragment { n.props["operator"] = "loop" }
        if k == .history { n.name = "" }
        if k == .klass || k == .interface || k == .enumeration || k == .entity || k == .object {
            n.frame.size = CGSize(width: 110, height: 90)
        }
        let d = Diagram(name: "", type: .classDiagram, nodes: [n])
        let img = NSImage(size: NSSize(width: size, height: size), flipped: true) { r in
            guard let ctx = NSGraphicsContext.current?.cgContext else { return false }
            let b = n.frame.insetBy(dx: -3, dy: -3)
            let scale = min(r.width / b.width, r.height / b.height)
            ctx.translateBy(x: r.midX - b.midX * scale, y: r.midY - b.midY * scale)
            ctx.scaleBy(x: scale, y: scale)
            Renderer(d, dark ? .dark : .light, ShapesOnlyPainter(CGPainter(ctx))).drawAll()
            return true
        }
        cache[key] = img
        return img
    }

    static func edge(_ k: EdgeKind, _ dark: Bool, size: CGFloat = 34) -> NSImage {
        let key = "e-\(k.rawValue)-\(dark)-\(size)"
        if let i = cache[key] { return i }
        let img = NSImage(size: NSSize(width: size, height: size), flipped: true) { r in
            guard let ctx = NSGraphicsContext.current?.cgContext else { return false }
            let pal: Palette = dark ? .dark : .light
            let rr = Renderer(Diagram(name: "", type: .classDiagram), pal, CGPainter(ctx))
            let a = CGPoint(x: r.minX + 5, y: r.maxY - 7), b = CGPoint(x: r.maxX - 5, y: r.minY + 7)
            let route = Route(pts: [a, b])
            let st = k.style
            let col = (k == .anchor || k == .bpmnAssoc) ? pal.muted : pal.ink
            ctx.setLineWidth(1.3)
            rr.p.stroke(route.cgPath, col, k == .branch ? 2.5 : 1.3, dash: rr.dash(st.line).map { $0 * 0.7 })
            if k == .relationship {
                rr.crowFoot("1", at: a, dir: route.startDir, col)
                rr.crowFoot("0..*", at: b, dir: route.endDir, col)
            } else {
                rr.marker(st.start, at: a, dir: route.startDir, col)
                rr.marker(st.end, at: b, dir: route.endDir, col)
            }
            return true
        }
        cache[key] = img
        return img
    }
}
