import SwiftUI
import AppKit

struct RootView: View {
    @ObservedObject var s: Store

    var body: some View {
        VStack(spacing: 8) {
            TopBar(s: s)
            HStack(spacing: 10) {
                if s.showSidebar {
                    Sidebar(s: s)
                        .frame(width: 244)
                        .transition(.move(edge: .leading).combined(with: .opacity))
                }
                CanvasArea(s: s)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                if s.showInspector {
                    Inspector(s: s)
                        .frame(width: 296)
                        .transition(.move(edge: .trailing).combined(with: .opacity))
                }
            }
            StatusBar(s: s)
        }
        .padding(.horizontal, 12)
        .padding(.top, 5)
        .padding(.bottom, 7)
        .background(AppBackground())
        .ignoresSafeArea(edges: .top)
        .frame(minWidth: 1080, minHeight: 660)
        .sheet(item: $s.sheet) { k in SheetHost(kind: k, s: s) }
        .animation(.easeOut(duration: 0.18), value: s.showSidebar)
        .animation(.easeOut(duration: 0.18), value: s.showInspector)
    }
}

// MARK: - top bar

struct TopBar: View {
    @ObservedObject var s: Store

    var body: some View {
        HStack(spacing: 8) {
            HStack(spacing: 7) {
                LogoMark().frame(width: 18, height: 18)
                Text(s.title).font(.system(size: 13, weight: .semibold)).lineLimit(1)
                if s.dirty { Circle().fill(T.orange).frame(width: 6, height: 6).help("Unsaved changes") }
            }
            .padding(.leading, 78)
            .fixedSize()

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(s.tabs, id: \.self) { id in
                        if let d = s.project.diagram(id) { TabPill(s: s, d: d) }
                    }
                    Menu {
                        NewDiagramMenu(s: s)
                    } label: {
                        Image(systemName: "plus").font(.system(size: 11, weight: .semibold))
                    }
                    .menuStyle(.borderlessButton)
                    .menuIndicator(.hidden)
                    .frame(width: 26, height: 26)
                    .help("New diagram")
                }
                .padding(.horizontal, 2)
            }
            .frame(height: 30)

            Spacer(minLength: 6)

            TopButton(icon: "arrow.uturn.backward", help: "Undo (⌘Z)") { s.undo() }.disabled(!s.canUndo)
            TopButton(icon: "arrow.uturn.forward", help: "Redo (⇧⌘Z)") { s.redo() }.disabled(!s.canRedo)
            Menu {
                Section("Java") {
                    Button("Generate Java Code…") { s.codeFocus = nil; s.sheet = .java }
                    Button("Reverse Engineer Java…") { s.sheet = .reverseJava }
                }
                Section("Database") {
                    Button("Generate SQL / JPA…") { s.codeFocus = nil; s.sheet = .sql }
                    Button("Reverse Engineer SQL…") { s.sheet = .reverseSQL }
                }
                Section("Export") {
                    Button("Diagram as PNG…") { Exporter.exportCurrent(s, .png) }
                    Button("Diagram as PDF…") { Exporter.exportCurrent(s, .pdf) }
                    Button("Diagram as SVG…") { Exporter.exportCurrent(s, .svg) }
                    Button("HTML Report…") { Exporter.exportReport(s) }
                }
            } label: {
                HStack(spacing: 5) {
                    Image(systemName: "chevron.left.forwardslash.chevron.right").font(.system(size: 11, weight: .semibold))
                    Text("Code").font(.system(size: 12, weight: .medium))
                }
            }
            .menuStyle(.borderlessButton)
            .menuIndicator(.hidden)
            .padding(.horizontal, 11)
            .frame(height: 28)
            .fixedSize()
            .liquidGlass(Capsule())
            .help("Code engineering and export")

            TopButton(icon: "checkmark.seal", text: "Check", help: "Check the model for mistakes (⇧⌘K)") { s.validate() }
            TopButton(icon: "graduationcap", text: "Learn Java", help: "UML to Java lessons") { s.sheet = .learn }
            TopButton(icon: "sidebar.left", help: "Show or hide the toolbox and project (⌥⌘S)", on: s.showSidebar) { s.showSidebar.toggle() }
            TopButton(icon: "sidebar.right", help: "Show or hide the properties (⌥⌘I)", on: s.showInspector) { s.showInspector.toggle() }
        }
        .frame(height: 30)
        .padding(.top, 4)
    }
}

struct NewDiagramMenu: View {
    @ObservedObject var s: Store
    var body: some View {
        ForEach(["UML", "Database", "Business & Diagrams"], id: \.self) { g in
            Section(g) {
                ForEach(DiagramType.allCases.filter { $0.group == g }) { t in
                    Menu {
                        Button("Blank") { s.newDiagram(t, example: false) }
                        Button("Example") { s.newDiagram(t, example: true) }
                    } label: {
                        Label(t.title, systemImage: t.icon)
                    } primaryAction: {
                        s.newDiagram(t, example: false)
                    }
                }
            }
        }
    }
}

struct LogoMark: View {
    var body: some View {
        GeometryReader { g in
            let w = g.size.width
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: w * 0.12).stroke(T.accent, lineWidth: 1.6)
                    .frame(width: w * 0.55, height: w * 0.42)
                RoundedRectangle(cornerRadius: w * 0.12).fill(T.orange)
                    .frame(width: w * 0.45, height: w * 0.36)
                    .offset(x: w * 0.55, y: w * 0.64)
                Path { p in
                    p.move(to: CGPoint(x: w * 0.28, y: w * 0.42))
                    p.addLine(to: CGPoint(x: w * 0.28, y: w * 0.82))
                    p.addLine(to: CGPoint(x: w * 0.55, y: w * 0.82))
                }
                .stroke(T.muted, lineWidth: 1.4)
            }
        }
    }
}

struct TabPill: View {
    @ObservedObject var s: Store
    let d: Diagram
    @StateObject private var hover = Box(false)

    var body: some View {
        let on = s.currentId == d.id
        HStack(spacing: 6) {
            Image(systemName: d.type.icon).font(.system(size: 10.5)).foregroundStyle(on ? T.accent : T.muted)
            Text(d.name).font(.system(size: 12, weight: on ? .semibold : .regular)).lineLimit(1)
            Button { s.closeTab(d.id) } label: {
                Image(systemName: "xmark").font(.system(size: 8.5, weight: .bold)).foregroundStyle(T.muted)
                    .frame(width: 14, height: 14)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .opacity(on || hover.v ? 1 : 0)
            .help("Close tab")
        }
        .padding(.leading, 11)
        .padding(.trailing, 7)
        .frame(height: 26)
        .background(on ? T.accent.opacity(0.16) : Color.primary.opacity(hover.v ? 0.08 : 0.04), in: Capsule())
        .overlay(Capsule().stroke(on ? T.accent.opacity(0.45) : Color.clear, lineWidth: 0.8))
        .contentShape(Capsule())
        .onTapGesture { s.open(d.id) }
        .onHover { hover.v = $0 }
        .contextMenu {
            Button("Rename") { s.renamingDiagram = d.id; s.showSidebar = true }
            Button("Duplicate") { s.duplicateDiagram(d.id) }
            Button("Close") { s.closeTab(d.id) }
            Divider()
            Button("Delete Diagram…") { s.deleteDiagram(d.id) }
        }
    }
}

// MARK: - left side: toolbox and project

struct Sidebar: View {
    @ObservedObject var s: Store
    var body: some View {
        VStack(spacing: 10) {
            Toolbox(s: s)
                .frame(maxHeight: .infinity)
            Explorer(s: s)
                .frame(maxHeight: .infinity)
        }
    }
}

struct Toolbox: View {
    @ObservedObject var s: Store
    @Environment(\.colorScheme) private var scheme
    private let cols = [GridItem(.flexible(), spacing: 4), GridItem(.flexible(), spacing: 4), GridItem(.flexible(), spacing: 4)]

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: s.diagram?.type.icon ?? "square.grid.2x2").foregroundStyle(T.accent)
                Text("Toolbox").font(.system(size: 13, weight: .semibold))
                Spacer()
                if let d = s.diagram { Text(d.type.short).font(.system(size: 11)).foregroundStyle(T.muted) }
            }
            if let d = s.diagram {
                ScrollView {
                    VStack(alignment: .leading, spacing: 8) {
                        SectionTitle(text: "Shapes")
                        LazyVGrid(columns: cols, spacing: 4) {
                            ForEach(d.type.nodes, id: \.self) { k in ToolTile(s: s, kind: k, dark: scheme == .dark) }
                        }
                        SectionTitle(text: "Connectors")
                        LazyVGrid(columns: cols, spacing: 4) {
                            ForEach(d.type.edges, id: \.self) { k in EdgeTile(s: s, kind: k, dark: scheme == .dark) }
                        }
                        SectionTitle(text: "General")
                        LazyVGrid(columns: cols, spacing: 4) {
                            ForEach([NodeKind.text, .rect, .ellipse], id: \.self) { k in ToolTile(s: s, kind: k, dark: scheme == .dark) }
                        }
                    }
                }
            } else {
                Text("Create or open a diagram to see its shapes.")
                    .font(.system(size: 12))
                    .foregroundStyle(T.muted)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .card(12)
    }
}

struct ToolTile: View {
    @ObservedObject var s: Store
    let kind: NodeKind
    let dark: Bool

    var body: some View {
        let armed = s.tool == .node(kind)
        Button {
            s.tool = armed ? nil : .node(kind)
            s.canvas?.window?.makeFirstResponder(s.canvas)
        } label: {
            VStack(spacing: 3) {
                Image(nsImage: Thumbs.node(kind, dark, size: 30))
                    .frame(width: 34, height: 30)
                Text(kind.title)
                    .font(.system(size: 9.5))
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                    .foregroundStyle(armed ? T.accent : T.muted)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 5)
            .background(armed ? T.accent.opacity(0.18) : Color.primary.opacity(0.001), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .help("\(kind.title): click it, then click on the canvas – or drag it onto the canvas. ⌥-click the canvas to place several.")
        .onDrag { NSItemProvider(object: "blueprint-node:\(kind.rawValue)" as NSString) }
    }
}

struct EdgeTile: View {
    @ObservedObject var s: Store
    let kind: EdgeKind
    let dark: Bool

    var body: some View {
        let armed = s.tool == .edge(kind)
        Button {
            s.tool = armed ? nil : .edge(kind)
            s.canvas?.window?.makeFirstResponder(s.canvas)
        } label: {
            VStack(spacing: 3) {
                Image(nsImage: Thumbs.edge(kind, dark, size: 28)).frame(width: 34, height: 28)
                Text(kind.title.replacingOccurrences(of: " (note link)", with: ""))
                    .font(.system(size: 9.5))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .foregroundStyle(armed ? T.accent : T.muted)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 5)
            .background(armed ? T.accent.opacity(0.18) : Color.primary.opacity(0.001), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .help("\(kind.title): drag from one shape to another. \(kind.javaHint)")
    }
}

struct Explorer: View {
    @ObservedObject var s: Store
    @Environment(\.colorScheme) private var scheme
    @FocusState private var searching: Bool

    var body: some View {
        let q = s.search.trimmed.lowercased()
        let diagrams = s.project.diagrams.filter { q.isEmpty || $0.name.lowercased().contains(q) || $0.type.title.lowercased().contains(q) }
        let items = s.modelItems.filter { q.isEmpty || $0.name.lowercased().contains(q) || $0.kind.title.lowercased().contains(q) }
        let groups = Dictionary(grouping: items, by: { $0.kind.title }).sorted { $0.key < $1.key }

        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: "folder").foregroundStyle(T.accent)
                Text("Project").font(.system(size: 13, weight: .semibold))
                Spacer()
                Menu { NewDiagramMenu(s: s) } label: { Image(systemName: "plus") }
                    .menuStyle(.borderlessButton)
                    .menuIndicator(.hidden)
                    .fixedSize()
                    .help("New diagram")
            }
            HStack(spacing: 5) {
                Image(systemName: "magnifyingglass").font(.system(size: 11)).foregroundStyle(T.muted)
                TextField("Search", text: $s.search)
                    .textFieldStyle(.plain)
                    .font(.system(size: 12))
                    .focused($searching)
                    .onChange(of: s.focusSearch) { _, _ in searching = true }
                if !s.search.isEmpty {
                    Button { s.search = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(T.muted) }.buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 8)
            .frame(height: 26)
            .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 8, style: .continuous))

            ScrollView {
                LazyVStack(alignment: .leading, spacing: 1) {
                    SectionTitle(text: "Diagrams · \(s.project.diagrams.count)").padding(.vertical, 3)
                    if diagrams.isEmpty {
                        Text(s.project.diagrams.isEmpty ? "No diagrams yet" : "No match").font(.system(size: 11)).foregroundStyle(T.muted).padding(.vertical, 4)
                    }
                    ForEach(diagrams) { d in DiagramRow(s: s, d: d) }
                    if !groups.isEmpty {
                        SectionTitle(text: "Model elements · \(items.count)").padding(.top, 10).padding(.bottom, 3)
                        ForEach(groups, id: \.key) { g in
                            Text(g.key).font(.system(size: 10.5, weight: .medium)).foregroundStyle(T.muted).padding(.top, 4)
                            ForEach(g.value.prefix(200)) { it in
                                Button { s.reveal(it.diagram, it.id) } label: {
                                    HStack(spacing: 6) {
                                        Image(nsImage: Thumbs.node(it.kind, scheme == .dark, size: 16)).frame(width: 16, height: 16)
                                        Text(it.name).font(.system(size: 12)).lineLimit(1)
                                        Spacer(minLength: 4)
                                        Text(it.diagramName).font(.system(size: 10)).foregroundStyle(T.muted).lineLimit(1)
                                    }
                                    .padding(.horizontal, 6)
                                    .frame(height: 22)
                                    .background(s.selection.contains(it.id) ? T.accent.opacity(0.14) : Color.clear, in: RoundedRectangle(cornerRadius: 6))
                                    .contentShape(Rectangle())
                                }
                                .buttonStyle(.plain)
                                .help("Show \(it.name) in \(it.diagramName)")
                            }
                        }
                    }
                }
            }
        }
        .card(12)
    }
}

struct DiagramRow: View {
    @ObservedObject var s: Store
    let d: Diagram

    var body: some View {
        let on = s.currentId == d.id
        HStack(spacing: 7) {
            Image(systemName: d.type.icon).font(.system(size: 11)).foregroundStyle(on ? T.accent : T.muted).frame(width: 16)
            if s.renamingDiagram == d.id {
                CommitField(text: d.name) { v in
                    s.renameDiagram(d.id, v)
                    s.renamingDiagram = nil
                }
                .frame(height: 22)
            } else {
                Text(d.name).font(.system(size: 12, weight: on ? .semibold : .regular)).lineLimit(1)
                Spacer(minLength: 4)
                Text(d.type.short).font(.system(size: 10)).foregroundStyle(T.muted).lineLimit(1)
            }
        }
        .padding(.horizontal, 6)
        .frame(height: 26)
        .background(on ? T.accent.opacity(0.15) : Color.clear, in: RoundedRectangle(cornerRadius: 7, style: .continuous))
        .contentShape(Rectangle())
        .onTapGesture { s.open(d.id) }
        .contextMenu {
            Button("Open") { s.open(d.id) }
            Button("Rename") { s.renamingDiagram = d.id }
            Button("Duplicate") { s.duplicateDiagram(d.id) }
            Divider()
            Button("Move Up") { s.moveDiagram(d.id, by: -1) }
            Button("Move Down") { s.moveDiagram(d.id, by: 1) }
            Divider()
            Button("Delete…") { s.deleteDiagram(d.id) }
        }
    }
}

// MARK: - centre: canvas or start page

struct CanvasArea: View {
    @ObservedObject var s: Store

    var body: some View {
        ZStack {
            if s.diagram != nil {
                CanvasHost(store: s)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(T.line, lineWidth: 0.5))
                    .overlay(alignment: .bottomLeading) { ZoomPill(s: s).padding(12) }
                    .overlay(alignment: .bottomTrailing) {
                        if s.showOverview {
                            OverviewHost(store: s)
                                .frame(width: 190, height: 124)
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(T.line, lineWidth: 0.8))
                                .shadow(color: .black.opacity(0.15), radius: 8, y: 3)
                                .padding(12)
                        }
                    }
                    .overlay(alignment: .top) {
                        VStack(spacing: 6) {
                            if let t = s.tool { ToolHint(s: s, tool: t) }
                            if let msg = s.toast {
                                Text(msg)
                                    .font(.system(size: 12, weight: .medium))
                                    .padding(.horizontal, 14)
                                    .frame(height: 30)
                                    .liquidGlass(Capsule())
                                    .transition(.move(edge: .top).combined(with: .opacity))
                            }
                        }
                        .padding(.top, 12)
                        .animation(.easeOut(duration: 0.2), value: s.toast)
                    }
            } else {
                StartPage(s: s)
            }
        }
    }
}

struct ToolHint: View {
    @ObservedObject var s: Store
    let tool: Tool
    var body: some View {
        let text: String = {
            switch tool {
            case .node(let k): return "Click on the canvas to place a \(k.title)"
            case .edge(let k): return "Drag from one shape to another to draw a \(k.title)"
            }
        }()
        HStack(spacing: 8) {
            Image(systemName: "hand.point.up.left").foregroundStyle(T.accent)
            Text(text).font(.system(size: 12, weight: .medium))
            Text("Esc cancels").font(.system(size: 11)).foregroundStyle(T.muted)
            Button { s.tool = nil } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(T.muted) }.buttonStyle(.plain)
        }
        .padding(.horizontal, 14)
        .frame(height: 30)
        .liquidGlass(Capsule())
    }
}

struct ZoomPill: View {
    @ObservedObject var s: Store
    var body: some View {
        HStack(spacing: 2) {
            Button { s.canvas?.zoomOut() } label: { Image(systemName: "minus").frame(width: 22, height: 22).contentShape(Rectangle()) }
                .help("Zoom out (⌘−)")
            Button { s.canvas?.zoomActual() } label: {
                Text("\(Int((s.zoom * 100).rounded()))%").font(.system(size: 11, weight: .medium)).monospacedDigit().frame(width: 42)
            }
            .help("Actual size (⌘0)")
            Button { s.canvas?.zoomIn() } label: { Image(systemName: "plus").frame(width: 22, height: 22).contentShape(Rectangle()) }
                .help("Zoom in (⌘+)")
            Divider().frame(height: 14)
            Button { s.canvas?.zoomToFit() } label: { Image(systemName: "arrow.up.left.and.arrow.down.right").frame(width: 22, height: 22).contentShape(Rectangle()) }
                .help("Zoom to fit (⌥⌘0)")
            Button { s.showGrid.toggle() } label: { Image(systemName: "grid").foregroundStyle(s.showGrid ? T.accent : T.muted).frame(width: 22, height: 22).contentShape(Rectangle()) }
                .help("Show grid (⌘')")
            Button { s.showOverview.toggle() } label: { Image(systemName: "map").foregroundStyle(s.showOverview ? T.accent : T.muted).frame(width: 22, height: 22).contentShape(Rectangle()) }
                .help("Overview")
        }
        .buttonStyle(.plain)
        .font(.system(size: 11, weight: .semibold))
        .padding(.horizontal, 8)
        .frame(height: 30)
        .liquidGlass(Capsule())
    }
}

struct StartPage: View {
    @ObservedObject var s: Store
    private let cols = [GridItem(.adaptive(minimum: 210, maximum: 320), spacing: 12)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack(alignment: .firstTextBaseline, spacing: 12) {
                    Text("Blueprint").font(.system(size: 34, weight: .bold))
                    Text("Model it, then let it write the Java.").font(.system(size: 15)).foregroundStyle(T.muted)
                    Spacer()
                    Button("Open Project…") { AppDelegate.shared.openDocument(nil) }.buttonStyle(PillStyle())
                    Button("Reverse Engineer Java…") { s.sheet = .reverseJava }.buttonStyle(PillStyle())
                }

                LearnBanner(s: s)

                ForEach(["UML", "Database", "Business & Diagrams"], id: \.self) { g in
                    VStack(alignment: .leading, spacing: 10) {
                        SectionTitle(text: g)
                        LazyVGrid(columns: cols, alignment: .leading, spacing: 12) {
                            ForEach(DiagramType.allCases.filter { $0.group == g }) { t in TypeCard(s: s, t: t) }
                        }
                    }
                }

                let recent = Recent.urls
                if !recent.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        SectionTitle(text: "Recent projects")
                        ForEach(recent.prefix(8), id: \.self) { u in
                            Button { AppDelegate.shared.open(u) } label: {
                                HStack(spacing: 8) {
                                    Image(systemName: "doc").foregroundStyle(T.accent)
                                    Text(u.deletingPathExtension().lastPathComponent).font(.system(size: 13, weight: .medium))
                                    Text(u.deletingLastPathComponent().path.replacingOccurrences(of: NSHomeDirectory(), with: "~"))
                                        .font(.system(size: 11)).foregroundStyle(T.muted).lineLimit(1)
                                    Spacer()
                                }
                                .padding(.horizontal, 12)
                                .frame(height: 32)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .card(0)
                        }
                    }
                }
            }
            .padding(24)
        }
        .card(0)
    }
}

struct LearnBanner: View {
    @ObservedObject var s: Store
    var body: some View {
        let done = Lessons.done.count
        HStack(spacing: 16) {
            Image(systemName: "graduationcap.fill").font(.system(size: 30)).foregroundStyle(T.orange)
            VStack(alignment: .leading, spacing: 4) {
                Text("Learn Java through UML").font(.system(size: 15, weight: .semibold))
                Text("\(Lessons.all.count) short lessons: every UML symbol next to the Java code it becomes, with a quiz question each.")
                    .font(.system(size: 12)).foregroundStyle(T.muted)
                ProgressView(value: Double(done), total: Double(Lessons.all.count))
                    .frame(maxWidth: 260)
                    .tint(T.orange)
            }
            Spacer()
            Text("\(done)/\(Lessons.all.count)").font(.system(size: 22, weight: .semibold)).monospacedDigit()
            Button(done == 0 ? "Start" : "Continue") { s.sheet = .learn }.buttonStyle(PillStyle(prominent: true))
        }
        .card(16)
    }
}

struct TypeCard: View {
    @ObservedObject var s: Store
    let t: DiagramType

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: t.icon).font(.system(size: 17, weight: .medium)).foregroundStyle(T.accent)
                Spacer()
            }
            Text(t.title).font(.system(size: 13, weight: .semibold)).lineLimit(1)
            Text(t.blurb).font(.system(size: 11)).foregroundStyle(T.muted).lineLimit(3).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 2)
            HStack(spacing: 6) {
                Button("Blank") { s.newDiagram(t, example: false) }.buttonStyle(PillStyle())
                Button("Example") { s.newDiagram(t, example: true) }.buttonStyle(PillStyle(prominent: true))
            }
        }
        .padding(14)
        .frame(height: 158, alignment: .topLeading)
        .card(0)
    }
}

// MARK: - status line

struct StatusBar: View {
    @ObservedObject var s: Store

    var hint: String {
        if s.tool != nil { return "Click to place · ⌥-click keeps the tool · Esc cancels" }
        if let d = s.diagram {
            if d.type == .mindMap { return "Tab adds a child topic · Return adds a sibling · type to rename" }
            if s.selection.count == 1, let n = s.selectedNodes.first {
                if n.kind.isClassifier { return "Double-click a row to edit it · ⌥⇧A attribute · ⌥⇧O operation · drag the blue dot to connect" }
                if n.kind.isLifeline { return "Drag down the dashed line to another lifeline to send a message" }
                return "Drag the blue dot to connect · Return or type to rename · arrows nudge"
            }
            if s.selection.count > 1 { return "Right-click to align or distribute · arrows nudge · ⌘D duplicates" }
            return "Double-click the canvas to add a shape · ⌘-scroll or pinch to zoom · Space-drag to pan"
        }
        return "Pick a diagram type to begin"
    }

    var body: some View {
        HStack(spacing: 6) {
            if let d = s.diagram {
                Image(systemName: d.type.icon)
                Text(d.type.title)
                Text("·")
                Text("\(d.nodes.count) shapes, \(d.edges.count) connectors")
                if !s.selection.isEmpty { Text("· \(s.selection.count) selected") }
            } else {
                Text("\(s.project.diagrams.count) diagrams")
            }
            Spacer()
            Text(hint).lineLimit(1)
        }
        .font(.system(size: 11))
        .foregroundStyle(T.muted)
        .padding(.horizontal, 8)
        .frame(height: 16)
    }
}

extension EdgeKind {
    /// what the relationship means for Java code
    var javaHint: String {
        switch self {
        case .association: return "In Java: each class gets a field pointing at the other."
        case .directed: return "In Java: a field in the class the line starts from."
        case .aggregation: return "In Java: the whole keeps a field (often a List) of parts that can exist on their own."
        case .composition: return "In Java: the whole creates and owns its parts, usually in a final List."
        case .generalization: return "In Java: class Child extends Parent."
        case .realization: return "In Java: class Impl implements Interface."
        case .dependency: return "In Java: the class uses the other one as a parameter or local variable."
        case .anchor: return "Attaches a note; no code."
        case .include: return "The base use case always runs the included one, like calling a method."
        case .extend: return "Optional extra behaviour inserted into the base use case."
        case .message: return "In Java: a method call, receiver.method(args)."
        case .asyncMessage: return "A call that doesn't wait for an answer, e.g. a new thread or an event."
        case .reply: return "The value a method returns."
        case .create: return "In Java: new ClassName(...)."
        case .controlFlow: return "The next step; a guard like [x > 0] is the condition of an if."
        case .objectFlow: return "Passes an object (data) to the next step."
        case .transition: return "Written as event [guard] / action; often a method that changes a state enum."
        case .deploy: return "The artifact (e.g. a .jar) runs on that node."
        case .importDep: return "In Java: an import statement."
        case .relationship: return "A foreign key; in JPA @ManyToOne on one side and @OneToMany on the other."
        case .flow, .sequenceFlow: return "The order in which steps happen."
        case .messageFlow: return "Communication between two participants."
        case .bpmnAssoc: return "Links data or a note to a task."
        case .branch: return "Links a topic to its parent idea."
        case .dataFlow: return "Data moving between processes, stores and outside parties."
        }
    }
}
