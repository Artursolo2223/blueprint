import Foundation

struct Issue: Identifiable {
    enum Level: Int { case error, warning, tip }
    let id = UUID()
    var level: Level
    var text: String
    var diagram: UUID
    var diagramName: String
    var node: UUID?
}

/// checks a project and explains what is wrong, mostly in Java terms
enum Validator {
    static func run(_ p: Project) -> [Issue] {
        var out: [Issue] = []
        for d in p.diagrams {
            var list: [Issue] = []
            func add(_ l: Issue.Level, _ t: String, _ n: UUID? = nil) {
                list.append(Issue(level: l, text: t, diagram: d.id, diagramName: d.name, node: n))
            }
            let byId = Dictionary(uniqueKeysWithValues: d.nodes.map { ($0.id, $0) })
            func outgoing(_ n: Node) -> [Edge] { d.edges.filter { $0.from == n.id } }
            func incoming(_ n: Node) -> [Edge] { d.edges.filter { $0.to == n.id } }
            func label(_ n: Node) -> String { n.name.isEmpty ? n.kind.title : "“\(n.name)”" }

            if d.nodes.isEmpty { add(.tip, "This diagram is empty. Pick a shape in the toolbox and click on the canvas.") }
            for e in d.edges where byId[e.from] == nil || byId[e.to] == nil {
                add(.error, "A \(e.kind.title.lowercased()) points at a shape that no longer exists.")
            }

            switch d.type {
            case .classDiagram, .package:
                classRules(d, byId, add)
            case .useCase:
                for n in d.nodes where n.kind == .useCase {
                    let connected = d.edges.contains { ($0.from == n.id || $0.to == n.id) && $0.kind != .anchor }
                    if !connected { add(.warning, "Use case \(label(n)) is not connected to any actor or other use case.", n.id) }
                    if n.name.trimmed.isEmpty { add(.error, "A use case has no name.", n.id) }
                }
                for n in d.nodes where n.kind == .actor {
                    if !d.edges.contains(where: { ($0.from == n.id || $0.to == n.id) && $0.kind != .anchor }) {
                        add(.warning, "Actor \(label(n)) doesn't use anything. Connect it to a use case with an association.", n.id)
                    }
                }
                for e in d.edges where e.kind == .include || e.kind == .extend {
                    if byId[e.from]?.kind != .useCase || byId[e.to]?.kind != .useCase {
                        add(.error, "«\(e.kind.rawValue)» may only connect two use cases.")
                    }
                }
            case .activity:
                if !d.nodes.contains(where: { $0.kind == .initial }) { add(.warning, "There is no initial node (the black dot where the activity starts).") }
                if !d.nodes.contains(where: { $0.kind == .final || $0.kind == .flowFinal }) { add(.tip, "There is no final node, so the activity never ends – like a loop without a way out.") }
                for n in d.nodes where n.kind == .decision {
                    let o = outgoing(n)
                    if o.count < 2 { add(.warning, "A decision needs at least two outgoing flows, like the two branches of an if/else.", n.id) }
                    if o.contains(where: { $0.name.trimmed.isEmpty }) && o.count >= 2 {
                        add(.tip, "Give each flow leaving a decision a guard such as [valid] or [else] – that's the condition of your if.", n.id)
                    }
                }
                for n in d.nodes where n.kind == .action {
                    if incoming(n).isEmpty { add(.tip, "Action \(label(n)) has no incoming flow, so it can never run.", n.id) }
                    else if outgoing(n).isEmpty { add(.tip, "Action \(label(n)) has no outgoing flow.", n.id) }
                }
            case .stateMachine:
                let initials = d.nodes.filter { $0.kind == .initial }
                if initials.isEmpty { add(.warning, "There is no initial state (black dot). In Java this is the value the state field starts with.") }
                // states you can't reach from the start
                var seen = Set(initials.map(\.id))
                var queue = initials.map(\.id)
                while let v = queue.popLast() {
                    for e in d.edges where e.from == v && e.kind == .transition && !seen.contains(e.to) { seen.insert(e.to); queue.append(e.to) }
                }
                if !initials.isEmpty {
                    for n in d.nodes where n.kind == .state && !seen.contains(n.id) {
                        let inside = d.nodes.contains { $0.kind == .state && $0.id != n.id && $0.frame.contains(n.frame) }
                        if !inside { add(.warning, "State \(label(n)) can't be reached from the initial state.", n.id) }
                    }
                }
                for e in d.edges where e.kind == .transition && e.name.trimmed.isEmpty && byId[e.from]?.kind == .state && byId[e.to]?.kind != .final {
                    add(.tip, "A transition out of \(byId[e.from].map(label) ?? "a state") has no trigger. Write it as event [guard] / action.", e.to)
                }
            case .sequence:
                for e in d.edges where e.kind.isMessage && e.kind != .reply && e.name.trimmed.isEmpty {
                    add(.tip, "A message has no name. Messages are method calls, e.g. placeOrder(cart).")
                }
                for n in d.nodes where n.kind == .lifeline && n.prop("classifier").isEmpty && n.name.trimmed.isEmpty {
                    add(.warning, "A lifeline has neither an object name nor a class.", n.id)
                }
            case .erd:
                for n in d.nodes where n.kind == .entity {
                    if !n.attrs.contains(where: \.pk) { add(.error, "Table \(label(n)) has no primary key. Every table needs one (mark a column PK).", n.id) }
                    var names: Set<String> = []
                    for c in n.attrs where !names.insert(c.name.lowercased()).inserted {
                        add(.error, "Table \(label(n)) has two columns called \(c.name).", n.id)
                    }
                    for c in n.attrs where c.fk && SQLGen.reference(c, of: n, in: d) == nil {
                        add(.warning, "Column \(n.name).\(c.name) is a foreign key but doesn't point at a table.", n.id)
                    }
                    for c in n.attrs where c.type.trimmed.isEmpty { add(.warning, "Column \(n.name).\(c.name) has no data type.", n.id) }
                    if n.name.contains(" ") { add(.tip, "Table names with spaces need quotes in SQL. Try \(n.name.replacingOccurrences(of: " ", with: "_")).", n.id) }
                }
            case .flowchart:
                if !d.nodes.contains(where: { $0.kind == .terminator }) { add(.tip, "Start and end your flowchart with a Start/End (terminator) shape.") }
                for n in d.nodes where n.kind == .fDecision && outgoing(n).count < 2 {
                    add(.warning, "Decision \(label(n)) needs two outgoing arrows (yes and no).", n.id)
                }
            case .bpmn:
                if !d.nodes.contains(where: { $0.kind == .startEvent }) { add(.warning, "The process has no start event.") }
                if !d.nodes.contains(where: { $0.kind == .endEvent }) { add(.warning, "The process has no end event.") }
                for n in d.nodes where [.xorGateway, .orGateway].contains(n.kind) && outgoing(n).count < 2 && incoming(n).count < 2 {
                    add(.tip, "A gateway usually splits into two or more flows or joins them again.", n.id)
                }
                for e in d.edges where e.kind == .messageFlow {
                    if let a = byId[e.from], let b = byId[e.to], poolOf(a, d) == poolOf(b, d), poolOf(a, d) != nil {
                        add(.error, "Message flows connect different pools. Inside one pool use a sequence flow.")
                    }
                }
            case .mindMap:
                if d.nodes.filter({ $0.kind == .central }).count > 1 { add(.tip, "A mind map normally has one central topic.") }
            default:
                break
            }
            out.append(contentsOf: list)
        }
        return out.sorted { $0.level.rawValue < $1.level.rawValue }
    }

    static func poolOf(_ n: Node, _ d: Diagram) -> UUID? {
        d.nodes.first { $0.kind == .pool && $0.id != n.id && $0.frame.contains(n.frame) }?.id
    }

    private static func classRules(_ d: Diagram, _ byId: [UUID: Node], _ add: (Issue.Level, String, UUID?) -> Void) {
        let classes = d.nodes.filter { JavaGen.classKinds.contains($0.kind) }
        var names: [String: Int] = [:]
        for n in classes { names[n.name, default: 0] += 1 }
        for n in classes {
            let nm = n.name.trimmed
            let what = n.kind == .interface ? "Interface" : n.kind == .enumeration ? "Enum" : "Class"
            if nm.isEmpty { add(.error, "A \(what.lowercased()) has no name.", n.id); continue }
            if (names[n.name] ?? 0) > 1 { add(.error, "Two classes are called \(nm). In Java every class in a package needs its own name.", n.id) }
            if !JavaNames.isIdentifier(nm) {
                add(.error, "\(what) name “\(nm)” isn't a valid Java name (letters, digits, _ and $ only, no spaces, not a keyword). Try \(JavaNames.type(nm)).", n.id)
            } else if nm.first!.isLowercase {
                add(.warning, "Java class names start with a capital letter: \(nm.upperFirst).", n.id)
            }
            // attributes
            for a in n.attrs where n.kind != .enumeration {
                if !JavaNames.isIdentifier(a.name) { add(.error, "\(nm).\(a.name) isn't a valid Java field name.", n.id); continue }
                let constant = a.isStatic && a.isFinal
                if constant && a.name != a.name.uppercased() {
                    add(.tip, "\(nm).\(a.name) is static final (a constant); Java writes constants in UPPER_CASE.", n.id)
                } else if !constant && a.name.first!.isUppercase {
                    add(.tip, "Field names start with a lowercase letter: \(a.name.lowerFirst) (lowerCamelCase).", n.id)
                }
                if a.type.trimmed.isEmpty { add(.warning, "\(nm).\(a.name) has no type. Java needs a type for every field, e.g. name : String.", n.id) }
                if a.vis == .pub && !a.isFinal && n.kind == .klass {
                    add(.tip, "\(nm).\(a.name) is public. Encapsulation: make it private (-) and add a getter/setter.", n.id)
                }
                if n.kind == .interface && !(a.isStatic && a.isFinal) {
                    add(.tip, "Fields in an interface are always constants (public static final). Mark \(a.name) static and final, or move it to a class.", n.id)
                }
            }
            for l in n.attrs where n.kind == .enumeration && l.name != l.name.uppercased() {
                add(.tip, "Enum values are written in UPPER_CASE: \(l.name.uppercased()).", n.id)
            }
            if n.kind == .enumeration && n.attrs.isEmpty { add(.warning, "Enum \(nm) has no values.", n.id) }
            // operations
            for o in n.ops {
                if !JavaNames.isIdentifier(o.name) { add(.error, "\(nm).\(o.name)() isn't a valid Java method name.", n.id); continue }
                if o.name.first!.isUppercase && o.name != nm { add(.tip, "Method names start with a lowercase letter: \(o.name.lowerFirst)().", n.id) }
            }
            if n.kind == .klass && !n.isAbstract && n.ops.contains(where: \.isAbstract) {
                add(.error, "\(nm) has an abstract method, so the class itself must be abstract.", n.id)
            }
            // inheritance
            let supers = d.edges.filter { $0.kind == .generalization && $0.from == n.id }.compactMap { byId[$0.to] }
            if n.kind == .klass {
                let classSupers = supers.filter { $0.kind == .klass }
                if classSupers.count > 1 {
                    add(.error, "\(nm) extends \(classSupers.count) classes. Java has single inheritance: keep one superclass and use interfaces for the rest.", n.id)
                }
                if supers.contains(where: { $0.kind == .interface }) {
                    add(.error, "\(nm) generalizes an interface. A class implements an interface: use a realization (dashed line).", n.id)
                }
            }
            if n.kind == .interface && supers.contains(where: { $0.kind == .klass }) {
                add(.error, "Interface \(nm) can't extend a class, only other interfaces.", n.id)
            }
            for e in d.edges where e.kind == .realization && e.from == n.id {
                if let t = byId[e.to], t.kind != .interface { add(.error, "\(nm) realizes \(t.name), which isn't an interface. You can only implement interfaces.", n.id) }
            }
            // methods an interface promises must exist in a concrete class
            if n.kind == .klass && !n.isAbstract {
                let mine = Set(n.ops.map(\.name))
                for e in d.edges where e.kind == .realization && e.from == n.id {
                    guard let i = byId[e.to], i.kind == .interface else { continue }
                    let missing = i.ops.filter { !$0.isStatic && !mine.contains($0.name) }.map { $0.name + "()" }
                    if !missing.isEmpty {
                        add(.warning, "\(nm) implements \(i.name) but has no \(missing.joined(separator: ", ")). The generated code adds them with @Override.", n.id)
                    }
                }
                for s in supers where s.kind == .klass && s.isAbstract {
                    let missing = s.ops.filter { $0.isAbstract && !mine.contains($0.name) }.map { $0.name + "()" }
                    if !missing.isEmpty { add(.warning, "\(nm) extends abstract \(s.name) but doesn't implement \(missing.joined(separator: ", ")).", n.id) }
                }
            }
        }
        // inheritance cycles
        var adj: [UUID: [UUID]] = [:]
        for e in d.edges where e.kind == .generalization { adj[e.from, default: []].append(e.to) }
        var state: [UUID: Int] = [:]
        var cyclic: Set<UUID> = []
        func visit(_ v: UUID) {
            state[v] = 1
            for w in adj[v] ?? [] {
                if state[w] == 1 { cyclic.insert(w) } else if state[w] == nil { visit(w) }
            }
            state[v] = 2
        }
        for v in adj.keys where state[v] == nil { visit(v) }
        for c in cyclic { add(.error, "Inheritance goes in a circle through \(byId[c]?.name ?? "a class"). A class can't be its own ancestor.", c) }
        for e in d.edges where [.association, .directed, .aggregation, .composition].contains(e.kind) {
            for m in [e.fromMult, e.toMult] where !m.isEmpty && m.range(of: "^(\\d+|\\*|n)(\\.\\.(\\d+|\\*|n))?$", options: .regularExpression) == nil {
                add(.warning, "Multiplicity “\(m)” isn't valid. Use 1, 0..1, *, 0..* or 1..*.", e.from)
            }
        }
    }
}
