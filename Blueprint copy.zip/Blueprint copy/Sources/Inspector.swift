import SwiftUI
import AppKit

struct Inspector: View {
    @ObservedObject var s: Store

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("", selection: $s.inspectorTab) {
                Text("Properties").tag(0)
                Text("Format").tag(1)
                Text("Code").tag(2)
            }
            .pickerStyle(.segmented)
            .labelsHidden()
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    switch s.inspectorTab {
                    case 1: FormatPane(s: s)
                    case 2: CodePane(s: s)
                    default: PropertiesPane(s: s)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.bottom, 10)
                .padding(.trailing, 2)
            }
        }
        .card(12)
    }
}

struct Labeled<C: View>: View {
    let label: String
    @ViewBuilder var content: C
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.system(size: 11, weight: .medium)).foregroundStyle(T.muted)
            content
        }
    }
}

struct KindHeader: View {
    let image: NSImage
    let title: String
    let subtitle: String
    var body: some View {
        HStack(spacing: 10) {
            Image(nsImage: image).frame(width: 30, height: 30)
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.system(size: 14, weight: .semibold))
                Text(subtitle).font(.system(size: 11)).foregroundStyle(T.muted).fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

// MARK: - properties

struct PropertiesPane: View {
    @ObservedObject var s: Store
    var body: some View {
        let nodes = s.selectedNodes
        let edges = s.selectedEdges
        if nodes.count == 1 && edges.isEmpty {
            NodeProps(s: s, n: nodes[0])
        } else if edges.count == 1 && nodes.isEmpty {
            EdgeProps(s: s, e: edges[0])
        } else if nodes.count + edges.count > 1 {
            MultiProps(s: s, count: nodes.count + edges.count)
        } else if let d = s.diagram {
            DiagramProps(s: s, d: d)
        } else {
            ProjectProps(s: s)
        }
    }
}

extension NodeKind {
    var help: String {
        switch self {
        case .klass: return "Becomes a Java class"
        case .interface: return "Becomes a Java interface"
        case .enumeration: return "Becomes a Java enum"
        case .object: return "An instance: what new creates"
        case .package: return "Becomes a Java package"
        case .entity: return "A database table"
        case .actor: return "A person or system outside"
        case .useCase: return "Something the system does for an actor"
        case .lifeline: return "An object taking part in the interaction"
        case .fragment: return "loop, alt (if/else), opt (if)…"
        case .state: return "A situation an object can be in"
        case .action: return "One step of the activity"
        case .decision: return "An if/else: one flow per guard"
        case .fork: return "Split into (or join) parallel flows"
        default: return info.family == .container ? "Groups the shapes inside it" : title
        }
    }
}

struct NodeProps: View {
    @ObservedObject var s: Store
    let n: Node
    @Environment(\.colorScheme) private var scheme

    func set(_ key: String? = nil, _ f: @escaping (inout Node) -> Void) { s.updateNode(n.id, key: key, f) }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            KindHeader(image: Thumbs.node(n.kind, scheme == .dark, size: 30), title: n.kind.title, subtitle: n.kind.help)

            if n.kind.isNoteLike {
                Labeled(label: "Text") {
                    CommitTextView(text: n.name) { v in set { $0.name = v } }
                        .frame(height: 70)
                        .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))
                }
            } else if !n.kind.unnamed || !n.name.isEmpty {
                Labeled(label: n.kind == .fragment ? "Guards (use | between the operands of alt)" : n.kind.isLifeline || n.kind == .object ? "Object name" : "Name") {
                    CommitField(text: n.name, placeholder: "Name") { v in set { $0.name = v } }.frame(height: 22)
                }
            } else {
                Labeled(label: "Label") {
                    CommitField(text: n.name, placeholder: "Optional") { v in set { $0.name = v } }.frame(height: 22)
                }
            }

            if n.kind.isLifeline || n.kind == .object {
                Labeled(label: "Class") {
                    CommitField(text: n.prop("classifier"), placeholder: "e.g. Order") { v in set { $0.props["classifier"] = v } }.frame(height: 22)
                }
            }
            if [.klass, .component, .artifact, .package, .node3d, .device, .execEnv, .useCase, .actor].contains(n.kind) {
                Labeled(label: "Stereotype") {
                    CommitField(text: n.stereotype, placeholder: n.kind == .klass ? "e.g. entity, record, final" : "optional") { v in set { $0.stereotype = v } }.frame(height: 22)
                }
            }
            if n.kind == .klass {
                Toggle("Abstract (name in italics)", isOn: Binding(get: { n.isAbstract }, set: { v in set { $0.isAbstract = v } }))
                    .toggleStyle(.checkbox)
                    .font(.system(size: 12))
            }
            if n.kind == .fragment {
                Labeled(label: "Operator") {
                    Picker("", selection: Binding(get: { n.prop("operator").isEmpty ? "loop" : n.prop("operator") }, set: { v in set { $0.props["operator"] = v } })) {
                        ForEach(["loop", "alt", "opt", "par", "break", "critical", "neg", "ref"], id: \.self) { Text($0).tag($0) }
                    }
                    .labelsHidden()
                }
            }
            if n.kind == .state {
                ForEach(["entry", "do", "exit"], id: \.self) { k in
                    Labeled(label: "\(k) /") {
                        CommitField(text: n.prop(k), placeholder: "action()") { v in set { $0.props[k] = v } }.frame(height: 22)
                    }
                }
            }
            if [.startEvent, .interEvent, .endEvent].contains(n.kind) {
                Labeled(label: "Trigger") {
                    Picker("", selection: Binding(get: { n.prop("trigger") }, set: { v in set { $0.props["trigger"] = v } })) {
                        Text("None").tag("")
                        Text("Message").tag("message")
                        Text("Timer").tag("timer")
                        Text("Error").tag("error")
                    }
                    .labelsHidden()
                }
            }

            switch n.kind {
            case .klass, .interface:
                MemberList(s: s, n: n, op: false)
                MemberList(s: s, n: n, op: true)
            case .enumeration:
                MemberList(s: s, n: n, op: false)
                MemberList(s: s, n: n, op: true)
            case .object, .entity:
                MemberList(s: s, n: n, op: false)
            default:
                EmptyView()
            }

            Labeled(label: "Documentation") {
                CommitTextView(text: n.doc) { v in set { $0.doc = v } }
                    .frame(height: 64)
                    .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))
            }

            Connections(s: s, n: n)

            Labeled(label: "Position and size") {
                HStack(spacing: 6) {
                    NumberField(label: "X", value: n.frame.minX) { v in set { $0.frame.origin.x = max(0, v) } }
                    NumberField(label: "Y", value: n.frame.minY) { v in set { $0.frame.origin.y = max(0, v) } }
                    NumberField(label: "W", value: n.frame.width) { v in set { $0.frame.size.width = max(Store.minSize($0).width, v) } }
                    NumberField(label: "H", value: n.frame.height) { v in set { $0.frame.size.height = max(Store.minSize($0).height, v) } }
                }
            }
        }
    }
}

struct NumberField: View {
    let label: String
    let value: CGFloat
    let onCommit: (CGFloat) -> Void
    var body: some View {
        HStack(spacing: 3) {
            Text(label).font(.system(size: 10, weight: .semibold)).foregroundStyle(T.muted)
            CommitField(text: String(Int(value.rounded()))) { v in
                if let d = Double(v.replacingOccurrences(of: ",", with: ".")) { onCommit(CGFloat(d)) }
            }
            .frame(height: 22)
        }
    }
}

struct Connections: View {
    @ObservedObject var s: Store
    let n: Node
    var body: some View {
        let es = s.diagram?.edges.filter { $0.from == n.id || $0.to == n.id } ?? []
        if !es.isEmpty {
            Labeled(label: "Connections") {
                VStack(alignment: .leading, spacing: 2) {
                    ForEach(es) { e in
                        let other = s.node(e.from == n.id ? e.to : e.from)
                        Button { s.selection = [e.id] } label: {
                            HStack(spacing: 5) {
                                Image(systemName: e.from == n.id ? "arrow.right" : "arrow.left").font(.system(size: 9)).foregroundStyle(T.muted)
                                Text(other.map { $0.name.isEmpty ? $0.kind.title : $0.name } ?? "?").font(.system(size: 12)).lineLimit(1)
                                Spacer()
                                Text(e.kind.title).font(.system(size: 10.5)).foregroundStyle(T.muted).lineLimit(1)
                            }
                            .frame(height: 20)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

struct MemberList: View {
    @ObservedObject var s: Store
    let n: Node
    let op: Bool

    var title: String {
        switch n.kind {
        case .entity: return "Columns"
        case .object: return "Slots (attribute = value)"
        case .enumeration: return op ? "Operations" : "Literals"
        default: return op ? "Operations" : "Attributes"
        }
    }
    var placeholder: String {
        switch n.kind {
        case .entity: return "column : VARCHAR(50)"
        case .object: return "name = value"
        case .enumeration: return op ? "name(p: Type) : Type" : "VALUE"
        default: return op ? "name(p: Type) : Type" : "name : Type = value"
        }
    }
    var showVis: Bool { n.kind == .klass || n.kind == .interface || (n.kind == .enumeration && op) }

    func update(_ i: Int, _ f: @escaping (inout Member) -> Void) {
        let isOp = op
        s.updateNode(n.id) { node in
            if isOp { if i < node.ops.count { f(&node.ops[i]) } } else { if i < node.attrs.count { f(&node.attrs[i]) } }
        }
    }

    func remove(_ i: Int) {
        let isOp = op
        s.updateNode(n.id) { node in
            if isOp { if i < node.ops.count { node.ops.remove(at: i) } } else { if i < node.attrs.count { node.attrs.remove(at: i) } }
        }
    }

    func move(_ i: Int, _ by: Int) {
        let isOp = op
        s.updateNode(n.id) { node in
            let j = i + by
            if isOp { if i < node.ops.count && j >= 0 && j < node.ops.count { node.ops.swapAt(i, j) } }
            else { if i < node.attrs.count && j >= 0 && j < node.attrs.count { node.attrs.swapAt(i, j) } }
        }
    }

    var body: some View {
        let list = op ? n.ops : n.attrs
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(title).font(.system(size: 11, weight: .medium)).foregroundStyle(T.muted)
                Spacer()
                Button {
                    s.selection = [n.id]
                    s.addMember(op: op)
                } label: { Image(systemName: "plus.circle.fill").foregroundStyle(T.accent) }
                .buttonStyle(.plain)
                .help("Add")
            }
            if list.isEmpty {
                Text("None yet – click + or double-click the shape").font(.system(size: 11)).foregroundStyle(T.muted)
            }
            ForEach(Array(list.enumerated()), id: \.element.id) { i, m in
                row(i, m, count: list.count)
            }
        }
    }

    @ViewBuilder
    func row(_ i: Int, _ m: Member, count: Int) -> some View {
        HStack(spacing: 4) {
            if showVis {
                Menu {
                    ForEach(Visibility.allCases, id: \.self) { v in
                        Button("\(v.rawValue)   \(v.explain)") { update(i) { $0.vis = v } }
                    }
                } label: {
                    Text(m.vis.rawValue).font(.system(size: 12, weight: .bold, design: .monospaced))
                }
                .menuStyle(.borderlessButton)
                .menuIndicator(.hidden)
                .frame(width: 18)
                .help(m.vis.explain)
            }
            CommitField(text: op ? UMLText.opEdit(m) : UMLText.attrEdit(m, kind: n.kind), placeholder: placeholder, mono: true) { v in
                if v.trimmed.isEmpty { remove(i); return }
                let k = n.kind
                let isOp = op
                update(i) { $0 = UMLText.apply(v, to: $0, op: isOp, kind: k) }
            }
            .frame(height: 22)
            if n.kind == .entity {
                ForEach(["PK", "FK", "NN", "UQ"], id: \.self) { flag in
                    let on = flag == "PK" ? m.pk : flag == "FK" ? m.fk : flag == "NN" ? !m.nullable : m.unique
                    Button(flag) {
                        update(i) { c in
                            switch flag {
                            case "PK": c.pk.toggle(); if c.pk { c.nullable = false }
                            case "FK": c.fk.toggle()
                            case "NN": c.nullable.toggle()
                            default: c.unique.toggle()
                            }
                        }
                    }
                    .buttonStyle(.plain)
                    .font(.system(size: 8.5, weight: .bold))
                    .frame(width: 20, height: 18)
                    .foregroundStyle(on ? Color.white : T.muted)
                    .background(on ? (flag == "PK" ? T.orange : flag == "FK" ? T.blue : T.accent) : Color.primary.opacity(0.07), in: RoundedRectangle(cornerRadius: 4))
                    .help(flag == "PK" ? "Primary key" : flag == "FK" ? "Foreign key" : flag == "NN" ? "Not null" : "Unique")
                }
            }
            Menu {
                if n.kind == .klass || n.kind == .interface || (n.kind == .enumeration && op) {
                    Toggle("Static (underlined)", isOn: Binding(get: { m.isStatic }, set: { v in update(i) { $0.isStatic = v } }))
                    if op {
                        Toggle("Abstract (italic)", isOn: Binding(get: { m.isAbstract }, set: { v in update(i) { $0.isAbstract = v } }))
                    } else {
                        Toggle("Final (constant)", isOn: Binding(get: { m.isFinal }, set: { v in update(i) { $0.isFinal = v } }))
                    }
                    Divider()
                }
                if n.kind == .entity, let d = s.diagram {
                    Menu("References") {
                        Button("None") { update(i) { $0.ref = "" } }
                        ForEach(d.nodes.filter { $0.kind == .entity && $0.id != n.id }) { t in
                            ForEach(t.attrs.filter(\.pk)) { c in
                                Button("\(t.name).\(c.name)") { update(i) { $0.ref = "\(t.name).\(c.name)"; $0.fk = true } }
                            }
                        }
                    }
                    Divider()
                }
                Button("Move Up") { move(i, -1) }.disabled(i == 0)
                Button("Move Down") { move(i, 1) }.disabled(i == count - 1)
                Divider()
                Button("Delete") { remove(i) }
            } label: {
                Image(systemName: "ellipsis").font(.system(size: 11))
            }
            .menuStyle(.borderlessButton)
            .menuIndicator(.hidden)
            .frame(width: 18)
        }
    }
}

struct EdgeProps: View {
    @ObservedObject var s: Store
    let e: Edge
    @Environment(\.colorScheme) private var scheme

    func set(_ key: String? = nil, _ f: @escaping (inout Edge) -> Void) { s.updateEdge(e.id, key: key, f) }

    var labelTitle: String {
        switch e.kind {
        case .transition: return "Trigger [guard] / action"
        case .controlFlow, .objectFlow, .sequenceFlow, .flow: return "Guard or label, e.g. [valid]"
        case .message, .asyncMessage, .create: return "Method call, e.g. pay(amount)"
        case .reply: return "Returned value"
        default: return "Name"
        }
    }

    var body: some View {
        let from = s.node(e.from)
        let to = s.node(e.to)
        VStack(alignment: .leading, spacing: 12) {
            KindHeader(image: Thumbs.edge(e.kind, scheme == .dark, size: 30), title: e.kind.title, subtitle: e.kind.javaHint)

            if let d = s.diagram {
                Labeled(label: "Type") {
                    Picker("", selection: Binding(get: { e.kind }, set: { k in set { $0.kind = k } })) {
                        ForEach(d.type.edges, id: \.self) { Text($0.title).tag($0) }
                    }
                    .labelsHidden()
                }
            }
            HStack(spacing: 6) {
                Text(from.map { $0.name.isEmpty ? $0.kind.title : $0.name } ?? "?").font(.system(size: 12, weight: .medium)).lineLimit(1)
                Image(systemName: "arrow.right").font(.system(size: 10)).foregroundStyle(T.muted)
                Text(to.map { $0.name.isEmpty ? $0.kind.title : $0.name } ?? "?").font(.system(size: 12, weight: .medium)).lineLimit(1)
                Spacer()
                Button("Reverse") {
                    set { x in
                        swap(&x.from, &x.to); swap(&x.fromMult, &x.toMult); swap(&x.fromRole, &x.toRole)
                        x.points.reverse()
                    }
                }
                .buttonStyle(PillStyle())
            }
            Labeled(label: labelTitle) {
                CommitField(text: e.name, placeholder: "optional") { v in set { $0.name = v } }.frame(height: 22)
            }

            if e.kind == .relationship {
                Labeled(label: "Cardinality") {
                    HStack {
                        multPicker(e.fromMult, ["1", "0..1"]) { v in set { $0.fromMult = v } }
                        Text("to").foregroundStyle(T.muted).font(.system(size: 11))
                        multPicker(e.toMult, ["1", "0..1", "1..*", "0..*"]) { v in set { $0.toMult = v } }
                    }
                }
            } else if e.kind.hasEnds {
                endEditor("Source end (\(from?.name ?? ""))", mult: e.fromMult, role: e.fromRole, setMult: { v in set { $0.fromMult = v } }, setRole: { v in set { $0.fromRole = v } })
                endEditor("Target end (\(to?.name ?? ""))", mult: e.toMult, role: e.toRole, setMult: { v in set { $0.toMult = v } }, setRole: { v in set { $0.toRole = v } })
            }

            if !e.kind.isMessage || s.diagram?.type != .sequence {
                Labeled(label: "Line style") {
                    Picker("", selection: Binding(get: { e.routing }, set: { r in set { $0.routing = r; $0.points = [] } })) {
                        ForEach(Routing.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()
                }
                if !e.points.isEmpty {
                    Button("Remove bend points") { set { $0.points = [] } }.buttonStyle(PillStyle())
                }
            }

            Labeled(label: "Documentation") {
                CommitTextView(text: e.doc) { v in set { $0.doc = v } }
                    .frame(height: 56)
                    .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }

    func multPicker(_ value: String, _ options: [String], _ onSet: @escaping (String) -> Void) -> some View {
        Picker("", selection: Binding(get: { options.contains(value) ? value : options[0] }, set: onSet)) {
            ForEach(options, id: \.self) { Text($0).tag($0) }
        }
        .labelsHidden()
        .frame(width: 90)
    }

    func endEditor(_ title: String, mult: String, role: String, setMult: @escaping (String) -> Void, setRole: @escaping (String) -> Void) -> some View {
        Labeled(label: title) {
            HStack(spacing: 6) {
                CommitField(text: role, placeholder: "role") { setRole($0) }.frame(height: 22)
                CommitField(text: mult, placeholder: "mult.") { setMult($0) }.frame(width: 56, height: 22)
                Menu {
                    ForEach(["1", "0..1", "*", "0..*", "1..*"], id: \.self) { m in Button(m) { setMult(m) } }
                    Button("None") { setMult("") }
                } label: { Image(systemName: "chevron.down").font(.system(size: 9)) }
                .menuStyle(.borderlessButton)
                .menuIndicator(.hidden)
                .frame(width: 18)
            }
        }
    }
}

struct MultiProps: View {
    @ObservedObject var s: Store
    let count: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("\(count) selected").font(.system(size: 14, weight: .semibold))
            Labeled(label: "Align") {
                HStack(spacing: 4) {
                    iconButton("align.horizontal.left", "Left") { s.align(0) }
                    iconButton("align.horizontal.center", "Centre") { s.align(1) }
                    iconButton("align.horizontal.right", "Right") { s.align(2) }
                    iconButton("align.vertical.top", "Top") { s.align(3) }
                    iconButton("align.vertical.center", "Middle") { s.align(4) }
                    iconButton("align.vertical.bottom", "Bottom") { s.align(5) }
                }
            }
            Labeled(label: "Distribute and size") {
                HStack(spacing: 4) {
                    iconButton("distribute.horizontal.center", "Distribute horizontally") { s.distribute(horizontal: true) }
                    iconButton("distribute.vertical.center", "Distribute vertically") { s.distribute(horizontal: false) }
                    iconButton("arrow.left.and.right", "Same width") { s.sameSize(0) }
                    iconButton("arrow.up.and.down", "Same height") { s.sameSize(1) }
                    iconButton("arrow.up.left.and.arrow.down.right", "Same size") { s.sameSize(2) }
                }
            }
            Labeled(label: "Connectors") {
                Picker("", selection: Binding(get: { Routing.straight }, set: { s.setRouting($0) })) {
                    ForEach(Routing.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                .pickerStyle(.segmented)
                .labelsHidden()
            }
            HStack {
                Button("Bring to Front") { s.order(0) }.buttonStyle(PillStyle())
                Button("Send to Back") { s.order(3) }.buttonStyle(PillStyle())
            }
            HStack {
                Button("Duplicate") { s.duplicate() }.buttonStyle(PillStyle())
                Button("Delete") { s.deleteSelection() }.buttonStyle(PillStyle())
            }
        }
    }

    func iconButton(_ icon: String, _ help: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon).font(.system(size: 13)).frame(width: 34, height: 28)
                .background(Color.primary.opacity(0.07), in: RoundedRectangle(cornerRadius: 7))
        }
        .buttonStyle(.plain)
        .help(help)
    }
}

struct DiagramProps: View {
    @ObservedObject var s: Store
    let d: Diagram

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: d.type.icon).font(.system(size: 20)).foregroundStyle(T.accent).frame(width: 30)
                VStack(alignment: .leading, spacing: 1) {
                    Text(d.type.title).font(.system(size: 14, weight: .semibold))
                    Text(d.type.blurb).font(.system(size: 11)).foregroundStyle(T.muted).fixedSize(horizontal: false, vertical: true)
                }
            }
            Labeled(label: "Diagram name") {
                CommitField(text: d.name) { v in s.renameDiagram(d.id, v) }.frame(height: 22)
            }
            Labeled(label: "Description") {
                CommitTextView(text: d.doc) { v in s.edit { $0.doc = v } }
                    .frame(height: 64)
                    .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))
            }
            HStack(spacing: 18) {
                stat(d.nodes.count, "shapes")
                stat(d.edges.count, "connectors")
                stat(s.project.diagrams.count, "diagrams")
            }
            Labeled(label: "Auto layout") {
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(LayoutStyle.allCases, id: \.self) { st in
                        Button(st.title) { s.autoLayout(st) }.buttonStyle(PillStyle(prominent: st == LayoutStyle.preferred(d.type)))
                    }
                }
            }
            Labeled(label: "Canvas") {
                VStack(alignment: .leading, spacing: 6) {
                    Toggle("Show grid", isOn: $s.showGrid).toggleStyle(.checkbox)
                    Toggle("Snap to grid", isOn: $s.snap).toggleStyle(.checkbox)
                    Toggle("Show overview", isOn: $s.showOverview).toggleStyle(.checkbox)
                    Picker("Paper", selection: $s.canvasTheme) {
                        Text("Match system").tag(0)
                        Text("Light").tag(1)
                        Text("Dark").tag(2)
                    }
                    .frame(width: 200)
                }
                .font(.system(size: 12))
            }
            Labeled(label: "Export") {
                HStack(spacing: 6) {
                    Button("PNG") { Exporter.exportCurrent(s, .png) }.buttonStyle(PillStyle())
                    Button("PDF") { Exporter.exportCurrent(s, .pdf) }.buttonStyle(PillStyle())
                    Button("SVG") { Exporter.exportCurrent(s, .svg) }.buttonStyle(PillStyle())
                    Button("Print") { Exporter.printDiagram(s) }.buttonStyle(PillStyle())
                }
            }
            Divider()
            ProjectProps(s: s)
        }
    }

    func stat(_ n: Int, _ label: String) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("\(n)").font(.system(size: 22, weight: .semibold)).monospacedDigit()
            Text(label).font(.system(size: 11)).foregroundStyle(T.muted)
        }
    }
}

struct ProjectProps: View {
    @ObservedObject var s: Store
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Project").font(.system(size: 14, weight: .semibold))
            Labeled(label: "Project name") {
                CommitField(text: s.project.name) { v in s.editProject { $0.name = v } }.frame(height: 22)
            }
            Labeled(label: "Author") {
                CommitField(text: s.project.author, placeholder: "Your name") { v in s.editProject { $0.author = v } }.frame(height: 22)
            }
            Labeled(label: "About this project") {
                CommitTextView(text: s.project.doc) { v in s.editProject { $0.doc = v } }
                    .frame(height: 56)
                    .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }
}

// MARK: - format

struct FormatPane: View {
    @ObservedObject var s: Store

    static let lines: [String?] = [nil, "#2F7BF6", "#2F9C76", "#D48B2C", "#D64545", "#7C57D6", "#1F2329", "#8A94A6"]

    func setNodes(_ key: String, _ f: @escaping (inout Node) -> Void) {
        let ids = s.selection
        s.edit(key) { d in
            for i in d.nodes.indices where ids.contains(d.nodes[i].id) {
                f(&d.nodes[i])
                Store.fit(&d.nodes[i])
            }
        }
    }

    func setEdges(_ key: String, _ f: @escaping (inout Edge) -> Void) {
        let ids = s.selection
        s.edit(key) { d in
            for i in d.edges.indices where ids.contains(d.edges[i].id) { f(&d.edges[i]) }
        }
    }

    var body: some View {
        let nodes = s.selectedNodes
        let edges = s.selectedEdges
        VStack(alignment: .leading, spacing: 14) {
            if nodes.isEmpty && edges.isEmpty {
                Text("Select shapes or connectors to change their colours, lines and fonts.")
                    .font(.system(size: 12)).foregroundStyle(T.muted)
            }
            if let n = nodes.first {
                Labeled(label: "Fill") {
                    swatches(CanvasView.fills.map(\.1), current: n.fill) { h in setNodes("fill") { $0.fill = h } }
                    ColorPicker("Custom fill", selection: Binding(get: { Color(hexString: n.fill) ?? .white }, set: { c in setNodes("fillc") { $0.fill = c.hexString } }))
                        .font(.system(size: 12))
                }
                Labeled(label: "Outline") {
                    swatches(FormatPane.lines, current: n.stroke) { h in setNodes("stroke") { $0.stroke = h } }
                }
                Labeled(label: "Text colour") {
                    swatches([nil, "#1F2329", "#FFFFFF", "#2F7BF6", "#D64545", "#2F9C76"], current: n.textColor) { h in setNodes("text") { $0.textColor = h } }
                }
                Labeled(label: "Font size") {
                    HStack {
                        Stepper(value: Binding(get: { n.fontSize ?? 12 }, set: { v in setNodes("font") { $0.fontSize = v } }), in: 8...32, step: 1) {
                            Text("\(Int(n.fontSize ?? 12)) pt").monospacedDigit().font(.system(size: 12))
                        }
                        if n.fontSize != nil { Button("Reset") { setNodes("font") { $0.fontSize = nil } }.buttonStyle(PillStyle()) }
                    }
                }
            }
            if let e = edges.first {
                Labeled(label: "Line colour") {
                    swatches(FormatPane.lines, current: e.stroke) { h in setEdges("estroke") { $0.stroke = h } }
                }
                Labeled(label: "Line width") {
                    Stepper(value: Binding(get: { e.width ?? 1.2 }, set: { v in setEdges("ewidth") { $0.width = v } }), in: 0.6...6, step: 0.4) {
                        Text(String(format: "%.1f", e.width ?? 1.2)).monospacedDigit().font(.system(size: 12))
                    }
                }
            }
            if !nodes.isEmpty {
                HStack {
                    Button("Copy Format") { s.copyFormat() }.buttonStyle(PillStyle())
                    Button("Paste Format") { s.pasteFormat() }.buttonStyle(PillStyle()).disabled(s.copiedStyle == nil)
                }
            }
        }
    }

    func swatches(_ list: [String?], current: String?, _ pick: @escaping (String?) -> Void) -> some View {
        LazyVGrid(columns: Array(repeating: GridItem(.fixed(22), spacing: 5), count: 8), alignment: .leading, spacing: 5) {
            ForEach(Array(list.enumerated()), id: \.offset) { _, h in
                Button { pick(h) } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 5).fill(h.map { Color(nsColor: NSColor(hex: $0)) } ?? Color.clear)
                        RoundedRectangle(cornerRadius: 5).stroke(current == h ? T.accent : T.line, lineWidth: current == h ? 2 : 0.8)
                        if h == nil { Image(systemName: "slash.circle").font(.system(size: 11)).foregroundStyle(T.muted) }
                    }
                    .frame(width: 22, height: 22)
                }
                .buttonStyle(.plain)
                .help(h ?? "Default")
            }
        }
    }
}

// MARK: - code

struct CodePane: View {
    @ObservedObject var s: Store
    @StateObject private var jpa = Box(false)

    var body: some View {
        let nodes = s.selectedNodes
        VStack(alignment: .leading, spacing: 10) {
            if nodes.count == 1, let n = nodes.first, JavaGen.classKinds.contains(n.kind), let f = JavaGen.file(for: n.id, in: s.project, s.javaOpts) {
                header("\(f.name)", "Updates as you edit the diagram")
                Toggle("Explain the UML in comments", isOn: $s.javaOpts.explain).toggleStyle(.checkbox).font(.system(size: 12))
                CodeView(code: f.code, lang: .java).frame(minHeight: 380)
                buttons(copy: f.code) { s.codeFocus = n.id; s.sheet = .java }
            } else if nodes.count == 1, let n = nodes.first, n.kind == .entity, let d = s.diagram {
                header(n.name, "The table as SQL, or as a Java class for JPA")
                Picker("", selection: $jpa.v) { Text("SQL").tag(false); Text("JPA (Java)").tag(true) }.pickerStyle(.segmented).labelsHidden()
                let code = jpa.v ? (SQLGen.jpa([(n, d)], explain: s.javaOpts.explain).first?.code ?? "")
                                 : SQLGen.ddl([(n, d)], .standard, title: n.name)
                CodeView(code: code, lang: jpa.v ? .java : .sql).frame(minHeight: 380)
                buttons(copy: code) { s.codeFocus = n.id; s.sheet = .sql }
            } else if let d = s.diagram, d.type == .stateMachine {
                header("State machine in Java", "An enum for the states, one method per event")
                let code = StateGen.java(d)
                CodeView(code: code, lang: .java).frame(minHeight: 380)
                buttons(copy: code, more: nil)
            } else if let d = s.diagram, d.type == .sequence {
                header("Calls in Java", "Each message is a method call, top to bottom")
                let code = SequenceGen.java(d)
                CodeView(code: code, lang: .java).frame(minHeight: 300)
                buttons(copy: code, more: nil)
            } else {
                Text("Select a class, interface, enum or table to see its code here. It changes while you edit.")
                    .font(.system(size: 12)).foregroundStyle(T.muted)
                Button("Generate Java for all classes…") { s.codeFocus = nil; s.sheet = .java }.buttonStyle(PillStyle(prominent: true))
                Button("Generate SQL / JPA…") { s.codeFocus = nil; s.sheet = .sql }.buttonStyle(PillStyle())
                Button("Reverse Engineer Java…") { s.sheet = .reverseJava }.buttonStyle(PillStyle())
                Button("Reverse Engineer SQL…") { s.sheet = .reverseSQL }.buttonStyle(PillStyle())
            }
        }
    }

    func header(_ t: String, _ sub: String) -> some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(t).font(.system(size: 14, weight: .semibold))
            Text(sub).font(.system(size: 11)).foregroundStyle(T.muted)
        }
    }

    func buttons(copy: String, more: (() -> Void)?) -> some View {
        HStack {
            Button("Copy") {
                NSPasteboard.general.clearContents()
                NSPasteboard.general.setString(copy, forType: .string)
                s.flash("Code copied")
            }
            .buttonStyle(PillStyle())
            if let more { Button("All Files…", action: more).buttonStyle(PillStyle(prominent: true)) }
        }
    }
}

/// a state machine as a Java class: enum of states and a method per event
enum StateGen {
    static func constant(_ s: String) -> String {
        let w = s.trimmed.replacingOccurrences(of: "([a-z])([A-Z])", with: "$1_$2", options: .regularExpression)
        let c = w.uppercased().map { $0.isLetter || $0.isNumber ? $0 : "_" }
        let r = String(c).replacingOccurrences(of: "_+", with: "_", options: .regularExpression).trimmingCharacters(in: CharacterSet(charactersIn: "_"))
        return r.isEmpty ? "STATE" : r
    }

    /// "pay [ok] / charge()" -> ("pay", "ok", "charge()")
    static func parse(_ t: String) -> (String, String, String) {
        var event = t, guardText = "", action = ""
        if let slash = event.firstIndex(of: "/") {
            action = event[event.index(after: slash)...].trimmed
            event = String(event[..<slash])
        }
        if let o = event.firstIndex(of: "["), let c = event.firstIndex(of: "]"), o < c {
            guardText = event[event.index(after: o)..<c].trimmed
            event = String(event[..<o])
        }
        return (event.trimmed, guardText, action)
    }

    /// a guard in Java: expressions stay, words become a boolean method ("refund ok" -> refundOk())
    static func condition(_ g: String, _ helpers: inout [String: String]) -> String {
        let t = g.trimmed
        if t.isEmpty || t.lowercased() == "else" { return "" }
        if t.rangeOfCharacter(from: CharacterSet(charactersIn: "<>=!&|().")) != nil { return t }
        let name = JavaNames.member(t)
        helpers[name] = "    private boolean \(name)() {\n        return true; // TODO: the condition “\(t)”\n    }"
        return "\(name)()"
    }

    /// actions become method calls; plain names get an empty helper method
    static func calls(_ a: String, _ helpers: inout [String: String]) -> [String] {
        a.split(separator: ";").map { $0.trimmed }.filter { !$0.isEmpty }.map { act in
            var call = act
            if !call.contains("(") { call = JavaNames.member(call) + "()" }
            let name = String(call.prefix { $0 != "(" }).trimmed
            if call.hasSuffix("()") && JavaNames.isIdentifier(name) && helpers[name] == nil {
                helpers[name] = "    private void \(name)() {\n        // TODO: \(act)\n    }"
            }
            return call + ";"
        }
    }

    static func java(_ d: Diagram) -> String {
        let states = d.nodes.filter { $0.kind == .state }
        guard !states.isEmpty else { return "// add some states and transitions first\n" }
        let byId = Dictionary(uniqueKeysWithValues: d.nodes.map { ($0.id, $0) })
        var helpers: [String: String] = [:]
        let cls = JavaNames.type(d.name)
        var L: [String] = ["public class \(cls) {", ""]
        L.append("    public enum State { \(states.map { constant($0.name) }.joined(separator: ", ")) }")
        L.append("")
        let start = d.edges.first { byId[$0.from]?.kind == .initial }.flatMap { byId[$0.to] }
        L.append("    private State state = State.\(constant(start?.name ?? states[0].name));   // where the black dot points")
        L.append("")
        L.append("    public State getState() {")
        L.append("        return state;")
        L.append("    }")

        struct Move { let from: Node; let to: Node?; let guardText: String; let action: String }
        var events: [String: [Move]] = [:]
        var order: [String] = []
        for e in d.edges where e.kind == .transition {
            guard let from = byId[e.from], from.kind == .state else { continue }
            let (ev, g, a) = parse(e.name)
            if ev.isEmpty && byId[e.to]?.kind == .final && a.isEmpty { continue }
            let name = JavaNames.member(ev.isEmpty ? "next" : ev.replacingOccurrences(of: "()", with: ""))
            if events[name] == nil { order.append(name) }
            events[name, default: []].append(Move(from: from, to: byId[e.to], guardText: g, action: a))
        }
        for ev in order {
            L.append("")
            L.append("    public void \(ev)() {")
            L.append("        switch (state) {")
            var groups: [(String, [Move])] = []
            for m in events[ev]! {
                let c = constant(m.from.name)
                if let i = groups.firstIndex(where: { $0.0 == c }) { groups[i].1.append(m) } else { groups.append((c, [m])) }
            }
            for (c, moves) in groups {
                L.append("            case \(c) -> {")
                // guarded moves first, the unguarded one (or [else]) last
                let unguarded: (Move) -> Bool = { $0.guardText.trimmed.isEmpty || $0.guardText.trimmed.lowercased() == "else" }
                for m in moves.filter({ !unguarded($0) }) + moves.filter(unguarded) {
                    let cond = condition(m.guardText, &helpers)
                    var body: [String] = []
                    if !m.from.prop("exit").isEmpty { body += calls(m.from.prop("exit"), &helpers) }
                    body += calls(m.action, &helpers)
                    if let to = m.to, to.kind == .state {
                        body.append("state = State.\(constant(to.name));")
                        if !to.prop("entry").isEmpty { body += calls(to.prop("entry"), &helpers) }
                    } else if m.to?.kind == .final {
                        body.append("// the machine ends here")
                    }
                    if cond.isEmpty {
                        body.forEach { L.append("                \($0)") }
                    } else {
                        L.append("                if (\(cond)) {")
                        body.forEach { L.append("                    \($0)") }
                        L.append("                    return;")
                        L.append("                }")
                    }
                }
                L.append("            }")
            }
            L.append("            default -> throw new IllegalStateException(\"\(ev) is not allowed in \" + state);")
            L.append("        }")
            L.append("    }")
        }
        for st in states where !st.prop("do").isEmpty {
            L.append("")
            L.append("    // while in \(st.name): do / \(st.prop("do"))")
        }
        if !helpers.isEmpty {
            L.append("")
            L.append("    // ── conditions and actions from the diagram: fill them in")
            for k in helpers.keys.sorted() {
                L.append("")
                L.append(helpers[k]!)
            }
        }
        L.append("}")
        return L.joined(separator: "\n") + "\n"
    }
}

/// the messages of a sequence diagram as Java calls
enum SequenceGen {
    static func java(_ d: Diagram) -> String {
        let byId = Dictionary(uniqueKeysWithValues: d.nodes.map { ($0.id, $0) })
        func objName(_ n: Node?) -> String {
            guard let n else { return "obj" }
            if !n.name.isEmpty { return JavaNames.member(n.name) }
            let c = n.prop("classifier")
            return c.isEmpty ? "obj" : JavaNames.member(c.lowerFirst)
        }
        var L: [String] = ["// read from top to bottom – one line per message", ""]
        var current: UUID? = nil
        for e in d.edges.filter({ $0.kind.isMessage }).sorted(by: { ($0.y ?? 0) < ($1.y ?? 0) }) {
            let a = byId[e.from], b = byId[e.to]
            if current != e.from {
                if current != nil { L.append("") }
                L.append("// inside \(a.map { $0.prop("classifier").isEmpty ? objName($0) : $0.prop("classifier") } ?? "?"):")
                current = e.from
            }
            var call = e.name.trimmed
            if call.isEmpty { call = "call" }
            if !call.contains("(") { call += "()" }
            switch e.kind {
            case .create:
                let c = b?.prop("classifier").isEmpty == false ? b!.prop("classifier") : JavaNames.type(objName(b))
                L.append("\(c) \(objName(b)) = new \(c)(\(call.components(separatedBy: "(").dropFirst().joined(separator: "(").dropLast()));")
            case .reply:
                L.append("return \(e.name.isEmpty ? "result" : e.name);   // back to \(objName(b))")
            case .asyncMessage:
                L.append("executor.submit(() -> \(objName(b)).\(call));   // asynchronous: doesn't wait")
            default:
                L.append(e.from == e.to ? "this.\(call);" : "\(objName(b)).\(call);")
            }
        }
        if L.count == 2 { L.append("// no messages yet: drag down a lifeline's dashed line to another lifeline") }
        return L.joined(separator: "\n") + "\n"
    }
}
