import AppKit
import Combine
import UniformTypeIdentifiers

enum SheetKind: String, Identifiable {
    case java, reverseJava, sql, reverseSQL, validate, learn, newDiagram, shortcuts
    var id: String { rawValue }
}

struct Snap {
    var project: Project
    var current: UUID?
    var selection: Set<UUID>
}

struct ModelItem: Identifiable {
    var id: UUID
    var name: String
    var kind: NodeKind
    var diagram: UUID
    var diagramName: String
}

struct ClipData: Codable {
    var nodes: [Node]
    var edges: [Edge]
    var type: DiagramType
}

struct StyleCopy {
    var fill: String?
    var stroke: String?
    var textColor: String?
    var fontSize: Double?
}

final class Store: ObservableObject {
    @Published var project: Project
    @Published var currentId: UUID?
    @Published var tabs: [UUID] = []
    @Published var selection: Set<UUID> = []
    @Published var tool: Tool? = nil
    @Published var zoom: CGFloat = 1
    @Published var sheet: SheetKind?
    @Published var search = ""
    @Published var inspectorTab = 0
    @Published var fileURL: URL?
    @Published var dirty = false
    @Published var toast: String?
    @Published var issues: [Issue] = []
    @Published var javaOpts = JavaOptions()
    @Published var codeFocus: UUID?
    @Published var renamingDiagram: UUID?
    /// bumped by Edit ▸ Find to put the cursor in the search field
    @Published var focusSearch = 0

    // view preferences, shared by all windows
    @Published var showGrid = Prefs.bool("showGrid", true) { didSet { Prefs.set("showGrid", showGrid) } }
    @Published var snap = Prefs.bool("snap", true) { didSet { Prefs.set("snap", snap) } }
    @Published var showOverview = Prefs.bool("showOverview", true) { didSet { Prefs.set("showOverview", showOverview) } }
    @Published var showInspector = Prefs.bool("showInspector", true) { didSet { Prefs.set("showInspector", showInspector) } }
    @Published var showSidebar = Prefs.bool("showSidebar", true) { didSet { Prefs.set("showSidebar", showSidebar) } }
    /// 0 = follow the system, 1 = light, 2 = dark
    @Published var canvasTheme = UserDefaults.standard.integer(forKey: "canvasTheme") { didSet { UserDefaults.standard.set(canvasTheme, forKey: "canvasTheme") } }
    let gridSize: CGFloat = 10

    weak var canvas: CanvasView?
    weak var overview: OverviewView?
    weak var window: NSWindow?
    var copiedStyle: StyleCopy?
    var viewState: [UUID: (CGPoint, CGFloat)] = [:]
    private var undoStack: [Snap] = []
    private var redoStack: [Snap] = []
    private var lastKey: String?
    private var lastTime = Date.distantPast
    private var pasteCount = 0
    private var toastTimer: Timer?

    init(project: Project = Project(), url: URL? = nil) {
        self.project = project
        self.fileURL = url
        if let first = project.diagrams.first {
            currentId = first.id
            tabs = [first.id]
        }
    }

    var diagram: Diagram? { project.diagram(currentId) }
    var title: String { fileURL?.deletingPathExtension().lastPathComponent ?? project.name }

    // MARK: undo

    /// saves the state before a change; changes with the same key close together become one undo step
    func checkpoint(_ key: String? = nil) {
        let now = Date()
        if let key, key == lastKey, now.timeIntervalSince(lastTime) < 1.5 {
            lastTime = now
            return
        }
        undoStack.append(Snap(project: project, current: currentId, selection: selection))
        if undoStack.count > 300 { undoStack.removeFirst(undoStack.count - 300) }
        redoStack.removeAll()
        lastKey = key
        lastTime = now
    }

    var canUndo: Bool { !undoStack.isEmpty }
    var canRedo: Bool { !redoStack.isEmpty }

    func undo() {
        guard let s = undoStack.popLast() else { NSSound.beep(); return }
        redoStack.append(Snap(project: project, current: currentId, selection: selection))
        restore(s)
    }

    func redo() {
        guard let s = redoStack.popLast() else { NSSound.beep(); return }
        undoStack.append(Snap(project: project, current: currentId, selection: selection))
        restore(s)
    }

    private func restore(_ s: Snap) {
        canvas?.cancelEditing()
        project = s.project
        if let c = s.current, project.diagram(c) != nil {
            if currentId != c { open(c) }
        } else if project.diagram(currentId) == nil {
            currentId = project.diagrams.first?.id
        }
        tabs = tabs.filter { project.diagram($0) != nil }
        if let c = currentId, !tabs.contains(c) { tabs.append(c) }
        let valid = Set((diagram?.nodes.map(\.id) ?? []) + (diagram?.edges.map(\.id) ?? []))
        selection = s.selection.intersection(valid)
        dirty = true
        lastKey = nil
    }

    // MARK: changing things

    func edit(_ key: String? = nil, _ f: (inout Diagram) -> Void) {
        guard let i = project.dindex(currentId) else { return }
        checkpoint(key)
        f(&project.diagrams[i])
        dirty = true
    }

    func editProject(_ key: String? = nil, _ f: (inout Project) -> Void) {
        checkpoint(key)
        f(&project)
        dirty = true
    }

    /// replaces the current diagram with one changed elsewhere (the canvas after a drag)
    func commit(_ d: Diagram, key: String? = nil) {
        guard let i = project.dindex(d.id) else { return }
        checkpoint(key)
        project.diagrams[i] = d
        dirty = true
    }

    func node(_ id: UUID) -> Node? { diagram?.node(id) }
    func edge(_ id: UUID) -> Edge? { diagram?.edges.first { $0.id == id } }

    var selectedNodes: [Node] { diagram?.nodes.filter { selection.contains($0.id) } ?? [] }
    var selectedEdges: [Edge] { diagram?.edges.filter { selection.contains($0.id) } ?? [] }

    func updateNode(_ id: UUID, key: String? = nil, _ f: (inout Node) -> Void) {
        edit(key) { d in
            if let i = d.index(id) {
                f(&d.nodes[i])
                Store.fit(&d.nodes[i])
            }
        }
    }

    func updateEdge(_ id: UUID, key: String? = nil, _ f: (inout Edge) -> Void) {
        edit(key) { d in
            if let i = d.edgeIndex(id) { f(&d.edges[i]) }
        }
    }

    /// class boxes and tables are exactly as tall as their contents
    static func fit(_ n: inout Node) {
        if n.kind.isClassifier {
            let L = ClassLayout.of(n)
            n.frame.size.height = L.size.height
            n.frame.size.width = max(n.frame.width, L.size.width)
        } else if n.kind == .entity {
            let L = EntityLayout.of(n)
            n.frame.size.height = L.size.height
            n.frame.size.width = max(n.frame.width, L.size.width)
        }
    }

    static func minSize(_ n: Node) -> CGSize {
        if n.kind.isClassifier { return ClassLayout.of(n).size }
        if n.kind == .entity { return EntityLayout.of(n).size }
        if n.kind == .fork { return CGSize(width: 4, height: 4) }
        return CGSize(width: 16, height: 16)
    }

    // MARK: adding

    static func uniqueName(_ k: NodeKind, _ d: Diagram) -> String {
        let base = k.info.name
        if base.isEmpty || k.unnamed { return "" }
        let names = Set(d.nodes.map(\.name))
        if !names.contains(base) { return base }
        var i = 2
        while names.contains("\(base)\(i)") { i += 1 }
        return "\(base)\(i)"
    }

    static func makeNode(_ k: NodeKind, center p: CGPoint, in d: Diagram, grid: CGFloat?) -> Node {
        var s = k.info.size
        if k == .lane && d.type == .bpmn { s = CGSize(width: 730, height: 180) }
        var n = Node(kind: k, frame: CGRect(x: p.x - s.width / 2, y: p.y - s.height / 2, width: s.width, height: s.height), name: uniqueName(k, d))
        switch k {
        case .enumeration:
            n.attrs = [Member(name: "FIRST", vis: .pub), Member(name: "SECOND", vis: .pub)]
        case .entity:
            n.attrs = [UMLText.column("PK id : INTEGER")]
        case .fragment:
            n.props["operator"] = "loop"
        case .object:
            n.props["classifier"] = "Class"
        case .lifeline:
            n.props["classifier"] = ""
        default: break
        }
        fit(&n)
        if k.isLifeline, let other = d.nodes.first(where: { $0.kind.isLifeline }) {
            n.frame.origin.y = other.frame.minY
            n.frame.size.height = d.nodes.filter { $0.kind.isLifeline }.map { $0.frame.height }.max() ?? n.frame.height
        }
        if let g = grid {
            n.frame.origin.x = (n.frame.minX / g).rounded() * g
            n.frame.origin.y = (n.frame.minY / g).rounded() * g
        }
        n.frame.origin.x = max(10, n.frame.minX)
        n.frame.origin.y = max(10, n.frame.minY)
        return n
    }

    @discardableResult
    func addNode(_ k: NodeKind, at p: CGPoint, select: Bool = true) -> UUID? {
        guard let d = diagram else { return nil }
        let n = Store.makeNode(k, center: p, in: d, grid: snap ? gridSize : nil)
        edit { d in
            if k.info.container { d.nodes.insert(n, at: 0) } else { d.nodes.append(n) }
        }
        if select { selection = [n.id] }
        return n.id
    }

    @discardableResult
    func addEdge(_ k: EdgeKind, from a: UUID, to b: UUID, y: CGFloat? = nil) -> UUID? {
        guard let d = diagram, d.node(a) != nil, d.node(b) != nil else { return nil }
        var id: UUID?
        edit { d in id = Store.connect(&d, k, a, b, y: y) }
        if let id { selection = [id] }
        return id
    }

    /// adds a connector inside a diagram, with the extras some kinds need
    @discardableResult
    static func connect(_ d: inout Diagram, _ k: EdgeKind, _ a: UUID, _ b: UUID, y: CGFloat?) -> UUID? {
        guard let na = d.node(a), let nb = d.node(b) else { return nil }
        var e = Edge(kind: k, from: a, to: b)
        e.routing = k == .branch ? .curved : d.type.routing
        if d.type == .sequence && na.kind.isLifeline && nb.kind.isLifeline {
            e.routing = .straight
            e.y = Double(y ?? Geo.defaultMessageY(na, nb))
            if k == .message || k == .asyncMessage { e.name = "call()" }
        }
        if k == .relationship { e.fromMult = "1"; e.toMult = "0..*" }
        d.edges.append(e)
        // ER diagrams: the "many" table gets a foreign key column pointing at the other table's key
        if k == .relationship, let ia = d.index(a), let ib = d.index(b), ia != ib {
            let pk = d.nodes[ia].attrs.first { $0.pk }
            let table = d.nodes[ia].name.lowercased().replacingOccurrences(of: " ", with: "_")
            let col = "\(table)_\(pk?.name ?? "id")"
            if !d.nodes[ib].attrs.contains(where: { $0.name == col }) {
                var c = Member(name: col, type: pk?.type ?? "INTEGER", vis: .pub)
                c.fk = true
                c.nullable = false
                c.ref = "\(d.nodes[ia].name).\(pk?.name ?? "id")"
                d.nodes[ib].attrs.append(c)
                Store.fit(&d.nodes[ib])
            }
        }
        if let yy = e.y {
            let y = CGFloat(yy)
            if k == .create, let ib = d.index(b) {
                let bottom = d.nodes[ib].frame.maxY
                d.nodes[ib].frame.origin.y = y - Geo.header(d.nodes[ib]).height / 2
                d.nodes[ib].frame.size.height = max(120, bottom - d.nodes[ib].frame.minY)
            }
            Store.growLifelines(&d, to: y)
        }
        return e.id
    }

    static func growLifelines(_ d: inout Diagram, to y: CGFloat) {
        for i in d.nodes.indices where d.nodes[i].kind.isLifeline && d.nodes[i].frame.maxY < y + 50 {
            d.nodes[i].frame.size.height = y + 60 - d.nodes[i].frame.minY
        }
    }

    /// new shape next to `from`, joined to it (dragging a connector onto empty canvas)
    func addConnected(_ k: NodeKind, from a: UUID, at p: CGPoint, edge: EdgeKind?, y: CGFloat?) {
        guard let d = diagram, let src = d.node(a) else { return }
        var n = Store.makeNode(k, center: p, in: d, grid: snap ? gridSize : nil)
        if d.type == .sequence && k.isLifeline && src.kind.isLifeline { n.frame.origin.y = src.frame.minY; n.frame.size.height = src.frame.height }
        let ek = edge ?? d.type.defaultEdge(src, n)
        edit { d in
            if k.info.container { d.nodes.insert(n, at: 0) } else { d.nodes.append(n) }
            Store.connect(&d, ek, a, n.id, y: y)
        }
        selection = [n.id]
        if !k.unnamed { DispatchQueue.main.async { self.canvas?.beginEditName(n.id) } }
    }

    // MARK: members

    func addMember(op: Bool) {
        guard selection.count == 1, let n = selectedNodes.first else { return }
        let new: Member
        switch n.kind {
        case .enumeration: new = op ? Member(name: "operation", type: "void", vis: .pub) : Member(name: "LITERAL", vis: .pub)
        case .entity: new = UMLText.column("column : VARCHAR(255)")
        case .object: new = Member(name: "attribute", vis: .pub, value: "value")
        case .interface: new = op ? Member(name: "operation", type: "void", vis: .pub, isAbstract: false) : Member(name: "CONSTANT", type: "int", vis: .pub, isStatic: true, isFinal: true, value: "0")
        case .klass: new = op ? Member(name: "operation", type: "void", vis: .pub) : Member(name: "attribute", type: "String", vis: .priv)
        default: return
        }
        let isOp = op && n.kind != .entity && n.kind != .object
        updateNode(n.id) { m in if isOp { m.ops.append(new) } else { m.attrs.append(new) } }
        let idx = isOp ? n.ops.count : n.attrs.count
        DispatchQueue.main.async { self.canvas?.beginEditMember(n.id, op: isOp, index: idx) }
    }

    // MARK: delete, copy, paste

    func deleteSelection() {
        guard !selection.isEmpty else { return }
        let ids = selection
        edit { d in
            d.nodes.removeAll { ids.contains($0.id) }
            d.edges.removeAll { ids.contains($0.id) || ids.contains($0.from) || ids.contains($0.to) }
        }
        selection = []
    }

    static let pbType = NSPasteboard.PasteboardType("com.artur.blueprint.shapes")

    private func clip() -> ClipData? {
        guard let d = diagram else { return nil }
        let ns = d.nodes.filter { selection.contains($0.id) }
        guard !ns.isEmpty else { return nil }
        let ids = Set(ns.map(\.id))
        let es = d.edges.filter { ids.contains($0.from) && ids.contains($0.to) }
        return ClipData(nodes: ns, edges: es, type: d.type)
    }

    func copySelection() {
        guard let c = clip(), let d = diagram else { return }
        let pb = NSPasteboard.general
        pb.clearContents()
        if let data = try? JSONEncoder().encode(c) { pb.setData(data, forType: Store.pbType) }
        var sub = d
        sub.nodes = c.nodes
        sub.edges = c.edges
        if let png = Exporter.png(sub, scale: 2, dark: false) { pb.setData(png, forType: .png) }
        pb.setData(Exporter.pdf(sub), forType: .pdf)
        pb.setString(c.nodes.map(\.name).filter { !$0.isEmpty }.joined(separator: "\n"), forType: .string)
        pasteCount = 0
    }

    func cutSelection() {
        copySelection()
        deleteSelection()
    }

    var canPaste: Bool { NSPasteboard.general.data(forType: Store.pbType) != nil && diagram != nil }

    func paste() {
        guard let data = NSPasteboard.general.data(forType: Store.pbType),
              let c = try? JSONDecoder().decode(ClipData.self, from: data) else { return }
        pasteCount += 1
        insert(c, offset: CGPoint(x: 20 * pasteCount, y: 20 * pasteCount))
    }

    func duplicate() {
        guard let c = clip() else { return }
        insert(c, offset: CGPoint(x: 20, y: 20))
    }

    func insert(_ c: ClipData, offset: CGPoint) {
        var map: [UUID: UUID] = [:]
        let ns = c.nodes.map { n -> Node in
            var m = n
            m.id = UUID()
            map[n.id] = m.id
            m.frame = m.frame.offsetBy(dx: offset.x, dy: offset.y)
            m.attrs = m.attrs.map { var a = $0; a.id = UUID(); return a }
            m.ops = m.ops.map { var a = $0; a.id = UUID(); return a }
            return m
        }
        let es = c.edges.compactMap { e -> Edge? in
            guard let f = map[e.from], let t = map[e.to] else { return nil }
            var x = e
            x.id = UUID()
            x.from = f
            x.to = t
            x.points = x.points.map { $0 + offset }
            if let y = x.y { x.y = y + Double(offset.y) }
            return x
        }
        edit { d in
            d.nodes.insert(contentsOf: ns.filter { $0.kind.info.container }, at: 0)
            d.nodes.append(contentsOf: ns.filter { !$0.kind.info.container })
            d.edges.append(contentsOf: es)
        }
        selection = Set(ns.map(\.id))
    }

    func selectAll() {
        guard let d = diagram else { return }
        selection = Set(d.nodes.map(\.id) + d.edges.map(\.id))
    }

    // MARK: arrange

    /// 0 front, 1 forward, 2 backward, 3 back
    func order(_ how: Int) {
        let sel = selection
        edit { d in
            switch how {
            case 0:
                let moving = d.nodes.filter { sel.contains($0.id) }
                d.nodes.removeAll { sel.contains($0.id) }
                d.nodes.append(contentsOf: moving)
            case 3:
                let moving = d.nodes.filter { sel.contains($0.id) }
                d.nodes.removeAll { sel.contains($0.id) }
                d.nodes.insert(contentsOf: moving, at: 0)
            case 1:
                var i = d.nodes.count - 2
                while i >= 0 {
                    if sel.contains(d.nodes[i].id) && !sel.contains(d.nodes[i + 1].id) { d.nodes.swapAt(i, i + 1) }
                    i -= 1
                }
            default:
                var i = 1
                while i < d.nodes.count {
                    if sel.contains(d.nodes[i].id) && !sel.contains(d.nodes[i - 1].id) { d.nodes.swapAt(i, i - 1) }
                    i += 1
                }
            }
        }
    }

    /// 0 left, 1 centre, 2 right, 3 top, 4 middle, 5 bottom
    func align(_ how: Int) {
        let sel = selectedNodes
        guard sel.count >= 2 else { flash("Select two or more shapes to align"); return }
        let b = sel.map(\.frame).reduce(CGRect.null) { $0.union($1) }
        let ids = selection
        edit { d in
            for i in d.nodes.indices where ids.contains(d.nodes[i].id) {
                var f = d.nodes[i].frame
                switch how {
                case 0: f.origin.x = b.minX
                case 1: f.origin.x = b.midX - f.width / 2
                case 2: f.origin.x = b.maxX - f.width
                case 3: f.origin.y = b.minY
                case 4: f.origin.y = b.midY - f.height / 2
                default: f.origin.y = b.maxY - f.height
                }
                d.nodes[i].frame = f
            }
        }
    }

    func distribute(horizontal: Bool) {
        let sel = selectedNodes.sorted { horizontal ? $0.frame.midX < $1.frame.midX : $0.frame.midY < $1.frame.midY }
        guard sel.count >= 3 else { flash("Select three or more shapes to distribute"); return }
        let b = sel.map(\.frame).reduce(CGRect.null) { $0.union($1) }
        let used = sel.reduce(CGFloat(0)) { $0 + (horizontal ? $1.frame.width : $1.frame.height) }
        let gap = ((horizontal ? b.width : b.height) - used) / CGFloat(sel.count - 1)
        var pos = horizontal ? b.minX : b.minY
        var target: [UUID: CGFloat] = [:]
        for n in sel {
            target[n.id] = pos
            pos += (horizontal ? n.frame.width : n.frame.height) + gap
        }
        edit { d in
            for i in d.nodes.indices {
                if let t = target[d.nodes[i].id] {
                    if horizontal { d.nodes[i].frame.origin.x = t } else { d.nodes[i].frame.origin.y = t }
                }
            }
        }
    }

    /// 0 width, 1 height, 2 both
    func sameSize(_ how: Int) {
        let sel = selectedNodes
        guard sel.count >= 2 else { flash("Select two or more shapes"); return }
        let w = sel.map(\.frame.width).max() ?? 100
        let h = sel.map(\.frame.height).max() ?? 60
        let ids = selection
        edit { d in
            for i in d.nodes.indices where ids.contains(d.nodes[i].id) {
                if how != 1 { d.nodes[i].frame.size.width = w }
                if how != 0 && !d.nodes[i].kind.autoSized { d.nodes[i].frame.size.height = h }
                Store.fit(&d.nodes[i])
            }
        }
    }

    func setRouting(_ r: Routing) {
        guard let d = diagram else { return }
        var ids = Set(selectedEdges.map(\.id))
        if ids.isEmpty {
            // shapes selected: their connectors; nothing selected: every connector
            let nodes = Set(selectedNodes.map(\.id))
            ids = Set(d.edges.filter { nodes.isEmpty || nodes.contains($0.from) || nodes.contains($0.to) }.map(\.id))
        }
        edit { d in
            for i in d.edges.indices where ids.contains(d.edges[i].id) && !d.edges[i].kind.isMessage {
                d.edges[i].routing = r
                d.edges[i].points = []
            }
        }
    }

    func nudge(_ dx: CGFloat, _ dy: CGFloat) {
        let ids = selection
        guard !ids.isEmpty else { return }
        edit("nudge") { d in
            for i in d.nodes.indices where ids.contains(d.nodes[i].id) {
                d.nodes[i].frame = d.nodes[i].frame.offsetBy(dx: dx, dy: dy)
                d.nodes[i].frame.origin.x = max(0, d.nodes[i].frame.minX)
                d.nodes[i].frame.origin.y = max(0, d.nodes[i].frame.minY)
            }
            for i in d.edges.indices where ids.contains(d.edges[i].id) && d.edges[i].y != nil {
                d.edges[i].y = max(0, d.edges[i].y! + Double(dy))
            }
        }
    }

    func copyFormat() {
        guard let n = selectedNodes.first else { flash("Select a shape to copy its format"); return }
        copiedStyle = StyleCopy(fill: n.fill, stroke: n.stroke, textColor: n.textColor, fontSize: n.fontSize)
        flash("Format copied")
    }

    func pasteFormat() {
        guard let s = copiedStyle else { flash("Copy a format first"); return }
        let ids = selection
        edit { d in
            for i in d.nodes.indices where ids.contains(d.nodes[i].id) {
                d.nodes[i].fill = s.fill
                d.nodes[i].stroke = s.stroke
                d.nodes[i].textColor = s.textColor
                d.nodes[i].fontSize = s.fontSize
                Store.fit(&d.nodes[i])
            }
        }
    }

    func autoLayout(_ style: LayoutStyle) {
        guard diagram != nil else { return }
        edit { d in Layout.apply(&d, style) }
        DispatchQueue.main.async { self.canvas?.zoomToFit() }
    }

    // MARK: mind maps

    func mindAdd(child: Bool) {
        guard let d = diagram, d.type == .mindMap, selection.count == 1, let sid = selection.first, let s = d.node(sid) else { return }
        var parent = s
        if !child && s.kind != .central {
            guard let e = d.edges.first(where: { $0.kind == .branch && $0.to == sid }), let p = d.node(e.from) else { return }
            parent = p
        }
        let central = d.nodes.first { $0.kind == .central } ?? parent
        let children = d.edges.filter { $0.kind == .branch && $0.from == parent.id }.compactMap { d.node($0.to) }
        var right = parent.frame.midX >= central.frame.midX
        if parent.kind == .central {
            let r = children.filter { $0.frame.midX >= parent.frame.midX }.count
            right = r <= children.count - r
        }
        let side = children.filter { ($0.frame.midX >= parent.frame.midX) == right }
        let size = NodeKind.topic.info.size
        let x = right ? parent.frame.maxX + 70 : parent.frame.minX - 70 - size.width
        let y = (side.map(\.frame.maxY).max().map { $0 + 16 }) ?? (parent.frame.midY - size.height / 2)
        var n = Node(kind: .topic, frame: CGRect(x: max(0, x), y: max(0, y), width: size.width, height: size.height), name: "Topic")
        n.frame.origin.y = max(0, n.frame.minY)
        let e = Edge(kind: .branch, from: parent.id, to: n.id, routing: .curved)
        edit { d in
            d.nodes.append(n)
            d.edges.append(e)
        }
        selection = [n.id]
        DispatchQueue.main.async { self.canvas?.beginEditName(n.id) }
    }

    // MARK: diagrams

    func uniqueDiagramName(_ t: DiagramType) -> String {
        let names = Set(project.diagrams.map(\.name))
        let base = t.title
        if !names.contains(base) { return base }
        var i = 2
        while names.contains("\(base) \(i)") { i += 1 }
        return "\(base) \(i)"
    }

    func newDiagram(_ t: DiagramType, example: Bool) {
        var d = example ? Samples.make(t) : Diagram(name: uniqueDiagramName(t), type: t)
        if example && project.diagrams.contains(where: { $0.name == d.name }) { d.name = uniqueDiagramName(t) }
        addDiagram(d)
    }

    func addDiagram(_ d: Diagram) {
        editProject { $0.diagrams.append(d) }
        open(d.id)
        if !d.nodes.isEmpty { DispatchQueue.main.async { self.canvas?.zoomToFit() } }
    }

    func open(_ id: UUID) {
        guard project.diagram(id) != nil else { return }
        canvas?.cancelEditing()
        canvas?.saveViewState()
        currentId = id
        if !tabs.contains(id) { tabs.append(id) }
        selection = []
        tool = nil
        canvas?.restoreViewState()
    }

    func closeTab(_ id: UUID) {
        guard let i = tabs.firstIndex(of: id) else { return }
        canvas?.saveViewState()
        tabs.remove(at: i)
        if currentId == id {
            currentId = tabs.isEmpty ? nil : tabs[min(i, tabs.count - 1)]
            selection = []
            canvas?.restoreViewState()
        }
    }

    func deleteDiagram(_ id: UUID) {
        guard let d = project.diagram(id) else { return }
        let a = NSAlert()
        a.messageText = "Delete “\(d.name)”?"
        a.informativeText = "You can undo this with ⌘Z."
        a.addButton(withTitle: "Delete")
        a.addButton(withTitle: "Cancel")
        guard a.runModal() == .alertFirstButtonReturn else { return }
        editProject { $0.diagrams.removeAll { $0.id == id } }
        if tabs.contains(id) { closeTab(id) }
    }

    func duplicateDiagram(_ id: UUID) {
        guard var d = project.diagram(id) else { return }
        d = Store.reidentified(d)
        d.name += " copy"
        addDiagram(d)
    }

    static func reidentified(_ src: Diagram) -> Diagram {
        var d = src
        d.id = UUID()
        var map: [UUID: UUID] = [:]
        for i in d.nodes.indices {
            let n = UUID()
            map[d.nodes[i].id] = n
            d.nodes[i].id = n
        }
        d.edges = d.edges.compactMap { e in
            guard let f = map[e.from], let t = map[e.to] else { return nil }
            var x = e
            x.id = UUID()
            x.from = f
            x.to = t
            return x
        }
        return d
    }

    func renameDiagram(_ id: UUID, _ name: String) {
        let n = name.trimmed
        guard !n.isEmpty else { return }
        editProject { p in
            if let i = p.dindex(id) { p.diagrams[i].name = n }
        }
    }

    func moveDiagram(_ id: UUID, by delta: Int) {
        guard let i = project.dindex(id) else { return }
        let j = i + delta
        guard j >= 0 && j < project.diagrams.count else { return }
        editProject { $0.diagrams.swapAt(i, j) }
    }

    func reveal(_ diagram: UUID, _ node: UUID?) {
        if currentId != diagram { open(diagram) }
        if let n = node {
            selection = [n]
            DispatchQueue.main.async { self.canvas?.scrollToSelection() }
        }
    }

    var modelItems: [ModelItem] {
        var out: [ModelItem] = []
        let skip: Set<NodeKind> = [.text, .rect, .ellipse, .note, .annotation, .fork, .initial, .final, .flowFinal, .connector]
        for d in project.diagrams {
            for n in d.nodes where !skip.contains(n.kind) && !n.name.trimmed.isEmpty {
                out.append(ModelItem(id: n.id, name: n.name, kind: n.kind, diagram: d.id, diagramName: d.name))
            }
        }
        return out
    }

    // MARK: messages

    func flash(_ s: String) {
        toast = s
        toastTimer?.invalidate()
        toastTimer = Timer.scheduledTimer(withTimeInterval: 2.6, repeats: false) { [weak self] _ in self?.toast = nil }
    }

    func validate() {
        issues = Validator.run(project)
        sheet = .validate
    }

    // MARK: files

    static let fileType = UTType(filenameExtension: "blueprint", conformingTo: .json) ?? .json

    @discardableResult
    func save(as saveAs: Bool = false) -> Bool {
        canvas?.commitEditing()
        var url = fileURL
        if url == nil || saveAs {
            let panel = NSSavePanel()
            panel.allowedContentTypes = [Store.fileType]
            panel.nameFieldStringValue = title
            panel.canCreateDirectories = true
            guard panel.runModal() == .OK, let u = panel.url else { return false }
            url = u
        }
        guard let u = url else { return false }
        do {
            if project.name == "Untitled Project" { project.name = u.deletingPathExtension().lastPathComponent }
            let enc = JSONEncoder()
            enc.outputFormatting = [.prettyPrinted, .sortedKeys]
            try enc.encode(project).write(to: u, options: .atomic)
            fileURL = u
            dirty = false
            Recent.add(u)
            flash("Saved \(u.lastPathComponent)")
            return true
        } catch {
            NSAlert(error: error).runModal()
            return false
        }
    }

    static func load(_ url: URL) throws -> Project {
        let data = try Data(contentsOf: url)
        return try JSONDecoder().decode(Project.self, from: data)
    }
}

enum Prefs {
    static func bool(_ k: String, _ d: Bool) -> Bool { UserDefaults.standard.object(forKey: k) == nil ? d : UserDefaults.standard.bool(forKey: k) }
    static func set(_ k: String, _ v: Bool) { UserDefaults.standard.set(v, forKey: k) }
}

enum Recent {
    static var urls: [URL] {
        (UserDefaults.standard.stringArray(forKey: "recent") ?? []).map { URL(fileURLWithPath: $0) }
            .filter { FileManager.default.fileExists(atPath: $0.path) }
    }
    static func add(_ u: URL) {
        var list = UserDefaults.standard.stringArray(forKey: "recent") ?? []
        list.removeAll { $0 == u.path }
        list.insert(u.path, at: 0)
        UserDefaults.standard.set(Array(list.prefix(12)), forKey: "recent")
        NSDocumentController.shared.noteNewRecentDocumentURL(u)
    }
    static func clear() { UserDefaults.standard.removeObject(forKey: "recent") }
}
