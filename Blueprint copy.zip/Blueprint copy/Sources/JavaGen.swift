import AppKit
import SwiftUI

struct JavaOptions: Equatable {
    /// comments that explain how each UML symbol becomes Java
    var explain = true
    var accessors = true
    var constructors = true
    var allDiagrams = false
}

struct GenFile: Identifiable, Equatable {
    var id: String { path }
    var path: String
    var code: String
    var node: UUID?
    var name: String { (path as NSString).lastPathComponent }
}

enum JavaNames {
    static let keywords: Set<String> = ["abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue", "default", "do",
                                        "double", "else", "enum", "extends", "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof",
                                        "int", "interface", "long", "native", "new", "package", "private", "protected", "public", "return", "short", "static",
                                        "strictfp", "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void", "volatile", "while",
                                        "true", "false", "null", "var", "record", "yield", "sealed", "permits"]

    static func isIdentifier(_ s: String) -> Bool {
        guard let f = s.first, f.isLetter || f == "_" || f == "$" else { return false }
        return s.allSatisfy { $0.isLetter || $0.isNumber || $0 == "_" || $0 == "$" } && !keywords.contains(s)
    }

    /// "order line" -> "OrderLine"
    static func type(_ s: String) -> String {
        let t = s.trimmed
        if isIdentifier(t) { return t }
        let clean = t.map { $0.isLetter || $0.isNumber ? $0 : " " }
        let p = String(clean).split(separator: " ").map { String($0).upperFirst }.joined()
        return p.isEmpty ? "Unnamed" : (p.first!.isNumber ? "_" + p : p)
    }

    static func member(_ s: String) -> String {
        let t = s.trimmed
        if isIdentifier(t) { return t }
        let clean = t.map { $0.isLetter || $0.isNumber || $0 == "_" ? $0 : " " }
        let p = String(clean).camel.replacingOccurrences(of: " ", with: "")
        if p.isEmpty { return "value" }
        return keywords.contains(p) ? p + "_" : (p.first!.isNumber ? "_" + p : p)
    }

    static func plural(_ s: String) -> String {
        if s.hasSuffix("s") || s.hasSuffix("x") || s.hasSuffix("ch") || s.hasSuffix("sh") { return s + "es" }
        if s.hasSuffix("y"), let b = s.dropLast().last, !"aeiou".contains(b) { return s.dropLast() + "ies" }
        return s + "s"
    }

    static func singular(_ s: String) -> String {
        if s.hasSuffix("ies") { return s.dropLast(3) + "y" }
        if s.hasSuffix("sses") || s.hasSuffix("xes") { return String(s.dropLast(2)) }
        if s.hasSuffix("s") && !s.hasSuffix("ss") && s.count > 3 { return String(s.dropLast()) }
        return s
    }

    static func isMany(_ mult: String) -> Bool {
        let m = mult.replacingOccurrences(of: " ", with: "")
        guard !m.isEmpty else { return false }
        let upper = m.components(separatedBy: "..").last ?? m
        if upper == "*" || upper.lowercased() == "n" || upper.lowercased() == "m" { return true }
        return (Int(upper) ?? 1) > 1
    }

    static func defaultValue(_ type: String) -> String? {
        switch type {
        case "void", "": return nil
        case "int", "long", "short", "byte": return "0"
        case "double", "float": return "0.0"
        case "boolean": return "false"
        case "char": return "'\\0'"
        default: return "null"
        }
    }

    /// "qty: int, price: double" -> "int qty, double price"
    static func params(_ p: String) -> String {
        UMLText.splitTop(p).compactMap { part -> String? in
            let s = part.trimmed
            guard !s.isEmpty else { return nil }
            if let c = s.firstIndex(of: ":") {
                let n = member(String(s[..<c]))
                let t = s[s.index(after: c)...].trimmed
                return "\(t.isEmpty ? "Object" : t) \(n)"
            }
            return s.contains(" ") ? s : "Object \(member(s))"
        }.joined(separator: ", ")
    }

    static func paramCount(_ p: String) -> Int { UMLText.splitTop(p).filter { !$0.trimmed.isEmpty }.count }
}

enum JavaGen {
    static let classKinds: [NodeKind] = [.klass, .interface, .enumeration]

    static func diagrams(_ p: Project, current: Diagram?, all: Bool) -> [Diagram] {
        let classy: (Diagram) -> Bool = { $0.nodes.contains { classKinds.contains($0.kind) } }
        if !all, let c = current, classy(c) { return [c] }
        return p.diagrams.filter(classy)
    }

    static func generate(_ p: Project, current: Diagram?, _ o: JavaOptions) -> [GenFile] {
        var out: [GenFile] = []
        var seen: Set<String> = []
        for d in diagrams(p, current: current, all: o.allDiagrams) {
            for n in d.nodes where classKinds.contains(n.kind) {
                let f = file(n, d, o)
                if seen.insert(f.path).inserted { out.append(f) }
            }
        }
        return out
    }

    static func file(for id: UUID, in p: Project, _ o: JavaOptions) -> GenFile? {
        for d in p.diagrams { if let n = d.node(id), classKinds.contains(n.kind) { return file(n, d, o) } }
        return nil
    }

    /// package from the package shapes around a class, outermost first
    static func package(of n: Node, in d: Diagram) -> String {
        d.nodes.filter { $0.kind == .package && $0.id != n.id && $0.frame.contains(n.frame) }
            .sorted { $0.frame.width * $0.frame.height > $1.frame.width * $1.frame.height }
            .map { JavaNames.member($0.name.lowercased().replacingOccurrences(of: " ", with: "")) }
            .joined(separator: ".")
    }

    static func imports(for types: [String]) -> [String] {
        let all = types.joined(separator: " ")
        let known: [(String, String)] = [("ArrayList", "java.util.ArrayList"), ("List", "java.util.List"), ("HashMap", "java.util.HashMap"), ("Map", "java.util.Map"),
                                         ("HashSet", "java.util.HashSet"), ("Set", "java.util.Set"), ("Optional", "java.util.Optional"), ("UUID", "java.util.UUID"),
                                         ("LocalDateTime", "java.time.LocalDateTime"), ("LocalDate", "java.time.LocalDate"), ("LocalTime", "java.time.LocalTime"),
                                         ("Instant", "java.time.Instant"), ("Duration", "java.time.Duration"), ("BigDecimal", "java.math.BigDecimal")]
        var out: [String] = []
        for (k, imp) in known {
            if all.range(of: "\\b\(k)\\b", options: .regularExpression) != nil && !out.contains(imp) { out.append(imp) }
        }
        return out.sorted()
    }

    struct Field {
        var line: String
        var comment: String
        var type: String
        var name: String
        var isList: Bool
    }

    static func file(_ n: Node, _ d: Diagram, _ o: JavaOptions) -> GenFile {
        let byId = Dictionary(uniqueKeysWithValues: d.nodes.map { ($0.id, $0) })
        let name = JavaNames.type(n.name)
        let pkg = package(of: n, in: d)
        let isIface = n.kind == .interface
        let isEnum = n.kind == .enumeration

        var superclass: String?
        var extraSupers: [String] = []
        var ifaces: [String] = []
        var assoc: [Field] = []
        var deps: [String] = []
        var inherited: [(String, Member)] = []   // methods this class must implement

        func addAssoc(_ other: Node, role: String, mult: String, kind: EdgeKind) {
            let t = JavaNames.type(other.name)
            let many = JavaNames.isMany(mult)
            let fname = role.trimmed.isEmpty ? (many ? JavaNames.plural(t.lowerFirst) : t.lowerFirst) : JavaNames.member(role)
            let type = many ? "List<\(t)>" : t
            var comment: String
            switch kind {
            case .composition: comment = "composition (filled diamond): \(name) owns its \(many ? JavaNames.plural(t) : t) – created and destroyed with it"
            case .aggregation: comment = "aggregation (hollow diamond): \(name) groups \(many ? JavaNames.plural(t) : t) that can also exist on their own"
            default: comment = "association: \(name) knows \(many ? "many" : "one") \(t)"
            }
            if !mult.isEmpty { comment += " – multiplicity \(mult)\(many ? " becomes a List" : "")" }
            let vis = isIface ? "" : "private "
            let line = "\(vis)\(type) \(fname)\(many && !isIface ? " = new ArrayList<>()" : "");"
            assoc.append(Field(line: line, comment: comment, type: type, name: fname, isList: many))
        }

        for e in d.edges {
            guard let a = byId[e.from], let b = byId[e.to] else { continue }
            switch e.kind {
            case .generalization where e.from == n.id && e.from != e.to:
                if isIface || b.kind == .interface { ifaces.append(JavaNames.type(b.name)) }
                else if superclass == nil { superclass = JavaNames.type(b.name) }
                else { extraSupers.append(JavaNames.type(b.name)) }
                if !isIface && b.kind != .interface {
                    for m in b.ops where m.isAbstract { inherited.append((JavaNames.type(b.name), m)) }
                } else if !isIface {
                    for m in b.ops where !m.isStatic { inherited.append((JavaNames.type(b.name), m)) }
                }
            case .realization where e.from == n.id && e.from != e.to:
                ifaces.append(JavaNames.type(b.name))
                if !isIface {
                    for m in b.ops where !m.isStatic { inherited.append((JavaNames.type(b.name), m)) }
                    // methods of the interfaces that interface extends
                    for e2 in d.edges where (e2.kind == .generalization) && e2.from == b.id {
                        if let up = byId[e2.to], up.kind == .interface {
                            for m in up.ops where !m.isStatic { inherited.append((JavaNames.type(up.name), m)) }
                        }
                    }
                }
            case .association, .directed, .aggregation, .composition:
                if e.from == n.id { addAssoc(b, role: e.toRole, mult: e.toMult, kind: e.kind) }
                if e.to == n.id && e.kind == .association && e.from != e.to { addAssoc(a, role: e.fromRole, mult: e.fromMult, kind: e.kind) }
            case .dependency where e.from == n.id:
                deps.append(JavaNames.type(b.name))
            default: break
            }
        }

        var L: [String] = []
        let ex = o.explain
        if !pkg.isEmpty { L.append("package \(pkg);"); L.append("") }

        // imports: collection types plus classes that live in other packages
        var types = n.attrs.map(\.type) + n.ops.map(\.type) + n.ops.map(\.params) + assoc.map(\.type)
        if assoc.contains(where: \.isList) { types.append("ArrayList List") }
        var imports = imports(for: types)
        let referenced = Set(assoc.map { $0.type.replacingOccurrences(of: "List<", with: "").replacingOccurrences(of: ">", with: "") } + ifaces + deps + [superclass].compactMap { $0 })
        for other in d.nodes where classKinds.contains(other.kind) && referenced.contains(JavaNames.type(other.name)) {
            let op = package(of: other, in: d)
            if !op.isEmpty && op != pkg { imports.append("\(op).\(JavaNames.type(other.name))") }
        }
        if !imports.isEmpty {
            imports.forEach { L.append("import \($0);") }
            L.append("")
        }

        // documentation
        L.append("/**")
        L.append(" * \(name)\(n.doc.isEmpty ? "" : " – " + n.doc.replacingOccurrences(of: "\n", with: "\n * "))")
        if ex { L.append(" * Generated from the \(d.type.title.lowercased()) “\(d.name)”.") }
        L.append(" */")
        if ex {
            if isIface { L.append("// «interface»: only method signatures and constants. Classes promise to provide these methods with 'implements'.") }
            if isEnum { L.append("// «enumeration»: a fixed list of named values. You can use them in a switch.") }
            if n.isAbstract && !isIface { L.append("// abstract (name in italics): you can't write new \(name)(); only subclasses can be created.") }
            if let s = superclass { L.append("// extends \(s): the arrow with a hollow triangle (generalization) – \(name) IS A \(s) and inherits its members.") }
            if !ifaces.isEmpty && !isIface { L.append("// implements \(ifaces.joined(separator: ", ")): the dashed arrow with a hollow triangle (realization).") }
            for dname in deps { L.append("// uses \(dname): the dashed arrow (dependency) – \(name) needs \(dname) for a moment, e.g. as a parameter, but keeps no field of it.") }
        }
        if !extraSupers.isEmpty {
            L.append("// ⚠ Java allows only one superclass. \(name) also generalizes \(extraSupers.joined(separator: ", ")) – turn those into interfaces.")
        }

        var head = "public "
        if n.isAbstract && !isIface && !isEnum { head += "abstract " }
        if n.stereotype.lowercased() == "final" { head += "final " }
        head += isIface ? "interface " : isEnum ? "enum " : "class "
        head += name
        if isIface {
            if !ifaces.isEmpty { head += " extends " + ifaces.joined(separator: ", ") }
        } else {
            if let s = superclass, !isEnum { head += " extends \(s)" }
            if !ifaces.isEmpty { head += " implements " + ifaces.joined(separator: ", ") }
        }
        L.append(head + " {")

        var sectionOpen = false
        func section(_ s: String) {
            if sectionOpen || L.last != head + " {" { L.append("") }
            if ex { L.append("    // ── \(s)") }
            sectionOpen = true
        }

        if isEnum {
            let lits = n.attrs.map { JavaNames.member($0.name) }
            if ex { L.append("    // the values") }
            L.append("    " + (lits.isEmpty ? "" : lits.joined(separator: ", ")) + ";")
            sectionOpen = true
        }

        // attributes
        let fields = isEnum ? [] : n.attrs
        if !fields.isEmpty {
            section(isIface ? "Constants: fields in an interface are always public static final" : "Attributes: '-' private, '+' public, '#' protected, '~' package")
            var explainedStatic = false
            for a in fields {
                let t = a.type.trimmed.isEmpty ? "String" : a.type.trimmed
                let nm = JavaNames.member(a.name)
                if isIface {
                    let val = a.value.isEmpty ? (JavaNames.defaultValue(t) ?? "null") : a.value
                    L.append("    \(t) \(nm) = \(val);")
                    continue
                }
                if ex && a.isStatic && !explainedStatic {
                    L.append("    // static (underlined in UML): one value shared by every \(name)")
                    explainedStatic = true
                }
                if ex && a.type.trimmed.isEmpty { L.append("    // no type in the diagram, so String is used") }
                var s = "    "
                if !a.vis.java.isEmpty { s += a.vis.java + " " }
                if a.isStatic { s += "static " }
                if a.isFinal { s += "final " }
                s += "\(t) \(nm)"
                if !a.value.isEmpty { s += " = \(a.value)" }
                s += ";"
                if !a.doc.isEmpty { s += " // \(a.doc)" }
                L.append(s)
            }
        }

        if !assoc.isEmpty {
            section("Relationships from the diagram")
            for f in assoc {
                if ex { L.append("    // \(f.comment)") }
                L.append("    \(f.line)")
            }
        }

        // constructors
        let ctorOps = n.ops.filter { JavaNames.type($0.name) == name && !isIface }
        let settable = fields.filter { !$0.isStatic && !($0.isFinal && !$0.value.isEmpty) }
        if o.constructors && !isIface && !isEnum && ctorOps.isEmpty {
            section("Constructors: they run when you write new \(name)(...)")
            L.append("    public \(name)() {")
            L.append("    }")
            if !settable.isEmpty {
                L.append("")
                let ps = settable.map { "\($0.type.trimmed.isEmpty ? "String" : $0.type.trimmed) \(JavaNames.member($0.name))" }.joined(separator: ", ")
                L.append("    public \(name)(\(ps)) {")
                if ex, superclass != nil { L.append("        super(); // first the \(superclass!) part of the object is built") }
                for f in settable {
                    let nm = JavaNames.member(f.name)
                    L.append("        this.\(nm) = \(nm);")
                }
                L.append("    }")
            }
        }

        // operations
        let normalOps = n.ops.filter { !ctorOps.contains($0) }
        if !normalOps.isEmpty || !ctorOps.isEmpty {
            section("Operations")
            var first = true
            for c in ctorOps {
                if !first { L.append("") }
                first = false
                L.append("    \(c.vis.java.isEmpty ? "" : c.vis.java + " ")\(name)(\(JavaNames.params(c.params))) {")
                L.append("    }")
            }
            for m in normalOps {
                if !first { L.append("") }
                first = false
                if !m.doc.isEmpty { L.append("    /** \(m.doc) */") }
                L.append(contentsOf: method(m, isIface: isIface, classAbstract: n.isAbstract, ex: ex, override: false))
            }
        }

        // methods from interfaces and abstract superclasses that aren't written yet
        if !isIface && !n.isAbstract {
            var done = Set(normalOps.map { "\($0.name)/\(JavaNames.paramCount($0.params))" })
            let missing = inherited.filter { done.insert("\($0.1.name)/\(JavaNames.paramCount($0.1.params))").inserted }
            if !missing.isEmpty {
                section("Inherited methods: a concrete class must implement every abstract method it gets")
                for (i, (from, m)) in missing.enumerated() {
                    if i > 0 { L.append("") }
                    if ex { L.append("    // from \(from)") }
                    var mm = m
                    mm.isAbstract = false
                    if mm.vis != .pub { mm.vis = .pub }
                    L.append(contentsOf: method(mm, isIface: false, classAbstract: false, ex: false, override: true))
                }
            }
        }

        // getters and setters
        if o.accessors && !isIface && !isEnum {
            let props = fields.filter { !$0.isStatic && $0.vis != .pub }.map { ($0.type.trimmed.isEmpty ? "String" : $0.type.trimmed, JavaNames.member($0.name), $0.isFinal) }
                + assoc.map { ($0.type, $0.name, false) }
            let existing = Set(n.ops.map(\.name))
            let list = props.filter { !existing.contains("get" + $0.1.upperFirst) }
            if !list.isEmpty {
                section("Getters and setters: controlled access to private fields (encapsulation)")
                for (i, (t, nm, fin)) in list.enumerated() {
                    if i > 0 { L.append("") }
                    let getter = (t == "boolean" ? "is" : "get") + nm.upperFirst
                    L.append("    public \(t) \(getter)() {")
                    L.append("        return \(nm);")
                    L.append("    }")
                    if !fin && !t.hasPrefix("List<") {
                        L.append("")
                        L.append("    public void set\(nm.upperFirst)(\(t) \(nm)) {")
                        L.append("        this.\(nm) = \(nm);")
                        L.append("    }")
                    }
                }
            }
        }

        L.append("}")
        let path = (pkg.isEmpty ? "" : pkg.replacingOccurrences(of: ".", with: "/") + "/") + name + ".java"
        return GenFile(path: path, code: L.joined(separator: "\n") + "\n", node: n.id)
    }

    static func method(_ m: Member, isIface: Bool, classAbstract: Bool, ex: Bool, override: Bool) -> [String] {
        var L: [String] = []
        let ret = m.type.trimmed.isEmpty ? "void" : m.type.trimmed
        let nm = JavaNames.member(m.name)
        let ps = JavaNames.params(m.params)
        if override { L.append("    @Override") }
        if isIface {
            if m.isStatic {
                L.append("    static \(ret) \(nm)(\(ps)) {")
                if let v = JavaNames.defaultValue(ret) { L.append("        return \(v);") }
                L.append("    }")
            } else {
                L.append("    \(ret) \(nm)(\(ps));")
            }
            return L
        }
        var s = "    "
        if !m.vis.java.isEmpty { s += m.vis.java + " " }
        if m.isAbstract {
            if ex { L.append("    // abstract (italic): no body here – every subclass must write one") }
            L.append(s + "abstract \(ret) \(nm)(\(ps));")
            return L
        }
        if m.isStatic { s += "static " }
        if m.isFinal { s += "final " }
        L.append(s + "\(ret) \(nm)(\(ps)) {")
        L.append("        // TODO: write the code for \(nm)")
        if let v = JavaNames.defaultValue(ret) { L.append("        return \(v);") }
        L.append("    }")
        return L
    }

    static func save(_ files: [GenFile], _ s: Store) {
        let p = NSOpenPanel()
        p.canChooseDirectories = true
        p.canChooseFiles = false
        p.canCreateDirectories = true
        p.prompt = "Save Here"
        p.message = "Choose a folder (for example your project's src folder)"
        guard p.runModal() == .OK, let dir = p.url else { return }
        do {
            for f in files {
                let url = dir.appendingPathComponent(f.path)
                try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
                try f.code.write(to: url, atomically: true, encoding: .utf8)
            }
            s.flash("Saved \(files.count) file\(files.count == 1 ? "" : "s")")
            NSWorkspace.shared.activateFileViewerSelecting([dir])
        } catch { NSAlert(error: error).runModal() }
    }
}

// MARK: - syntax colouring for the code views

enum CodeLang { case java, sql }

enum Highlight {
    static let javaKeywords = JavaNames.keywords.union(["String", "Override"])
    static let sqlKeywords: Set<String> = ["CREATE", "TABLE", "PRIMARY", "KEY", "FOREIGN", "REFERENCES", "NOT", "NULL", "UNIQUE", "ALTER", "ADD", "CONSTRAINT",
                                           "INDEX", "ON", "DELETE", "UPDATE", "CASCADE", "DEFAULT", "CHECK", "IF", "EXISTS", "DROP", "INSERT", "INTO", "VALUES",
                                           "SELECT", "FROM", "WHERE", "AND", "OR", "AUTO_INCREMENT", "AUTOINCREMENT", "SERIAL", "INTEGER", "INT", "BIGINT", "VARCHAR",
                                           "TEXT", "DATE", "TIMESTAMP", "BOOLEAN", "DECIMAL", "NUMERIC", "CHAR", "FLOAT", "DOUBLE", "REAL", "SMALLINT", "TIME",
                                           "GENERATED", "ALWAYS", "AS", "IDENTITY", "BLOB", "UUID", "DATETIME", "ENGINE", "SET"]

    struct Colors {
        let text, keyword, type, string, comment, number, annotation: Color
        static func of(_ dark: Bool) -> Colors {
            dark ? Colors(text: Color(hex: 0xE6E8EC), keyword: Color(hex: 0xFF7AB2), type: Color(hex: 0x6BDFFF), string: Color(hex: 0xFF8170),
                          comment: Color(hex: 0x7F8C98), number: Color(hex: 0xD9C97C), annotation: Color(hex: 0xFFA14F))
                 : Colors(text: Color(hex: 0x1F2329), keyword: Color(hex: 0xAD3DA4), type: Color(hex: 0x3F6E75), string: Color(hex: 0xC41A16),
                          comment: Color(hex: 0x5D6C79), number: Color(hex: 0x1C00CF), annotation: Color(hex: 0x805E03))
        }
    }

    static func attributed(_ code: String, _ lang: CodeLang, dark: Bool) -> AttributedString {
        let c = Colors.of(dark)
        var out = AttributedString()
        let chars = Array(code)
        var i = 0
        var plain = ""
        func flush() {
            if !plain.isEmpty {
                var a = AttributedString(plain)
                a.foregroundColor = c.text
                out += a
                plain = ""
            }
        }
        func emit(_ s: String, _ col: Color) {
            flush()
            var a = AttributedString(s)
            a.foregroundColor = col
            out += a
        }
        while i < chars.count {
            let ch = chars[i]
            let next: Character? = i + 1 < chars.count ? chars[i + 1] : nil
            // comments
            if (lang == .java && ch == "/" && next == "/") || (lang == .sql && ch == "-" && next == "-") {
                var s = ""
                while i < chars.count && chars[i] != "\n" { s.append(chars[i]); i += 1 }
                emit(s, c.comment)
                continue
            }
            if ch == "/" && next == "*" {
                var s = "/*"
                i += 2
                while i < chars.count && !(chars[i] == "*" && i + 1 < chars.count && chars[i + 1] == "/") { s.append(chars[i]); i += 1 }
                if i < chars.count { s += "*/"; i += 2 }
                emit(s, c.comment)
                continue
            }
            if ch == "\"" || ch == "'" {
                var s = String(ch)
                i += 1
                while i < chars.count && chars[i] != ch && chars[i] != "\n" {
                    if chars[i] == "\\" && i + 1 < chars.count { s.append(chars[i]); i += 1 }
                    s.append(chars[i])
                    i += 1
                }
                if i < chars.count && chars[i] == ch { s.append(ch); i += 1 }
                emit(s, lang == .sql && ch == "\"" ? c.type : c.string)
                continue
            }
            if ch == "@" && lang == .java {
                var s = "@"
                i += 1
                while i < chars.count && (chars[i].isLetter || chars[i].isNumber || chars[i] == ".") { s.append(chars[i]); i += 1 }
                emit(s, c.annotation)
                continue
            }
            if ch.isLetter || ch == "_" || ch == "$" {
                var s = ""
                while i < chars.count && (chars[i].isLetter || chars[i].isNumber || chars[i] == "_" || chars[i] == "$") { s.append(chars[i]); i += 1 }
                if lang == .java {
                    if javaKeywords.contains(s) && s != "String" { emit(s, c.keyword) }
                    else if s.first!.isUppercase { emit(s, c.type) }
                    else { plain += s }
                } else {
                    if sqlKeywords.contains(s.uppercased()) { emit(s, c.keyword) } else { plain += s }
                }
                continue
            }
            if ch.isNumber {
                var s = ""
                while i < chars.count && (chars[i].isNumber || chars[i] == "." || chars[i] == "L" || chars[i] == "f") { s.append(chars[i]); i += 1 }
                emit(s, c.number)
                continue
            }
            plain.append(ch)
            i += 1
        }
        flush()
        return out
    }
}
