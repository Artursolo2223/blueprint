import AppKit

/// colour group a shape is drawn in
enum Family { case structure, behavior, actor, note, container, control, flow, data, event, gateway, component, mind, plain, text }

/// outline used to clip connectors
enum Clip { case rect, ellipse, diamond }

struct KindInfo {
    let title: String
    let name: String
    let size: CGSize
    let family: Family
    let clip: Clip
    var container = false
    /// the name is written under the shape instead of inside it
    var labelBelow = false
}

enum NodeKind: String, Codable, CaseIterable {
    // class, object and package diagrams
    case klass, interface, enumeration, package, object
    // general
    case note, text, rect, ellipse
    // use cases
    case actor, useCase, boundary
    // sequence
    case lifeline, actorLifeline, fragment
    // activity
    case initial, final, flowFinal, action, decision, merge, fork, lane, objectNode, sendSignal, acceptEvent
    // state machine
    case state, choice, history
    // component and deployment
    case component, provided, artifact, node3d, device, execEnv
    // database
    case entity
    // flowchart
    case terminator, process, fDecision, io, predefined, document, database, manualInput, connector, preparation
    // BPMN
    case startEvent, interEvent, endEvent, task, subProcess, xorGateway, andGateway, orGateway, dataObject, dataStore, pool, annotation
    // mind map
    case central, topic
    // data flow
    case dfdProcess, external, dfdStore

    var info: KindInfo { NodeKind.table[self]! }
    var title: String { info.title }
    var isClassifier: Bool { self == .klass || self == .interface || self == .enumeration || self == .object }
    /// shapes whose height follows their content
    var autoSized: Bool { isClassifier || self == .entity }
    var isLifeline: Bool { self == .lifeline || self == .actorLifeline }
    var isNoteLike: Bool { self == .note || self == .annotation || self == .text }
    /// shapes that are normally left without a name
    var unnamed: Bool {
        [.initial, .final, .flowFinal, .fork, .choice, .history, .merge, .connector, .startEvent, .interEvent, .endEvent,
         .xorGateway, .andGateway, .orGateway].contains(self)
    }

    static let table: [NodeKind: KindInfo] = {
        func s(_ w: CGFloat, _ h: CGFloat) -> CGSize { CGSize(width: w, height: h) }
        return [
            .klass: KindInfo(title: "Class", name: "Class", size: s(170, 90), family: .structure, clip: .rect),
            .interface: KindInfo(title: "Interface", name: "Interface", size: s(170, 80), family: .structure, clip: .rect),
            .enumeration: KindInfo(title: "Enumeration", name: "Enum", size: s(150, 90), family: .structure, clip: .rect),
            .package: KindInfo(title: "Package", name: "package", size: s(260, 190), family: .container, clip: .rect, container: true),
            .object: KindInfo(title: "Object", name: "object", size: s(170, 70), family: .structure, clip: .rect),
            .note: KindInfo(title: "Note", name: "Note", size: s(160, 70), family: .note, clip: .rect),
            .text: KindInfo(title: "Text", name: "Text", size: s(120, 30), family: .text, clip: .rect),
            .rect: KindInfo(title: "Rectangle", name: "", size: s(130, 70), family: .plain, clip: .rect),
            .ellipse: KindInfo(title: "Ellipse", name: "", size: s(130, 70), family: .plain, clip: .ellipse),
            .actor: KindInfo(title: "Actor", name: "Actor", size: s(60, 96), family: .actor, clip: .rect),
            .useCase: KindInfo(title: "Use Case", name: "Use Case", size: s(150, 62), family: .behavior, clip: .ellipse),
            .boundary: KindInfo(title: "System", name: "System", size: s(320, 380), family: .container, clip: .rect, container: true),
            .lifeline: KindInfo(title: "Lifeline", name: "object", size: s(120, 380), family: .structure, clip: .rect),
            .actorLifeline: KindInfo(title: "Actor Lifeline", name: "User", size: s(90, 380), family: .actor, clip: .rect),
            .fragment: KindInfo(title: "Combined Fragment", name: "condition", size: s(320, 160), family: .container, clip: .rect, container: true),
            .initial: KindInfo(title: "Initial Node", name: "", size: s(26, 26), family: .control, clip: .ellipse),
            .final: KindInfo(title: "Final Node", name: "", size: s(30, 30), family: .control, clip: .ellipse),
            .flowFinal: KindInfo(title: "Flow Final", name: "", size: s(28, 28), family: .control, clip: .ellipse),
            .action: KindInfo(title: "Action", name: "Action", size: s(140, 54), family: .behavior, clip: .rect),
            .decision: KindInfo(title: "Decision", name: "", size: s(44, 44), family: .gateway, clip: .diamond, labelBelow: true),
            .merge: KindInfo(title: "Merge", name: "", size: s(44, 44), family: .gateway, clip: .diamond, labelBelow: true),
            .fork: KindInfo(title: "Fork / Join", name: "", size: s(130, 8), family: .control, clip: .rect),
            .lane: KindInfo(title: "Swimlane", name: "Lane", size: s(230, 440), family: .container, clip: .rect, container: true),
            .objectNode: KindInfo(title: "Object Node", name: "Object", size: s(120, 50), family: .data, clip: .rect),
            .sendSignal: KindInfo(title: "Send Signal", name: "Send", size: s(140, 50), family: .behavior, clip: .rect),
            .acceptEvent: KindInfo(title: "Accept Event", name: "Receive", size: s(140, 50), family: .behavior, clip: .rect),
            .state: KindInfo(title: "State", name: "State", size: s(140, 62), family: .behavior, clip: .rect, container: true),
            .choice: KindInfo(title: "Choice", name: "", size: s(30, 30), family: .gateway, clip: .diamond, labelBelow: true),
            .history: KindInfo(title: "History", name: "", size: s(30, 30), family: .plain, clip: .ellipse),
            .component: KindInfo(title: "Component", name: "Component", size: s(180, 84), family: .component, clip: .rect, container: true),
            .provided: KindInfo(title: "Interface (lollipop)", name: "Interface", size: s(26, 26), family: .component, clip: .ellipse, labelBelow: true),
            .artifact: KindInfo(title: "Artifact", name: "app.jar", size: s(150, 70), family: .data, clip: .rect),
            .node3d: KindInfo(title: "Node", name: "Server", size: s(240, 160), family: .component, clip: .rect, container: true),
            .device: KindInfo(title: "Device", name: "Device", size: s(210, 140), family: .component, clip: .rect, container: true),
            .execEnv: KindInfo(title: "Execution Env.", name: "JVM", size: s(190, 110), family: .component, clip: .rect, container: true),
            .entity: KindInfo(title: "Entity", name: "table", size: s(190, 90), family: .data, clip: .rect),
            .terminator: KindInfo(title: "Start / End", name: "Start", size: s(130, 48), family: .flow, clip: .rect),
            .process: KindInfo(title: "Process", name: "Process", size: s(140, 60), family: .flow, clip: .rect),
            .fDecision: KindInfo(title: "Decision", name: "Condition?", size: s(140, 84), family: .gateway, clip: .diamond),
            .io: KindInfo(title: "Input / Output", name: "Input", size: s(150, 60), family: .flow, clip: .rect),
            .predefined: KindInfo(title: "Subroutine", name: "Subroutine", size: s(150, 60), family: .flow, clip: .rect),
            .document: KindInfo(title: "Document", name: "Document", size: s(140, 70), family: .flow, clip: .rect),
            .database: KindInfo(title: "Database", name: "Database", size: s(100, 84), family: .data, clip: .rect),
            .manualInput: KindInfo(title: "Manual Input", name: "Enter data", size: s(140, 60), family: .flow, clip: .rect),
            .connector: KindInfo(title: "Connector", name: "A", size: s(36, 36), family: .flow, clip: .ellipse),
            .preparation: KindInfo(title: "Preparation", name: "Setup", size: s(150, 60), family: .flow, clip: .rect),
            .startEvent: KindInfo(title: "Start Event", name: "", size: s(36, 36), family: .event, clip: .ellipse, labelBelow: true),
            .interEvent: KindInfo(title: "Intermediate Event", name: "", size: s(36, 36), family: .event, clip: .ellipse, labelBelow: true),
            .endEvent: KindInfo(title: "End Event", name: "", size: s(36, 36), family: .event, clip: .ellipse, labelBelow: true),
            .task: KindInfo(title: "Task", name: "Task", size: s(130, 72), family: .behavior, clip: .rect),
            .subProcess: KindInfo(title: "Sub-Process", name: "Sub-Process", size: s(170, 100), family: .behavior, clip: .rect),
            .xorGateway: KindInfo(title: "Exclusive Gateway", name: "", size: s(46, 46), family: .gateway, clip: .diamond, labelBelow: true),
            .andGateway: KindInfo(title: "Parallel Gateway", name: "", size: s(46, 46), family: .gateway, clip: .diamond, labelBelow: true),
            .orGateway: KindInfo(title: "Inclusive Gateway", name: "", size: s(46, 46), family: .gateway, clip: .diamond, labelBelow: true),
            .dataObject: KindInfo(title: "Data Object", name: "Data", size: s(40, 52), family: .data, clip: .rect, labelBelow: true),
            .dataStore: KindInfo(title: "Data Store", name: "Store", size: s(56, 50), family: .data, clip: .rect, labelBelow: true),
            .pool: KindInfo(title: "Pool / Lane", name: "Participant", size: s(760, 220), family: .container, clip: .rect, container: true),
            .annotation: KindInfo(title: "Text Annotation", name: "Annotation", size: s(150, 56), family: .text, clip: .rect),
            .central: KindInfo(title: "Central Topic", name: "Central Topic", size: s(190, 64), family: .mind, clip: .rect),
            .topic: KindInfo(title: "Topic", name: "Topic", size: s(140, 40), family: .mind, clip: .rect),
            .dfdProcess: KindInfo(title: "Process", name: "Process", size: s(110, 110), family: .flow, clip: .ellipse),
            .external: KindInfo(title: "External Entity", name: "Customer", size: s(130, 62), family: .structure, clip: .rect),
            .dfdStore: KindInfo(title: "Data Store", name: "D1  Orders", size: s(160, 44), family: .data, clip: .rect),
        ]
    }()
}

enum Marker { case none, open, filled, hollowTri, hollowDiamond, filledDiamond, circle }
enum LineStyle { case solid, dashed, dotted }

struct EdgeStyle {
    var line: LineStyle = .solid
    var start: Marker = .none
    var end: Marker = .none
    var stereo = ""
}

enum EdgeKind: String, Codable, CaseIterable {
    case association, directed, aggregation, composition, generalization, realization, dependency, anchor
    case include, extend
    case message, asyncMessage, reply, create
    case controlFlow, objectFlow, transition
    case deploy, importDep
    case relationship
    case flow
    case sequenceFlow, messageFlow, bpmnAssoc
    case branch
    case dataFlow

    var title: String {
        switch self {
        case .association: return "Association"
        case .directed: return "Directed Association"
        case .aggregation: return "Aggregation"
        case .composition: return "Composition"
        case .generalization: return "Generalization"
        case .realization: return "Realization"
        case .dependency: return "Dependency"
        case .anchor: return "Anchor (note link)"
        case .include: return "Include"
        case .extend: return "Extend"
        case .message: return "Message (sync)"
        case .asyncMessage: return "Message (async)"
        case .reply: return "Return Message"
        case .create: return "Create Message"
        case .controlFlow: return "Control Flow"
        case .objectFlow: return "Object Flow"
        case .transition: return "Transition"
        case .deploy: return "Deploy"
        case .importDep: return "Import"
        case .relationship: return "Relationship"
        case .flow: return "Flow"
        case .sequenceFlow: return "Sequence Flow"
        case .messageFlow: return "Message Flow"
        case .bpmnAssoc: return "Association"
        case .branch: return "Branch"
        case .dataFlow: return "Data Flow"
        }
    }

    var style: EdgeStyle {
        switch self {
        case .association: return EdgeStyle()
        case .directed: return EdgeStyle(end: .open)
        case .aggregation: return EdgeStyle(start: .hollowDiamond)
        case .composition: return EdgeStyle(start: .filledDiamond)
        case .generalization: return EdgeStyle(end: .hollowTri)
        case .realization: return EdgeStyle(line: .dashed, end: .hollowTri)
        case .dependency: return EdgeStyle(line: .dashed, end: .open)
        case .anchor: return EdgeStyle(line: .dotted)
        case .include: return EdgeStyle(line: .dashed, end: .open, stereo: "«include»")
        case .extend: return EdgeStyle(line: .dashed, end: .open, stereo: "«extend»")
        case .message: return EdgeStyle(end: .filled)
        case .asyncMessage: return EdgeStyle(end: .open)
        case .reply: return EdgeStyle(line: .dashed, end: .open)
        case .create: return EdgeStyle(line: .dashed, end: .open, stereo: "«create»")
        case .controlFlow, .objectFlow, .transition: return EdgeStyle(end: .open)
        case .deploy: return EdgeStyle(line: .dashed, end: .open, stereo: "«deploy»")
        case .importDep: return EdgeStyle(line: .dashed, end: .open, stereo: "«import»")
        case .relationship: return EdgeStyle()
        case .flow, .sequenceFlow, .dataFlow: return EdgeStyle(end: .filled)
        case .messageFlow: return EdgeStyle(line: .dashed, start: .circle, end: .hollowTri)
        case .bpmnAssoc: return EdgeStyle(line: .dotted)
        case .branch: return EdgeStyle()
        }
    }

    /// kinds that show multiplicities and role names at their ends
    var hasEnds: Bool { [.association, .directed, .aggregation, .composition, .relationship].contains(self) }
    var isMessage: Bool { [.message, .asyncMessage, .reply, .create].contains(self) }
}

enum DiagramType: String, Codable, CaseIterable, Identifiable {
    case classDiagram, useCase, sequence, activity, stateMachine, component, deployment, package, object, erd, flowchart, bpmn, mindMap, dfd
    var id: String { rawValue }

    var title: String {
        switch self {
        case .classDiagram: return "Class Diagram"
        case .useCase: return "Use Case Diagram"
        case .sequence: return "Sequence Diagram"
        case .activity: return "Activity Diagram"
        case .stateMachine: return "State Machine Diagram"
        case .component: return "Component Diagram"
        case .deployment: return "Deployment Diagram"
        case .package: return "Package Diagram"
        case .object: return "Object Diagram"
        case .erd: return "Entity Relationship Diagram"
        case .flowchart: return "Flowchart"
        case .bpmn: return "Business Process (BPMN)"
        case .mindMap: return "Mind Map"
        case .dfd: return "Data Flow Diagram"
        }
    }

    var short: String {
        switch self {
        case .classDiagram: return "Class"
        case .useCase: return "Use Case"
        case .sequence: return "Sequence"
        case .activity: return "Activity"
        case .stateMachine: return "State Machine"
        case .component: return "Component"
        case .deployment: return "Deployment"
        case .package: return "Package"
        case .object: return "Object"
        case .erd: return "ERD"
        case .flowchart: return "Flowchart"
        case .bpmn: return "BPMN"
        case .mindMap: return "Mind Map"
        case .dfd: return "Data Flow"
        }
    }

    var icon: String {
        switch self {
        case .classDiagram: return "rectangle.split.3x1"
        case .useCase: return "figure.stand"
        case .sequence: return "arrow.left.arrow.right"
        case .activity: return "arrow.triangle.branch"
        case .stateMachine: return "circle.circle"
        case .component: return "puzzlepiece.extension"
        case .deployment: return "server.rack"
        case .package: return "shippingbox"
        case .object: return "cube"
        case .erd: return "tablecells"
        case .flowchart: return "diamond"
        case .bpmn: return "flowchart"
        case .mindMap: return "brain.head.profile"
        case .dfd: return "arrow.triangle.swap"
        }
    }

    var group: String {
        switch self {
        case .erd: return "Database"
        case .flowchart, .bpmn, .dfd, .mindMap: return "Business & Diagrams"
        default: return "UML"
        }
    }

    var blurb: String {
        switch self {
        case .classDiagram: return "Classes, attributes, methods and how they relate. Generates Java."
        case .useCase: return "Who uses the system and what they can do with it."
        case .sequence: return "Objects calling each other's methods, in time order."
        case .activity: return "Steps, decisions and parallel work — like if/else and loops."
        case .stateMachine: return "The states an object moves through and what triggers each change."
        case .component: return "The building blocks of a system and their interfaces."
        case .deployment: return "Which software runs on which machine."
        case .package: return "How classes are grouped into Java packages."
        case .object: return "A snapshot of objects and their values at one moment."
        case .erd: return "Database tables, keys and relationships. Generates SQL and JPA."
        case .flowchart: return "Classic program and process flow."
        case .bpmn: return "Business processes with pools, lanes, events and gateways."
        case .mindMap: return "Brainstorm ideas around a central topic. Tab adds a child."
        case .dfd: return "How data moves between processes, stores and outside parties."
        }
    }

    var nodes: [NodeKind] {
        switch self {
        case .classDiagram: return [.klass, .interface, .enumeration, .package, .note]
        case .useCase: return [.actor, .useCase, .boundary, .note]
        case .sequence: return [.lifeline, .actorLifeline, .fragment, .note]
        case .activity: return [.initial, .action, .decision, .merge, .fork, .final, .flowFinal, .lane, .objectNode, .sendSignal, .acceptEvent, .note]
        case .stateMachine: return [.initial, .state, .choice, .history, .final, .note]
        case .component: return [.component, .provided, .interface, .artifact, .package, .note]
        case .deployment: return [.node3d, .device, .execEnv, .artifact, .component, .note]
        case .package: return [.package, .klass, .interface, .note]
        case .object: return [.object, .klass, .note]
        case .erd: return [.entity, .note]
        case .flowchart: return [.terminator, .process, .fDecision, .io, .predefined, .document, .database, .manualInput, .preparation, .connector, .note]
        case .bpmn: return [.startEvent, .interEvent, .endEvent, .task, .subProcess, .xorGateway, .andGateway, .orGateway, .dataObject, .dataStore, .pool, .annotation]
        case .mindMap: return [.central, .topic, .note]
        case .dfd: return [.external, .dfdProcess, .dfdStore, .note]
        }
    }

    var edges: [EdgeKind] {
        switch self {
        case .classDiagram: return [.association, .directed, .aggregation, .composition, .generalization, .realization, .dependency, .anchor]
        case .useCase: return [.association, .include, .extend, .generalization, .anchor]
        case .sequence: return [.message, .asyncMessage, .reply, .create, .anchor]
        case .activity: return [.controlFlow, .objectFlow, .anchor]
        case .stateMachine: return [.transition, .anchor]
        case .component: return [.dependency, .realization, .association, .anchor]
        case .deployment: return [.association, .deploy, .dependency, .anchor]
        case .package: return [.dependency, .importDep, .generalization, .anchor]
        case .object: return [.association, .anchor]
        case .erd: return [.relationship, .anchor]
        case .flowchart: return [.flow, .anchor]
        case .bpmn: return [.sequenceFlow, .messageFlow, .bpmnAssoc]
        case .mindMap: return [.branch, .anchor]
        case .dfd: return [.dataFlow, .anchor]
        }
    }

    var routing: Routing {
        switch self {
        case .activity, .flowchart, .bpmn: return .orthogonal
        case .mindMap, .dfd: return .curved
        default: return .straight
        }
    }

    /// the connector created when you drag from one shape to another
    func defaultEdge(_ a: Node, _ b: Node) -> EdgeKind {
        if a.kind.isNoteLike || b.kind.isNoteLike {
            return self == .bpmn ? .bpmnAssoc : .anchor
        }
        switch self {
        case .classDiagram, .package:
            if b.kind == .interface && a.kind == .klass { return .realization }
            if a.kind == .interface && b.kind == .interface { return .generalization }
            if a.kind == .package || b.kind == .package { return .dependency }
            return self == .package ? .dependency : .association
        case .useCase:
            if a.kind == .actor && b.kind == .actor { return .generalization }
            if a.kind == .useCase && b.kind == .useCase { return .include }
            return .association
        case .sequence: return .message
        case .activity: return (a.kind == .objectNode || b.kind == .objectNode) ? .objectFlow : .controlFlow
        case .stateMachine: return .transition
        case .component: return (b.kind == .provided || b.kind == .interface) && a.kind == .component ? .realization : .dependency
        case .deployment: return a.kind == .artifact ? .deploy : .association
        case .object: return .association
        case .erd: return .relationship
        case .flowchart: return .flow
        case .bpmn:
            if [.dataObject, .dataStore].contains(a.kind) || [.dataObject, .dataStore].contains(b.kind) { return .bpmnAssoc }
            if a.kind == .pool || b.kind == .pool { return .messageFlow }
            return .sequenceFlow
        case .mindMap: return .branch
        case .dfd: return .dataFlow
        }
    }
}

enum Tool: Equatable {
    case node(NodeKind)
    case edge(EdgeKind)
}
