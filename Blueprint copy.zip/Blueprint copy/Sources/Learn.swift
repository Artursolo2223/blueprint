import AppKit

struct Quiz {
    let q: String
    let options: [String]
    let answer: Int
    let why: String
}

struct Lesson: Identifiable {
    let id: Int
    let title: String
    let icon: String
    let text: String
    let java: String
    let build: () -> Diagram
    let quiz: Quiz
}

enum Lessons {
    static let all: [Lesson] = [
        Lesson(id: 1, title: "Classes and objects", icon: "rectangle.split.3x1",
               text: "A class box has three parts: the name at the top, the attributes (the data) in the middle and the operations (the methods) at the bottom. In Java the box becomes a class. Every time you write new, Java creates an object from that class – the object diagram on the right shows one.",
               java: """
               public class Dog {
                   private String name;
                   private int age;

                   public void bark() {
                       System.out.println(name + " says woof");
                   }
               }

               // somewhere else:
               Dog rex = new Dog();   // an object (instance) of Dog
               """,
               build: {
                   let b = DB("Lesson: Classes and objects", .classDiagram)
                   let c = b.n(.klass, "Dog", 40, 40, a: ["- name : String", "- age : int"], o: ["+ bark() : void"])
                   let o = b.n(.object, "rex", 300, 50, a: ["name = \"Rex\"", "age = 3"], props: ["classifier": "Dog"])
                   b.e(.dependency, o, c, "«instanceOf»")
                   return b.d
               },
               quiz: Quiz(q: "Which part of a class box holds the methods?", options: ["The top part", "The middle part", "The bottom part"], answer: 2,
                          why: "Top: the name. Middle: the attributes (fields). Bottom: the operations (methods).")),

        Lesson(id: 2, title: "Visibility  + − # ~", icon: "eye",
               text: "The symbol in front of a member says who may use it. + is public, − is private, # is protected and ~ is package-private (no keyword in Java). Java programmers usually make fields private and methods public: that is called encapsulation.",
               java: """
               public class BankAccount {
                   private double balance;     // -  only BankAccount itself
                   protected String owner;     // #  also subclasses
                   String branch;              // ~  classes in the same package

                   public void deposit(double amount) {   // +  everyone
                       balance += amount;
                   }
               }
               """,
               build: {
                   let b = DB("Lesson: Visibility", .classDiagram)
                   b.n(.klass, "BankAccount", 40, 40, a: ["- balance : double", "# owner : String", "~ branch : String"], o: ["+ deposit(amount: double) : void"])
                   return b.d
               },
               quiz: Quiz(q: "What does − (minus) in front of an attribute mean?", options: ["public", "private", "protected", "package-private"], answer: 1,
                          why: "− is private: only code inside the class can see it.")),

        Lesson(id: 3, title: "Operations and parameters", icon: "function",
               text: "UML writes the type after a colon: add(a: int, b: int) : int. Java writes the type first: int add(int a, int b). A return type of void means the method gives nothing back.",
               java: """
               public class Calculator {
                   public int add(int a, int b) {
                       return a + b;
                   }

                   public void reset() {
                       // nothing is returned
                   }

                   public double average(int[] values) {
                       int sum = 0;
                       for (int v : values) sum += v;
                       return (double) sum / values.length;
                   }
               }
               """,
               build: {
                   let b = DB("Lesson: Operations", .classDiagram)
                   b.n(.klass, "Calculator", 40, 40, o: ["+ add(a: int, b: int) : int", "+ reset() : void", "+ average(values: int[]) : double"])
                   return b.d
               },
               quiz: Quiz(q: "How do you write the UML operation area(r: double) : double in Java?", options: ["area double(r double)", "double area(double r)", "void area(double r)"], answer: 1,
                          why: "Java puts the return type first and writes each parameter as type name.")),

        Lesson(id: 4, title: "Static members", icon: "underline",
               text: "Underlined members are static: they belong to the class itself, not to one object. There is one shared copy. You call them on the class name, like Math.max(a, b) or Counter.getCount().",
               java: """
               public class Counter {
                   private static int count = 0;   // shared by all counters
                   private int id;                 // every counter has its own

                   public Counter() {
                       count++;
                       id = count;
                   }

                   public static int getCount() {
                       return count;
                   }
               }

               new Counter(); new Counter();
               System.out.println(Counter.getCount());   // 2
               """,
               build: {
                   let b = DB("Lesson: Static", .classDiagram)
                   b.n(.klass, "Counter", 40, 40, a: ["- static count : int = 0", "- id : int"], o: ["+ Counter()", "+ static getCount() : int"])
                   return b.d
               },
               quiz: Quiz(q: "How is a static attribute shown in UML?", options: ["In italics", "Underlined", "With a # in front"], answer: 1,
                          why: "Static members are underlined. Italics mean abstract.")),

        Lesson(id: 5, title: "Constructors and encapsulation", icon: "lock",
               text: "A constructor has the same name as the class and no return type; it runs when you write new. Private fields with public getters and setters let the class check every change – here setAge refuses negative ages.",
               java: """
               public class Person {
                   private String name;
                   private int age;

                   public Person(String name, int age) {
                       this.name = name;
                       setAge(age);
                   }

                   public int getAge() {
                       return age;
                   }

                   public void setAge(int age) {
                       if (age < 0) throw new IllegalArgumentException("age < 0");
                       this.age = age;
                   }
               }
               """,
               build: {
                   let b = DB("Lesson: Encapsulation", .classDiagram)
                   b.n(.klass, "Person", 40, 40, a: ["- name : String", "- age : int"], o: ["+ Person(name: String, age: int)", "+ getAge() : int", "+ setAge(age: int) : void"])
                   return b.d
               },
               quiz: Quiz(q: "What is special about a constructor?", options: ["It always returns void", "It has the class name and no return type", "It must be static"], answer: 1,
                          why: "A constructor is named after its class and has no return type at all – not even void.")),

        Lesson(id: 6, title: "Inheritance – extends", icon: "arrow.up.right",
               text: "A solid line with a hollow triangle points from the subclass to the superclass. In Java that is class Cat extends Animal. Cat gets everything Animal has and can override methods. Java allows only one superclass.",
               java: """
               public class Animal {
                   protected String name;

                   public void makeSound() {
                       System.out.println("...");
                   }
               }

               public class Cat extends Animal {
                   @Override
                   public void makeSound() {
                       System.out.println(name + ": Meow");
                   }
               }
               """,
               build: {
                   let b = DB("Lesson: Inheritance", .classDiagram)
                   let a = b.n(.klass, "Animal", 130, 40, a: ["# name : String"], o: ["+ makeSound() : void"])
                   let c = b.n(.klass, "Cat", 40, 220, o: ["+ makeSound() : void"])
                   let d = b.n(.klass, "Dog", 250, 220, o: ["+ makeSound() : void", "+ fetch() : void"])
                   b.e(.generalization, c, a)
                   b.e(.generalization, d, a)
                   return b.d
               },
               quiz: Quiz(q: "Which arrow means extends?", options: ["Dashed line, open arrow", "Solid line, hollow triangle", "Line with a filled diamond"], answer: 1,
                          why: "Generalization is a solid line with a hollow triangle at the superclass.")),

        Lesson(id: 7, title: "Abstract classes", icon: "italic",
               text: "A class name in italics is abstract: you can't create it with new. An italic operation has no body – every concrete subclass must implement it, or the compiler complains.",
               java: """
               public abstract class Shape {
                   public abstract double area();
               }

               public class Circle extends Shape {
                   private double radius;

                   @Override
                   public double area() {
                       return Math.PI * radius * radius;
                   }
               }

               Shape s = new Circle();   // fine
               Shape t = new Shape();    // compile error: Shape is abstract
               """,
               build: {
                   let b = DB("Lesson: Abstract classes", .classDiagram)
                   let s = b.n(.klass, "Shape", 140, 40, o: ["+ abstract area() : double"], abstract: true)
                   let c = b.n(.klass, "Circle", 40, 200, a: ["- radius : double"], o: ["+ area() : double"])
                   let r = b.n(.klass, "Rectangle", 260, 200, a: ["- width : double", "- height : double"], o: ["+ area() : double"])
                   b.e(.generalization, c, s)
                   b.e(.generalization, r, s)
                   return b.d
               },
               quiz: Quiz(q: "Shape is abstract. Can you write new Shape()?", options: ["Yes", "No"], answer: 1,
                          why: "Abstract classes can't be instantiated; create a subclass such as Circle instead.")),

        Lesson(id: 8, title: "Interfaces – implements", icon: "square.dashed",
               text: "An «interface» lists methods without code. A dashed line with a hollow triangle means a class implements it and promises to write those methods. One class can implement many interfaces – Java's answer to multiple inheritance.",
               java: """
               public interface Flyable {
                   void fly();
               }

               public interface Swimmable {
                   void swim();
               }

               public class Duck implements Flyable, Swimmable {
                   @Override public void fly()  { System.out.println("flap flap"); }
                   @Override public void swim() { System.out.println("paddle"); }
               }
               """,
               build: {
                   let b = DB("Lesson: Interfaces", .classDiagram)
                   let f = b.n(.interface, "Flyable", 40, 40, o: ["+ fly() : void"])
                   let s = b.n(.interface, "Swimmable", 260, 40, o: ["+ swim() : void"])
                   let d = b.n(.klass, "Duck", 150, 220, o: ["+ fly() : void", "+ swim() : void"])
                   b.e(.realization, d, f)
                   b.e(.realization, d, s)
                   return b.d
               },
               quiz: Quiz(q: "How many interfaces can one Java class implement?", options: ["Only one", "Two", "As many as it needs"], answer: 2,
                          why: "A class extends at most one class but may implement any number of interfaces.")),

        Lesson(id: 9, title: "Enumerations", icon: "list.number",
               text: "An «enumeration» is a fixed list of values. A variable of type Day can only hold one of those values, so typos are caught by the compiler. Enums work great with switch.",
               java: """
               public enum Day {
                   MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
               }

               Day today = Day.SATURDAY;
               switch (today) {
                   case SATURDAY, SUNDAY -> System.out.println("Weekend!");
                   default -> System.out.println("Work day");
               }
               """,
               build: {
                   let b = DB("Lesson: Enums", .classDiagram)
                   b.n(.enumeration, "Day", 40, 40, a: ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"])
                   return b.d
               },
               quiz: Quiz(q: "Which line uses the enum correctly?", options: ["Day d = \"MONDAY\";", "Day d = Day.MONDAY;", "Day d = new Day();"], answer: 1,
                          why: "Enum values are constants on the enum type: Day.MONDAY. You can't create new ones.")),

        Lesson(id: 10, title: "Associations and multiplicity", icon: "line.diagonal",
               text: "A line between two classes means their objects know each other. The numbers are multiplicities: 1 = exactly one, 0..1 = optional, * or 0..* = any number, 1..* = at least one. A 'many' end usually becomes a List in Java; an arrow shows which side keeps the reference.",
               java: """
               public class Teacher {
                   // 0..* -> a list
                   private List<Course> courses = new ArrayList<>();
               }

               public class Course {
                   // 1 -> a single reference
                   private Room room;
               }
               """,
               build: {
                   let b = DB("Lesson: Associations", .classDiagram)
                   let t = b.n(.klass, "Teacher", 40, 60, a: ["- name : String"])
                   let c = b.n(.klass, "Course", 300, 60, a: ["- title : String"])
                   let r = b.n(.klass, "Room", 560, 60, a: ["- number : int"])
                   b.e(.directed, t, c, "teaches", fm: "1", tm: "0..*", tr: "courses")
                   b.e(.directed, c, r, tm: "1", tr: "room")
                   return b.d
               },
               quiz: Quiz(q: "What does multiplicity 0..* usually become in Java?", options: ["An int", "A List (collection)", "A static field"], answer: 1,
                          why: "Any number of objects needs a collection such as List<Course>.")),

        Lesson(id: 11, title: "Aggregation vs composition", icon: "diamond",
               text: "Both mean has-a. A hollow diamond (aggregation) says the parts can live on their own: a Team has Players who can change teams. A filled diamond (composition) says the parts belong to the whole: a House's Rooms disappear with the House. In Java the whole usually creates its composed parts itself.",
               java: """
               public class Team {                     // aggregation
                   private List<Player> players = new ArrayList<>();
                   public void add(Player p) { players.add(p); }   // players come from outside
               }

               public class House {                    // composition
                   private final List<Room> rooms = new ArrayList<>();
                   public House(int count) {
                       for (int i = 0; i < count; i++) rooms.add(new Room());   // House makes its rooms
                   }
               }
               """,
               build: {
                   let b = DB("Lesson: Aggregation and composition", .classDiagram)
                   let t = b.n(.klass, "Team", 40, 40)
                   let p = b.n(.klass, "Player", 300, 40)
                   let h = b.n(.klass, "House", 40, 200)
                   let r = b.n(.klass, "Room", 300, 200)
                   b.e(.aggregation, t, p, fm: "0..1", tm: "0..*")
                   b.e(.composition, h, r, fm: "1", tm: "1..*")
                   return b.d
               },
               quiz: Quiz(q: "A Book has Pages that can't exist without it. Which diamond?", options: ["Hollow (aggregation)", "Filled (composition)"], answer: 1,
                          why: "The pages live and die with the book: that's composition.")),

        Lesson(id: 12, title: "Dependency", icon: "arrow.right.circle.dotted",
               text: "A dashed arrow means one class uses another only for a moment – as a parameter, a local variable or a return value – but doesn't keep a field of it.",
               java: """
               public class Printer {
                   public void print(Document doc) {   // uses Document, keeps nothing
                       System.out.println(doc.getText());
                   }
               }
               """,
               build: {
                   let b = DB("Lesson: Dependency", .classDiagram)
                   let p = b.n(.klass, "Printer", 40, 40, o: ["+ print(doc: Document) : void"])
                   let d = b.n(.klass, "Document", 330, 40, o: ["+ getText() : String"])
                   b.e(.dependency, p, d)
                   return b.d
               },
               quiz: Quiz(q: "Printer has print(Document d) but no Document field. Which relationship?", options: ["Association", "Dependency", "Composition"], answer: 1,
                          why: "Using a class only as a parameter is a dependency (dashed arrow).")),

        Lesson(id: 13, title: "Packages and imports", icon: "shippingbox",
               text: "A package groups related classes, like folders. The package statement goes at the top of each file, and classes from another package are brought in with import.",
               java: """
               package shop.ui;

               import shop.model.Order;

               public class OrderView {
                   private Order order;
               }
               """,
               build: {
                   let b = DB("Lesson: Packages", .package)
                   let ui = b.n(.package, "ui", 40, 40, w: 220, h: 140)
                   b.n(.klass, "OrderView", 80, 90, w: 140)
                   let model = b.n(.package, "model", 340, 40, w: 220, h: 140)
                   b.n(.klass, "Order", 400, 90, w: 110)
                   b.e(.importDep, ui, model)
                   return b.d
               },
               quiz: Quiz(q: "Which keyword lets you use a class from another package?", options: ["include", "import", "using"], answer: 1,
                          why: "Java uses import, e.g. import java.util.List;")),

        Lesson(id: 14, title: "Sequence diagrams are method calls", icon: "arrow.left.arrow.right",
               text: "Each lifeline is an object. A solid arrow with a filled head is a method call on the object it points at; the dashed arrow back is the return value. Time runs down the page, so you can read the code line by line.",
               java: """
               // Main
               double t = order.total();

               // Order
               public double total() {
                   double sum = 0;
                   for (OrderLine line : lines) {
                       sum += line.subtotal();
                   }
                   return sum;
               }
               """,
               build: {
                   let b = DB("Lesson: Sequence", .sequence)
                   let m = b.n(.lifeline, "", 40, 40, w: 110, h: 280, props: ["classifier": "Main"])
                   let o = b.n(.lifeline, "order", 220, 40, w: 110, h: 280, props: ["classifier": "Order"])
                   let l = b.n(.lifeline, "line", 400, 40, w: 120, h: 280, props: ["classifier": "OrderLine"])
                   b.n(.fragment, "for each line", 200, 140, w: 350, h: 120, props: ["operator": "loop"])
                   b.e(.message, m, o, "total()", y: 110)
                   b.e(.message, o, l, "subtotal()", y: 180)
                   b.e(.reply, l, o, "double", y: 220)
                   b.e(.reply, o, m, "sum", y: 290)
                   return b.d
               },
               quiz: Quiz(q: "In a sequence diagram, what does a dashed arrow usually show?", options: ["Creating an object", "A return value", "An error"], answer: 1,
                          why: "The dashed arrow goes back to the caller with the result.")),

        Lesson(id: 15, title: "State machines: enum + switch", icon: "circle.circle",
               text: "Each rounded box is a state; arrows are transitions triggered by events. A common Java way to build one is an enum for the states and a switch that picks the next state.",
               java: """
               enum Light { RED, GREEN, YELLOW }

               private Light state = Light.RED;     // the black dot

               public void timer() {                 // the event on every arrow
                   state = switch (state) {
                       case RED -> Light.GREEN;
                       case GREEN -> Light.YELLOW;
                       case YELLOW -> Light.RED;
                   };
               }
               """,
               build: {
                   let b = DB("Lesson: State machine", .stateMachine)
                   let s = b.n(.initial, "", 40, 62)
                   let r = b.n(.state, "Red", 110, 44)
                   let g = b.n(.state, "Green", 360, 44)
                   let y = b.n(.state, "Yellow", 235, 190)
                   b.e(.transition, s, r)
                   b.e(.transition, r, g, "timer")
                   b.e(.transition, g, y, "timer")
                   b.e(.transition, y, r, "timer")
                   return b.d
               },
               quiz: Quiz(q: "What does the black dot mean?", options: ["The end", "The initial state", "An error"], answer: 1,
                          why: "The filled dot marks where the machine starts; the bull's-eye is the end.")),

        Lesson(id: 16, title: "Activity diagrams: if and while", icon: "arrow.triangle.branch",
               text: "Actions are steps, a diamond is an if/else and an arrow that goes back up is a loop. An activity diagram is a picture of the code inside a method.",
               java: """
               int n = scanner.nextInt();
               while (n > 0) {
                   System.out.println(n);
                   n = n - 1;
               }
               System.out.println("Lift off!");
               """,
               build: {
                   let b = DB("Lesson: Activity", .activity)
                   let s = b.n(.initial, "", 107, 20)
                   let read = b.n(.action, "Read n", 50, 70)
                   let dec = b.n(.decision, "", 98, 160)
                   let pr = b.n(.action, "Print n", 50, 250)
                   let dn = b.n(.action, "n = n − 1", 50, 340)
                   let lift = b.n(.action, "Print \"Lift off!\"", 260, 153)
                   let e = b.n(.final, "", 315, 260)
                   b.e(.controlFlow, s, read)
                   b.e(.controlFlow, read, dec)
                   b.e(.controlFlow, dec, pr, "[n > 0]")
                   b.e(.controlFlow, pr, dn)
                   b.e(.controlFlow, dn, dec, via: [CGPoint(x: 20, y: 367), CGPoint(x: 20, y: 182)])
                   b.e(.controlFlow, dec, lift, "[else]")
                   b.e(.controlFlow, lift, e)
                   return b.d
               },
               quiz: Quiz(q: "An arrow back to an earlier decision is…", options: ["A loop", "A method call", "An exception"], answer: 0,
                          why: "Going back and checking the condition again is exactly a while loop.")),

        Lesson(id: 17, title: "Tables become JPA entities", icon: "tablecells",
               text: "With JPA (Hibernate) each table becomes a Java class marked @Entity. The primary key gets @Id, and a foreign key becomes a reference to the other object with @ManyToOne.",
               java: """
               @Entity
               public class Book {
                   @Id
                   @GeneratedValue
                   private Long id;

                   private String title;

                   @ManyToOne
                   @JoinColumn(name = "author_id")
                   private Author author;
               }
               """,
               build: {
                   let b = DB("Lesson: Tables and JPA", .erd)
                   let a = b.n(.entity, "author", 40, 40, a: ["PK id : INTEGER", "name : VARCHAR(80) NN"])
                   let k = b.n(.entity, "book", 330, 40, a: ["PK id : INTEGER", "title : VARCHAR(200) NN", "FK author_id : INTEGER -> author.id NN"])
                   b.e(.relationship, a, k, fm: "1", tm: "0..*")
                   return b.d
               },
               quiz: Quiz(q: "Which annotation marks the primary key field?", options: ["@Key", "@Id", "@Primary"], answer: 1,
                          why: "@Id tells JPA which field is the primary key.")),
    ]

    static var done: Set<Int> {
        get { Set(UserDefaults.standard.array(forKey: "lessonsDone") as? [Int] ?? []) }
        set { UserDefaults.standard.set(Array(newValue), forKey: "lessonsDone") }
    }
}
