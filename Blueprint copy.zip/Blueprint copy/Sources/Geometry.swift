import AppKit

/// the points of a drawn connector; a curve is [start, control1, control2, end]
struct Route {
    var pts: [CGPoint]
    var curved = false

    var start: CGPoint { pts.first ?? .zero }
    var end: CGPoint { pts.last ?? .zero }

    /// unit vector pointing into the end point
    var endDir: CGPoint {
        guard pts.count >= 2 else { return CGPoint(x: 1, y: 0) }
        var i = pts.count - 2
        while i > 0 && pts[i].dist(end) < 0.5 { i -= 1 }
        return (end - pts[i]).unit
    }
    /// unit vector pointing into the start point
    var startDir: CGPoint {
        guard pts.count >= 2 else { return CGPoint(x: -1, y: 0) }
        var i = 1
        while i < pts.count - 1 && pts[i].dist(start) < 0.5 { i += 1 }
        return (start - pts[i]).unit
    }

    func sample(_ t: CGFloat) -> CGPoint {
        let (p0, c1, c2, p3) = (pts[0], pts[1], pts[2], pts[3])
        let u = 1 - t
        return p0 * (u * u * u) + c1 * (3 * u * u * t) + c2 * (3 * u * t * t) + p3 * (t * t * t)
    }

    /// polyline that follows the route (curves are sampled)
    var polyline: [CGPoint] {
        guard curved, pts.count == 4 else { return pts }
        return (0...24).map { sample(CGFloat($0) / 24) }
    }

    /// the middle of the route and the direction there
    var middle: (CGPoint, CGPoint) {
        let line = polyline
        guard line.count >= 2 else { return (start, CGPoint(x: 1, y: 0)) }
        var total: CGFloat = 0
        for i in 1..<line.count { total += line[i].dist(line[i - 1]) }
        var walked: CGFloat = 0
        for i in 1..<line.count {
            let seg = line[i].dist(line[i - 1])
            if walked + seg >= total / 2 && seg > 0 {
                let t = (total / 2 - walked) / seg
                return (line[i - 1] + (line[i] - line[i - 1]) * t, (line[i] - line[i - 1]).unit)
            }
            walked += seg
        }
        return (line[line.count / 2], (line.last! - line.first!).unit)
    }

    var cgPath: CGPath {
        let p = CGMutablePath()
        guard let f = pts.first else { return p }
        p.move(to: f)
        if curved && pts.count == 4 {
            p.addCurve(to: pts[3], control1: pts[1], control2: pts[2])
        } else {
            for q in pts.dropFirst() { p.addLine(to: q) }
        }
        return p
    }

    var bounds: CGRect {
        let line = polyline
        guard let f = line.first else { return .null }
        var r = CGRect(origin: f, size: .zero)
        for q in line { r = r.union(CGRect(origin: q, size: .zero)) }
        return r
    }

    func distance(to p: CGPoint) -> CGFloat {
        let line = polyline
        guard line.count >= 2 else { return .infinity }
        var best = CGFloat.infinity
        for i in 1..<line.count { best = min(best, Geo.segDist(p, line[i - 1], line[i])) }
        return best
    }

    /// index of the segment closest to p (for inserting bend points)
    func segment(near p: CGPoint) -> Int {
        var best = CGFloat.infinity, idx = 0
        for i in 1..<pts.count {
            let d = Geo.segDist(p, pts[i - 1], pts[i])
            if d < best { best = d; idx = i - 1 }
        }
        return idx
    }
}

enum Geo {
    static let lifelineHeader: CGFloat = 40
    static let actorHeader: CGFloat = 78
    static let actorLabel: CGFloat = 18

    static func segDist(_ p: CGPoint, _ a: CGPoint, _ b: CGPoint) -> CGFloat {
        let ab = b - a
        let l2 = ab.x * ab.x + ab.y * ab.y
        if l2 < 0.0001 { return p.dist(a) }
        let t = max(0, min(1, ((p.x - a.x) * ab.x + (p.y - a.y) * ab.y) / l2))
        return p.dist(a + ab * t)
    }

    /// the header box of a lifeline
    static func header(_ n: Node) -> CGRect {
        let h = n.kind == .actorLifeline ? actorHeader : lifelineHeader
        return CGRect(x: n.frame.minX, y: n.frame.minY, width: n.frame.width, height: min(h, n.frame.height))
    }

    /// the part of a shape that connectors attach to
    static func clipRect(_ n: Node) -> CGRect {
        switch n.kind {
        case .actor: return CGRect(x: n.frame.minX, y: n.frame.minY, width: n.frame.width, height: max(10, n.frame.height - actorLabel))
        case .lifeline, .actorLifeline: return header(n)
        default: return n.frame
        }
    }

    static func boundary(_ n: Node, toward p: CGPoint) -> CGPoint {
        let r = clipRect(n)
        let c = r.center
        var d = p - c
        if d.length < 0.001 { d = CGPoint(x: 0, y: -1) }
        let hw = max(r.width / 2, 0.5), hh = max(r.height / 2, 0.5)
        let t: CGFloat
        switch n.kind.info.clip {
        case .rect:
            let tx = abs(d.x) < 0.0001 ? CGFloat.infinity : hw / abs(d.x)
            let ty = abs(d.y) < 0.0001 ? CGFloat.infinity : hh / abs(d.y)
            t = min(tx, ty)
        case .ellipse:
            t = 1 / sqrt(pow(d.x / hw, 2) + pow(d.y / hh, 2))
        case .diamond:
            t = 1 / (abs(d.x) / hw + abs(d.y) / hh)
        }
        return c + d * t
    }

    /// where a vertical line at x leaves the shape (top or bottom)
    static func edgeY(_ n: Node, _ x: CGFloat, bottom: Bool) -> CGFloat {
        let r = clipRect(n)
        let hw = r.width / 2, hh = r.height / 2
        let k = min(1, abs(x - r.midX) / max(hw, 0.5))
        let off: CGFloat
        switch n.kind.info.clip {
        case .rect: off = hh
        case .ellipse: off = hh * sqrt(max(0, 1 - k * k))
        case .diamond: off = hh * (1 - k)
        }
        return bottom ? r.midY + off : r.midY - off
    }

    static func edgeX(_ n: Node, _ y: CGFloat, right: Bool) -> CGFloat {
        let r = clipRect(n)
        let hw = r.width / 2, hh = r.height / 2
        let k = min(1, abs(y - r.midY) / max(hh, 0.5))
        let off: CGFloat
        switch n.kind.info.clip {
        case .rect: off = hw
        case .ellipse: off = hw * sqrt(max(0, 1 - k * k))
        case .diamond: off = hw * (1 - k)
        }
        return right ? r.midX + off : r.midX - off
    }

    static func defaultMessageY(_ a: Node, _ b: Node) -> CGFloat {
        max(header(a).maxY, header(b).maxY) + 30
    }

    static func route(_ e: Edge, _ nodes: [UUID: Node], sequence: Bool, spread: CGFloat = 0) -> Route? {
        guard let a = nodes[e.from], let b = nodes[e.to] else { return nil }

        // sequence messages run horizontally between lifelines
        if sequence && a.kind.isLifeline && b.kind.isLifeline {
            let y = CGFloat(e.y ?? Double(defaultMessageY(a, b)))
            if a.id == b.id {
                let x = a.frame.midX + 5
                return Route(pts: [CGPoint(x: x, y: y), CGPoint(x: x + 44, y: y), CGPoint(x: x + 44, y: y + 22), CGPoint(x: x, y: y + 22)])
            }
            let dir: CGFloat = b.frame.midX > a.frame.midX ? 1 : -1
            let x1 = a.frame.midX + 5 * dir
            var x2 = b.frame.midX - 5 * dir
            if e.kind == .create {
                let h = header(b)
                if y >= h.minY && y <= h.maxY { x2 = dir > 0 ? h.minX : h.maxX }
            }
            return Route(pts: [CGPoint(x: x1, y: y), CGPoint(x: x2, y: y)])
        }

        // a connector from a shape to itself loops over its top right corner (several loops nest)
        if a.id == b.id {
            let r = clipRect(a)
            let k = 26 + 16 * abs(spread)
            return Route(pts: [CGPoint(x: r.maxX - 18, y: r.minY), CGPoint(x: r.maxX - 18, y: r.minY - k),
                               CGPoint(x: r.maxX + k, y: r.minY - k), CGPoint(x: r.maxX + k, y: r.minY + 18),
                               CGPoint(x: r.maxX, y: r.minY + 18)])
        }

        // several connectors between the same two shapes are pulled apart
        let ca = clipRect(a).center, cb = clipRect(b).center
        // measured along one fixed direction, so connectors running opposite ways still separate
        let shift = (e.from.uuidString < e.to.uuidString ? cb - ca : ca - cb).unit.perp * (spread * 20)
        let wps = e.points
        switch e.routing {
        case .straight:
            if wps.isEmpty && spread != 0 {
                let mid = CGPoint(x: (ca.x + cb.x) / 2, y: (ca.y + cb.y) / 2) + shift
                return Route(pts: [boundary(a, toward: mid), mid, boundary(b, toward: mid)])
            }
            let p0 = boundary(a, toward: wps.first ?? cb)
            let pn = boundary(b, toward: wps.last ?? ca)
            return Route(pts: [p0] + wps + [pn])
        case .orthogonal:
            var pts = clean(wps.isEmpty ? ortho(a, b) : orthoThrough(a, b, wps))
            if wps.isEmpty && spread != 0 {
                let s = spread * 16
                if pts.count == 2 {
                    if abs(pts[0].x - pts[1].x) < 0.5 { pts[0].x += s; pts[1].x += s } else { pts[0].y += s; pts[1].y += s }
                } else if pts.count == 4 {
                    if abs(pts[0].y - pts[1].y) < 0.5 { pts[1].x += s; pts[2].x += s } else { pts[1].y += s; pts[2].y += s }
                }
            }
            return Route(pts: pts)
        case .curved:
            if let w0 = wps.first, let wn = wps.last {
                return Route(pts: [boundary(a, toward: w0), w0, wn, boundary(b, toward: wn)], curved: true)
            }
            let ra = clipRect(a), rb = clipRect(b)
            let dx = rb.midX - ra.midX, dy = rb.midY - ra.midY
            if abs(dx) >= abs(dy) {
                let p0 = CGPoint(x: edgeX(a, ra.midY, right: dx > 0), y: ra.midY)
                let p3 = CGPoint(x: edgeX(b, rb.midY, right: dx < 0), y: rb.midY)
                let mx = (p0.x + p3.x) / 2
                return Route(pts: [p0, CGPoint(x: mx, y: p0.y) + shift * 1.5, CGPoint(x: mx, y: p3.y) + shift * 1.5, p3], curved: true)
            } else {
                let p0 = CGPoint(x: ra.midX, y: edgeY(a, ra.midX, bottom: dy > 0))
                let p3 = CGPoint(x: rb.midX, y: edgeY(b, rb.midX, bottom: dy < 0))
                let my = (p0.y + p3.y) / 2
                return Route(pts: [p0, CGPoint(x: p0.x, y: my) + shift * 1.5, CGPoint(x: p3.x, y: my) + shift * 1.5, p3], curved: true)
            }
        }
    }

    static func clean(_ pts: [CGPoint]) -> [CGPoint] {
        var out: [CGPoint] = []
        for p in pts where out.last.map({ $0.dist(p) > 0.5 }) ?? true { out.append(p) }
        return out.count >= 2 ? out : pts
    }

    static func ortho(_ a: Node, _ b: Node) -> [CGPoint] {
        let ra = clipRect(a), rb = clipRect(b)
        let ox0 = max(ra.minX, rb.minX), ox1 = min(ra.maxX, rb.maxX)
        let oy0 = max(ra.minY, rb.minY), oy1 = min(ra.maxY, rb.maxY)
        func pick(_ lo: CGFloat, _ hi: CGFloat, _ c1: CGFloat, _ c2: CGFloat) -> CGFloat {
            if c1 >= lo && c1 <= hi { return c1 }
            if c2 >= lo && c2 <= hi { return c2 }
            return (lo + hi) / 2
        }
        if ox1 - ox0 > 12 && (rb.minY >= ra.maxY || ra.minY >= rb.maxY) {
            let x = pick(ox0 + 6, ox1 - 6, ra.midX, rb.midX)
            let down = rb.midY > ra.midY
            return [CGPoint(x: x, y: edgeY(a, x, bottom: down)), CGPoint(x: x, y: edgeY(b, x, bottom: !down))]
        }
        if oy1 - oy0 > 12 && (rb.minX >= ra.maxX || ra.minX >= rb.maxX) {
            let y = pick(oy0 + 6, oy1 - 6, ra.midY, rb.midY)
            let right = rb.midX > ra.midX
            return [CGPoint(x: edgeX(a, y, right: right), y: y), CGPoint(x: edgeX(b, y, right: !right), y: y)]
        }
        let dx = rb.midX - ra.midX, dy = rb.midY - ra.midY
        if abs(dx) >= abs(dy) {
            let x0 = edgeX(a, ra.midY, right: dx > 0), x3 = edgeX(b, rb.midY, right: dx < 0)
            let mx = (x0 + x3) / 2
            return [CGPoint(x: x0, y: ra.midY), CGPoint(x: mx, y: ra.midY), CGPoint(x: mx, y: rb.midY), CGPoint(x: x3, y: rb.midY)]
        } else {
            let y0 = edgeY(a, ra.midX, bottom: dy > 0), y3 = edgeY(b, rb.midX, bottom: dy < 0)
            let my = (y0 + y3) / 2
            return [CGPoint(x: ra.midX, y: y0), CGPoint(x: ra.midX, y: my), CGPoint(x: rb.midX, y: my), CGPoint(x: rb.midX, y: y3)]
        }
    }

    /// where an orthogonal line toward w leaves the shape, and whether it leaves sideways
    static func port(_ n: Node, toward w: CGPoint) -> (CGPoint, Bool) {
        let r = clipRect(n)
        if w.x > r.minX + 4 && w.x < r.maxX - 4 {
            let down = w.y > r.midY
            return (CGPoint(x: w.x, y: edgeY(n, w.x, bottom: down)), false)
        }
        if w.y > r.minY + 4 && w.y < r.maxY - 4 {
            let right = w.x > r.midX
            return (CGPoint(x: edgeX(n, w.y, right: right), y: w.y), true)
        }
        if abs(w.x - r.midX) >= abs(w.y - r.midY) {
            return (CGPoint(x: edgeX(n, r.midY, right: w.x > r.midX), y: r.midY), true)
        }
        return (CGPoint(x: r.midX, y: edgeY(n, r.midX, bottom: w.y > r.midY)), false)
    }

    static func orthoThrough(_ a: Node, _ b: Node, _ wps: [CGPoint]) -> [CGPoint] {
        let (p0, h0) = port(a, toward: wps[0])
        let (pn, _) = port(b, toward: wps[wps.count - 1])
        let raw = [p0] + wps + [pn]
        var out = [raw[0]]
        var horizontal = h0
        for q in raw.dropFirst() {
            let p = out.last!
            if abs(p.x - q.x) > 0.5 && abs(p.y - q.y) > 0.5 {
                // bend once; the leg into q is perpendicular, so the next leg runs the same way as this one
                out.append(horizontal ? CGPoint(x: q.x, y: p.y) : CGPoint(x: p.x, y: q.y))
            } else {
                horizontal = abs(p.y - q.y) <= 0.5
                horizontal.toggle()
            }
            out.append(q)
        }
        return out
    }
}
