import AppKit
import SwiftUI
import Combine

/// one window per project
final class ProjectWindow: NSObject, NSWindowDelegate {
    let store: Store
    let window: NSWindow
    private var subs: Set<AnyCancellable> = []

    init(store: Store) {
        self.store = store
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1440, height: 900),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView],
                          backing: .buffered, defer: false)
        super.init()
        window.titlebarAppearsTransparent = true
        window.titleVisibility = .hidden
        window.isReleasedWhenClosed = false
        window.delegate = self
        window.minSize = NSSize(width: 1080, height: 660)
        window.tabbingMode = .disallowed
        window.contentView = NSHostingView(rootView: RootView(s: store))
        store.window = window
        store.$dirty.sink { [weak self] d in self?.window.isDocumentEdited = d }.store(in: &subs)
        store.objectWillChange.sink { [weak self] _ in DispatchQueue.main.async { self?.updateTitle() } }.store(in: &subs)
        updateTitle()
    }

    func updateTitle() {
        window.title = store.title
        if window.representedURL != store.fileURL { window.representedURL = store.fileURL }
    }

    func windowShouldClose(_ sender: NSWindow) -> Bool { confirmClose() }

    /// Save / Don't Save / Cancel when there are unsaved changes
    func confirmClose() -> Bool {
        guard store.dirty && !store.project.diagrams.isEmpty else { return true }
        window.makeKeyAndOrderFront(nil)
        let a = NSAlert()
        a.messageText = "Save changes to “\(store.title)”?"
        a.informativeText = "Your changes are lost if you don't save them."
        a.addButton(withTitle: "Save")
        a.addButton(withTitle: "Cancel")
        a.addButton(withTitle: "Don't Save")
        switch a.runModal() {
        case .alertFirstButtonReturn: return store.save()
        case .alertThirdButtonReturn: return true
        default: return false
        }
    }

    func windowWillClose(_ n: Notification) { AppDelegate.shared.closed(self) }
}

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuItemValidation, NSMenuDelegate {
    static var shared: AppDelegate!
    var windows: [ProjectWindow] = []
    private let recentMenu = NSMenu(title: "Open Recent")
    private var launchedWithFiles = false

    var current: Store? {
        if let w = NSApp.keyWindow ?? NSApp.mainWindow, let pw = windows.first(where: { $0.window == w || $0.window.attachedSheet == w }) { return pw.store }
        return windows.last?.store
    }

    func applicationDidFinishLaunching(_ n: Notification) {
        let d = UserDefaults.standard
        for k in ["NSAutomaticSpellingCorrectionEnabled", "NSAutomaticQuoteSubstitutionEnabled", "NSAutomaticDashSubstitutionEnabled",
                  "NSAutomaticTextReplacementEnabled", "NSAutomaticTextCompletionEnabled", "NSAutomaticPeriodSubstitutionEnabled",
                  "NSAutomaticCapitalizationEnabled", "NSContinuousSpellCheckingEnabled", "NSAutomaticInlinePredictionEnabled"] {
            d.set(false, forKey: k)
        }
        buildMenu()
        if let dir = ProcessInfo.processInfo.environment["BP_SELFTEST"] {
            SelfTest.run(dir)
            return
        }
        if !launchedWithFiles && windows.isEmpty {
            let reopen = (d.stringArray(forKey: "openFiles") ?? []).map { URL(fileURLWithPath: $0) }
                .filter { FileManager.default.fileExists(atPath: $0.path) }
            if !reopen.isEmpty {
                reopen.forEach { open($0) }
            } else if !d.bool(forKey: "launchedBefore") {
                newWindow(Samples.starterProject(), url: nil)
            } else {
                newWindow(Project(), url: nil)
            }
        }
        d.set(true, forKey: "launchedBefore")
        if ProcessInfo.processInfo.environment["BP_BACKGROUND"] == nil { NSApp.activate(ignoringOtherApps: true) }
    }

    func application(_ app: NSApplication, open urls: [URL]) {
        launchedWithFiles = true
        for u in urls { open(u) }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ s: NSApplication) -> Bool { false }

    func applicationShouldHandleReopen(_ s: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag && windows.isEmpty { newWindow(Project(), url: nil) }
        return true
    }

    func applicationShouldTerminate(_ s: NSApplication) -> NSApplication.TerminateReply {
        UserDefaults.standard.set(windows.compactMap { $0.store.fileURL?.path }, forKey: "openFiles")
        for w in windows where w.store.dirty {
            if !w.confirmClose() { return .terminateCancel }
            w.store.dirty = false
        }
        return .terminateNow
    }

    // MARK: windows

    @discardableResult
    func newWindow(_ p: Project, url: URL?) -> ProjectWindow {
        let pw = ProjectWindow(store: Store(project: p, url: url))
        if let last = windows.last?.window {
            pw.window.setFrame(last.frame, display: false)
            pw.window.setFrameTopLeftPoint(pw.window.cascadeTopLeft(from: NSPoint(x: last.frame.minX, y: last.frame.maxY)))
        } else if let screen = NSScreen.main {
            let vis = screen.visibleFrame
            let w = min(1480, vis.width - 40), h = min(940, vis.height - 40)
            pw.window.setFrame(NSRect(x: vis.midX - w / 2, y: vis.midY - h / 2, width: w, height: h), display: false)
        }
        windows.append(pw)
        if ProcessInfo.processInfo.environment["BP_BACKGROUND"] == nil { pw.window.makeKeyAndOrderFront(nil) } else { pw.window.orderBack(nil) }
        return pw
    }

    func closed(_ pw: ProjectWindow) {
        windows.removeAll { $0 === pw }
    }

    func open(_ url: URL) {
        if let w = windows.first(where: { $0.store.fileURL?.standardizedFileURL == url.standardizedFileURL }) {
            w.window.makeKeyAndOrderFront(nil)
            return
        }
        do {
            let p = try Store.load(url)
            // an empty untitled window is replaced by the opened project
            if let only = windows.first, windows.count == 1, only.store.fileURL == nil, only.store.project.diagrams.isEmpty {
                only.window.close()
            }
            newWindow(p, url: url)
            Recent.add(url)
        } catch {
            let a = NSAlert()
            a.messageText = "Couldn't open \(url.lastPathComponent)"
            a.informativeText = error.localizedDescription
            a.runModal()
        }
    }

    // MARK: menu actions

    @objc func newProject(_ sender: Any?) { newWindow(Project(), url: nil) }

    @objc func openDocument(_ sender: Any?) {
        let p = NSOpenPanel()
        p.allowedContentTypes = [Store.fileType]
        p.allowsMultipleSelection = true
        guard p.runModal() == .OK else { return }
        p.urls.forEach { open($0) }
    }

    @objc func openRecent(_ sender: NSMenuItem) {
        if let path = sender.representedObject as? String { open(URL(fileURLWithPath: path)) }
    }

    @objc func clearRecent(_ sender: Any?) { Recent.clear(); NSDocumentController.shared.clearRecentDocuments(nil) }

    @objc func saveDocument(_ sender: Any?) { current?.save() }
    @objc func saveDocumentAs(_ sender: Any?) { current?.save(as: true) }

    @objc func newDiagram(_ sender: NSMenuItem) {
        guard let s = current else { return }
        let types = DiagramType.allCases
        let i = sender.tag % 100
        guard i < types.count else { return }
        s.newDiagram(types[i], example: sender.tag >= 100)
    }

    @objc func exportPNG(_ sender: Any?) { if let s = current { Exporter.exportCurrent(s, .png) } }
    @objc func exportPDF(_ sender: Any?) { if let s = current { Exporter.exportCurrent(s, .pdf) } }
    @objc func exportSVG(_ sender: Any?) { if let s = current { Exporter.exportCurrent(s, .svg) } }
    @objc func exportAllPDF(_ sender: Any?) { if let s = current { Exporter.exportAllPDF(s) } }
    @objc func exportReport(_ sender: Any?) { if let s = current { Exporter.exportReport(s) } }
    @objc func printDiagram(_ sender: Any?) { if let s = current { Exporter.printDiagram(s) } }
    @objc func copyImage(_ sender: Any?) { if let s = current { Exporter.copyImage(s) } }

    @objc func generateJava(_ sender: Any?) { current?.codeFocus = nil; current?.sheet = .java }
    @objc func reverseJava(_ sender: Any?) { current?.sheet = .reverseJava }
    @objc func generateSQL(_ sender: Any?) { current?.codeFocus = nil; current?.sheet = .sql }
    @objc func reverseSQL(_ sender: Any?) { current?.sheet = .reverseSQL }
    @objc func validateModel(_ sender: Any?) { current?.validate() }
    @objc func learn(_ sender: Any?) { current?.sheet = .learn }
    @objc func shortcuts(_ sender: Any?) { current?.sheet = .shortcuts }

    // fallbacks when the canvas isn't the first responder
    @objc func undo(_ sender: Any?) { current?.undo() }
    @objc func redo(_ sender: Any?) { current?.redo() }
    @objc func copy(_ sender: Any?) { current?.copySelection() }
    @objc func cut(_ sender: Any?) { current?.cutSelection() }
    @objc func paste(_ sender: Any?) { current?.paste() }
    @objc func delete(_ sender: Any?) { current?.deleteSelection() }
    @objc func duplicate(_ sender: Any?) { current?.duplicate() }
    @objc func selectAll(_ sender: Any?) { current?.selectAll() }
    @objc func find(_ sender: Any?) {
        guard let s = current else { return }
        s.showSidebar = true
        DispatchQueue.main.async { s.focusSearch += 1 }
    }
    @objc func copyFormat(_ sender: Any?) { current?.copyFormat() }
    @objc func pasteFormat(_ sender: Any?) { current?.pasteFormat() }

    @objc func zoomIn(_ sender: Any?) { current?.canvas?.zoomIn() }
    @objc func zoomOut(_ sender: Any?) { current?.canvas?.zoomOut() }
    @objc func zoomActual(_ sender: Any?) { current?.canvas?.zoomActual() }
    @objc func zoomFit(_ sender: Any?) { current?.canvas?.zoomToFit() }
    @objc func toggleGrid(_ sender: Any?) { current?.showGrid.toggle() }
    @objc func toggleSnap(_ sender: Any?) { current?.snap.toggle() }
    @objc func toggleOverview(_ sender: Any?) { current?.showOverview.toggle() }
    @objc func toggleInspector(_ sender: Any?) { current?.showInspector.toggle() }
    @objc func toggleSidebarPane(_ sender: Any?) { current?.showSidebar.toggle() }
    @objc func canvasTheme(_ sender: NSMenuItem) { current?.canvasTheme = sender.tag }

    @objc func align(_ sender: NSMenuItem) { current?.align(sender.tag) }
    @objc func distribute(_ sender: NSMenuItem) { current?.distribute(horizontal: sender.tag == 0) }
    @objc func sameSize(_ sender: NSMenuItem) { current?.sameSize(sender.tag) }
    @objc func order(_ sender: NSMenuItem) { current?.order(sender.tag) }
    @objc func layout(_ sender: NSMenuItem) { current?.autoLayout(LayoutStyle.allCases[sender.tag]) }
    @objc func routing(_ sender: NSMenuItem) { current?.setRouting(Routing.allCases[sender.tag]) }
    @objc func addAttribute(_ sender: Any?) { current?.addMember(op: false) }
    @objc func addOperation(_ sender: Any?) { current?.addMember(op: true) }
    @objc func renameSelection(_ sender: Any?) {
        guard let s = current, let id = s.selection.first else { return }
        if s.node(id) != nil { s.canvas?.beginEditName(id) } else if s.edge(id) != nil { s.canvas?.beginEditEdge(id) }
    }
    @objc func closeTab(_ sender: Any?) { if let s = current, let id = s.currentId { s.closeTab(id) } }
    @objc func nextTab(_ sender: NSMenuItem) {
        guard let s = current, let c = s.currentId, let i = s.tabs.firstIndex(of: c), s.tabs.count > 1 else { return }
        s.open(s.tabs[(i + (sender.tag == 0 ? 1 : s.tabs.count - 1)) % s.tabs.count])
    }

    func validateMenuItem(_ item: NSMenuItem) -> Bool {
        let s = current
        let hasDiagram = s?.diagram != nil
        let sel = s?.selection.count ?? 0
        switch item.action {
        case #selector(toggleGrid(_:)): item.state = s?.showGrid == true ? .on : .off
        case #selector(toggleSnap(_:)): item.state = s?.snap == true ? .on : .off
        case #selector(toggleOverview(_:)): item.state = s?.showOverview == true ? .on : .off
        case #selector(toggleInspector(_:)): item.state = s?.showInspector == true ? .on : .off
        case #selector(toggleSidebarPane(_:)): item.state = s?.showSidebar == true ? .on : .off
        case #selector(canvasTheme(_:)): item.state = s?.canvasTheme == item.tag ? .on : .off
        default: break
        }
        switch item.action {
        case #selector(undo(_:)): return s?.canUndo ?? false
        case #selector(redo(_:)): return s?.canRedo ?? false
        case #selector(copy(_:)), #selector(cut(_:)), #selector(delete(_:)), #selector(duplicate(_:)), #selector(copyFormat(_:)), #selector(renameSelection(_:)):
            return sel > 0
        case #selector(paste(_:)): return s?.canPaste ?? false
        case #selector(pasteFormat(_:)): return sel > 0 && s?.copiedStyle != nil
        case #selector(align(_:)), #selector(sameSize(_:)): return (s?.selectedNodes.count ?? 0) >= 2
        case #selector(distribute(_:)): return (s?.selectedNodes.count ?? 0) >= 3
        case #selector(order(_:)): return sel > 0
        case #selector(addAttribute(_:)), #selector(addOperation(_:)):
            guard let n = s?.selectedNodes.first, sel == 1 else { return false }
            return [.klass, .interface, .enumeration, .entity, .object].contains(n.kind) && (item.action != #selector(addOperation(_:)) || ![.entity, .object].contains(n.kind))
        case #selector(exportPNG(_:)), #selector(exportPDF(_:)), #selector(exportSVG(_:)), #selector(printDiagram(_:)), #selector(copyImage(_:)),
             #selector(zoomIn(_:)), #selector(zoomOut(_:)), #selector(zoomActual(_:)), #selector(zoomFit(_:)), #selector(layout(_:)), #selector(routing(_:)),
             #selector(selectAll(_:)), #selector(closeTab(_:)):
            return hasDiagram
        case #selector(saveDocument(_:)), #selector(saveDocumentAs(_:)), #selector(newDiagram(_:)), #selector(generateJava(_:)), #selector(reverseJava(_:)),
             #selector(generateSQL(_:)), #selector(reverseSQL(_:)), #selector(validateModel(_:)), #selector(learn(_:)), #selector(shortcuts(_:)),
             #selector(exportAllPDF(_:)), #selector(exportReport(_:)):
            return s != nil
        default:
            return true
        }
    }

    // MARK: menu bar

    func menuNeedsUpdate(_ menu: NSMenu) {
        guard menu === recentMenu else { return }
        menu.removeAllItems()
        let list = Recent.urls
        if list.isEmpty {
            let it = NSMenuItem(title: "No Recent Projects", action: nil, keyEquivalent: "")
            it.isEnabled = false
            menu.addItem(it)
        }
        for u in list {
            let it = NSMenuItem(title: u.deletingPathExtension().lastPathComponent, action: #selector(openRecent(_:)), keyEquivalent: "")
            it.representedObject = u.path
            it.target = self
            it.toolTip = u.path
            menu.addItem(it)
        }
        menu.addItem(.separator())
        let clear = NSMenuItem(title: "Clear Menu", action: #selector(clearRecent(_:)), keyEquivalent: "")
        clear.target = self
        menu.addItem(clear)
    }

    @discardableResult
    private func item(_ m: NSMenu, _ title: String, _ action: Selector?, _ key: String = "", _ mods: NSEvent.ModifierFlags = .command, tag: Int = 0, mine: Bool = true) -> NSMenuItem {
        let it = NSMenuItem(title: title, action: action, keyEquivalent: key)
        it.keyEquivalentModifierMask = mods
        it.tag = tag
        if mine { it.target = self }
        m.addItem(it)
        return it
    }

    private func submenu(_ parent: NSMenu, _ title: String) -> NSMenu {
        let m = NSMenu(title: title)
        let it = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        it.submenu = m
        parent.addItem(it)
        return m
    }

    private func top(_ bar: NSMenu, _ title: String) -> NSMenu {
        let m = NSMenu(title: title)
        let it = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        it.submenu = m
        bar.addItem(it)
        return m
    }

    private func diagramTypesMenu(_ m: NSMenu) {
        for (i, t) in DiagramType.allCases.enumerated() {
            let it = item(m, t.title, #selector(newDiagram(_:)), tag: i)
            it.image = NSImage(systemSymbolName: t.icon, accessibilityDescription: nil)
        }
        m.addItem(.separator())
        let ex = submenu(m, "From Example")
        for (i, t) in DiagramType.allCases.enumerated() { item(ex, t.title, #selector(newDiagram(_:)), tag: 100 + i) }
    }

    func buildMenu() {
        let bar = NSMenu()

        let app = top(bar, "Blueprint")
        item(app, "About Blueprint", #selector(NSApplication.orderFrontStandardAboutPanel(_:)), mine: false)
        app.addItem(.separator())
        let services = submenu(app, "Services")
        NSApp.servicesMenu = services
        app.addItem(.separator())
        item(app, "Hide Blueprint", #selector(NSApplication.hide(_:)), "h", mine: false)
        item(app, "Hide Others", #selector(NSApplication.hideOtherApplications(_:)), "h", [.command, .option], mine: false)
        item(app, "Show All", #selector(NSApplication.unhideAllApplications(_:)), mine: false)
        app.addItem(.separator())
        item(app, "Quit Blueprint", #selector(NSApplication.terminate(_:)), "q", mine: false)

        let file = top(bar, "File")
        item(file, "New Project", #selector(newProject(_:)), "n")
        let nd = submenu(file, "New Diagram")
        diagramTypesMenu(nd)
        item(file, "Open…", #selector(openDocument(_:)), "o")
        let recent = NSMenuItem(title: "Open Recent", action: nil, keyEquivalent: "")
        recent.submenu = recentMenu
        recentMenu.delegate = self
        file.addItem(recent)
        file.addItem(.separator())
        item(file, "Close Window", #selector(NSWindow.performClose(_:)), "w", [.command, .shift], mine: false)
        item(file, "Close Diagram Tab", #selector(closeTab(_:)), "w")
        item(file, "Save", #selector(saveDocument(_:)), "s")
        item(file, "Save As…", #selector(saveDocumentAs(_:)), "s", [.command, .shift])
        file.addItem(.separator())
        let imp = submenu(file, "Import")
        item(imp, "Java Source (Reverse Engineer)…", #selector(reverseJava(_:)))
        item(imp, "SQL DDL (Reverse Engineer)…", #selector(reverseSQL(_:)))
        let exp = submenu(file, "Export")
        item(exp, "Diagram as PNG…", #selector(exportPNG(_:)), "e")
        item(exp, "Diagram as PDF…", #selector(exportPDF(_:)))
        item(exp, "Diagram as SVG…", #selector(exportSVG(_:)))
        item(exp, "All Diagrams as PDF…", #selector(exportAllPDF(_:)))
        exp.addItem(.separator())
        item(exp, "HTML Report…", #selector(exportReport(_:)))
        item(exp, "Java Code…", #selector(generateJava(_:)))
        item(exp, "SQL / JPA…", #selector(generateSQL(_:)))
        file.addItem(.separator())
        item(file, "Print…", #selector(printDiagram(_:)), "p")

        let edit = top(bar, "Edit")
        item(edit, "Undo", #selector(undo(_:)), "z", mine: false)
        item(edit, "Redo", #selector(redo(_:)), "z", [.command, .shift], mine: false)
        edit.addItem(.separator())
        item(edit, "Cut", #selector(cut(_:)), "x", mine: false)
        item(edit, "Copy", #selector(copy(_:)), "c", mine: false)
        item(edit, "Paste", #selector(paste(_:)), "v", mine: false)
        item(edit, "Duplicate", #selector(duplicate(_:)), "d", mine: false)
        item(edit, "Delete", #selector(delete(_:)), "", [], mine: false)
        item(edit, "Select All", #selector(selectAll(_:)), "a", mine: false)
        edit.addItem(.separator())
        item(edit, "Find…", #selector(find(_:)), "f")
        item(edit, "Rename", #selector(renameSelection(_:)))
        item(edit, "Copy Format", #selector(copyFormat(_:)), "c", [.command, .option])
        item(edit, "Paste Format", #selector(pasteFormat(_:)), "v", [.command, .option])
        item(edit, "Copy Diagram as Picture", #selector(copyImage(_:)), "c", [.command, .shift])

        let view = top(bar, "View")
        item(view, "Zoom In", #selector(zoomIn(_:)), "+")
        item(view, "Zoom In", #selector(zoomIn(_:)), "=").isHidden = true
        item(view, "Zoom Out", #selector(zoomOut(_:)), "-")
        item(view, "Actual Size", #selector(zoomActual(_:)), "0")
        item(view, "Zoom to Fit", #selector(zoomFit(_:)), "0", [.command, .option])
        view.addItem(.separator())
        item(view, "Show Grid", #selector(toggleGrid(_:)), "'")
        item(view, "Snap to Grid", #selector(toggleSnap(_:)), "'", [.command, .option])
        item(view, "Show Overview", #selector(toggleOverview(_:)), "m", [.command, .option])
        let theme = submenu(view, "Paper")
        item(theme, "Match System", #selector(canvasTheme(_:)), tag: 0)
        item(theme, "Light", #selector(canvasTheme(_:)), tag: 1)
        item(theme, "Dark", #selector(canvasTheme(_:)), tag: 2)
        view.addItem(.separator())
        item(view, "Show Toolbox and Project", #selector(toggleSidebarPane(_:)), "s", [.command, .option])
        item(view, "Show Properties", #selector(toggleInspector(_:)), "i", [.command, .option])
        item(view, "Next Diagram Tab", #selector(nextTab(_:)), "}", [.command], tag: 0)
        item(view, "Previous Diagram Tab", #selector(nextTab(_:)), "{", [.command], tag: 1)
        view.addItem(.separator())
        item(view, "Enter Full Screen", #selector(NSWindow.toggleFullScreen(_:)), "f", [.command, .control], mine: false)

        let diagram = top(bar, "Diagram")
        diagramTypesMenu(submenu(diagram, "New Diagram"))
        diagram.addItem(.separator())
        item(diagram, "Add Attribute", #selector(addAttribute(_:)), "a", [.option, .shift])
        item(diagram, "Add Operation", #selector(addOperation(_:)), "o", [.option, .shift])
        diagram.addItem(.separator())
        let lay = submenu(diagram, "Auto Layout")
        for (i, st) in LayoutStyle.allCases.enumerated() {
            item(lay, st.title, #selector(layout(_:)), i == 0 ? "l" : "", [.command, .shift], tag: i)
        }
        let rt = submenu(diagram, "Connector Style")
        for (i, r) in Routing.allCases.enumerated() { item(rt, r.title, #selector(routing(_:)), tag: i) }
        diagram.addItem(.separator())
        item(diagram, "Check Model…", #selector(validateModel(_:)), "k", [.command, .shift])

        let arrange = top(bar, "Arrange")
        let al = submenu(arrange, "Align")
        for (i, t) in ["Left Edges", "Centres", "Right Edges", "Top Edges", "Middles", "Bottom Edges"].enumerated() { item(al, t, #selector(align(_:)), tag: i) }
        let di = submenu(arrange, "Distribute")
        item(di, "Horizontally", #selector(distribute(_:)), tag: 0)
        item(di, "Vertically", #selector(distribute(_:)), tag: 1)
        let ss = submenu(arrange, "Make Same")
        item(ss, "Width", #selector(sameSize(_:)), tag: 0)
        item(ss, "Height", #selector(sameSize(_:)), tag: 1)
        item(ss, "Size", #selector(sameSize(_:)), tag: 2)
        arrange.addItem(.separator())
        item(arrange, "Bring to Front", #selector(order(_:)), "f", [.command, .shift], tag: 0)
        item(arrange, "Bring Forward", #selector(order(_:)), "f", [.command, .option], tag: 1)
        item(arrange, "Send Backward", #selector(order(_:)), "b", [.command, .option], tag: 2)
        item(arrange, "Send to Back", #selector(order(_:)), "b", [.command, .shift], tag: 3)

        let tools = top(bar, "Tools")
        item(tools, "Generate Java Code…", #selector(generateJava(_:)), "j", [.command, .shift])
        item(tools, "Reverse Engineer Java…", #selector(reverseJava(_:)), "j", [.command, .option])
        tools.addItem(.separator())
        item(tools, "Generate SQL / JPA…", #selector(generateSQL(_:)), "d", [.command, .option])
        item(tools, "Reverse Engineer SQL…", #selector(reverseSQL(_:)))
        tools.addItem(.separator())
        item(tools, "Check Model…", #selector(validateModel(_:)))
        item(tools, "HTML Report…", #selector(exportReport(_:)))
        tools.addItem(.separator())
        item(tools, "Learn Java with UML…", #selector(learn(_:)), "l", [.command, .option])

        let win = top(bar, "Window")
        item(win, "Minimize", #selector(NSWindow.performMiniaturize(_:)), "m", mine: false)
        item(win, "Zoom", #selector(NSWindow.performZoom(_:)), mine: false)
        win.addItem(.separator())
        item(win, "Bring All to Front", #selector(NSApplication.arrangeInFront(_:)), mine: false)
        NSApp.windowsMenu = win

        let help = top(bar, "Help")
        item(help, "Learn Java with UML", #selector(learn(_:)))
        item(help, "Shortcuts and Gestures", #selector(shortcuts(_:)), "/", [.command, .shift])
        NSApp.helpMenu = help

        NSApp.mainMenu = bar
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
AppDelegate.shared = delegate
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
