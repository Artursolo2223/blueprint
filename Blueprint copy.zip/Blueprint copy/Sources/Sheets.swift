import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct SheetHost: View {
    let kind: SheetKind
    @ObservedObject var s: Store

    var body: some View {
        Group {
            switch kind {
            case .java: JavaSheet(s: s)
            case .reverseJava: ReverseSheet(s: s, sql: false)
            case .sql: SQLSheet(s: s)
            case .reverseSQL: ReverseSheet(s: s, sql: true)
            case .validate: ValidateSheet(s: s)
            case .learn: LearnSheet(s: s)
            case .newDiagram: NewDiagramSheet(s: s)
            case .shortcuts: ShortcutsSheet(s: s)
            }
        }
        .background(AppBackground())
    }
}

struct SheetTitle: View {
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.system(size: 22, weight: .bold))
            Text(subtitle).font(.system(size: 12)).foregroundStyle(T.muted).fixedSize(horizontal: false, vertical: true)
        }
    }
}

/// list of files on the left, the chosen one on the right
struct FilesBrowser: View {
    let files: [GenFile]
    @Binding var selected: String?
    let lang: CodeLang

    var body: some View {
        let cur = files.first { $0.path == selected } ?? files.first
        HStack(spacing: 12) {
            ScrollView {
                VStack(alignment: .leading, spacing: 2) {
                    ForEach(files) { f in
                        Button { selected = f.path } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "doc.text").font(.system(size: 11)).foregroundStyle(T.accent)
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(f.name).font(.system(size: 12, weight: .medium)).lineLimit(1)
                                    let folder = (f.path as NSString).deletingLastPathComponent
                                    if !folder.isEmpty { Text(folder).font(.system(size: 10)).foregroundStyle(T.muted).lineLimit(1) }
                                }
                                Spacer()
                            }
                            .padding(.horizontal, 8)
                            .frame(height: 32)
                            .background(cur?.path == f.path ? T.accent.opacity(0.16) : Color.clear, in: RoundedRectangle(cornerRadius: 8))
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(6)
            }
            .frame(width: 220)
            .card(0)
            if let cur {
                CodeView(code: cur.code, lang: lang)
            } else {
                Text("Nothing to generate yet.").foregroundStyle(T.muted).frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }
}

struct JavaSheet: View {
    @ObservedObject var s: Store
    @StateObject private var sel = Box<String?>(nil)

    var body: some View {
        let files = JavaGen.generate(s.project, current: s.diagram, s.javaOpts)
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top) {
                SheetTitle(title: "Java code", subtitle: "Every class, interface and enum becomes a .java file. Arrows become extends, implements and fields.")
                Spacer()
                VStack(alignment: .leading, spacing: 4) {
                    Toggle("Explain the UML in comments", isOn: $s.javaOpts.explain)
                    Toggle("Getters and setters", isOn: $s.javaOpts.accessors)
                    Toggle("Constructors", isOn: $s.javaOpts.constructors)
                    Toggle("All class diagrams in the project", isOn: $s.javaOpts.allDiagrams)
                }
                .toggleStyle(.checkbox)
                .font(.system(size: 12))
            }
            if files.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "rectangle.split.3x1").font(.system(size: 34)).foregroundStyle(T.muted)
                    Text("There are no classes yet. Open a class diagram, or try the example.").foregroundStyle(T.muted)
                    Button("Add Example Class Diagram") { s.sheet = nil; s.newDiagram(.classDiagram, example: true) }.buttonStyle(PillStyle(prominent: true))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                FilesBrowser(files: files, selected: $sel.v, lang: .java)
            }
            HStack {
                Text("\(files.count) file\(files.count == 1 ? "" : "s")").font(.system(size: 12)).foregroundStyle(T.muted)
                Spacer()
                Button("Copy") {
                    let code = (files.first { $0.path == sel.v } ?? files.first)?.code ?? ""
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(code, forType: .string)
                    s.flash("Code copied")
                }
                .buttonStyle(PillStyle())
                .disabled(files.isEmpty)
                Button("Save Files…") { JavaGen.save(files, s) }.buttonStyle(PillStyle()).disabled(files.isEmpty)
                Button("Done") { s.sheet = nil }.buttonStyle(PillStyle(prominent: true)).keyboardShortcut(.defaultAction)
            }
        }
        .padding(22)
        .frame(width: 1000, height: 680)
        .onAppear {
            if let f = s.codeFocus, let file = files.first(where: { $0.node == f }) { sel.v = file.path }
        }
    }
}

struct SQLSheet: View {
    @ObservedObject var s: Store
    @StateObject private var dialect = Box(SQLDialect.standard)
    @StateObject private var jpa = Box(false)
    @StateObject private var sel = Box<String?>(nil)

    var body: some View {
        let list = SQLGen.entities(s.project, current: s.diagram)
        let title = s.diagram?.type == .erd ? s.diagram!.name : s.project.name
        let sql = SQLGen.ddl(list, dialect.v, title: title)
        let files = SQLGen.jpa(list, explain: s.javaOpts.explain)
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top) {
                SheetTitle(title: "Database code", subtitle: "CREATE TABLE statements for your ER diagram, or Java entity classes that JPA/Hibernate maps to those tables.")
                Spacer()
                VStack(alignment: .trailing, spacing: 6) {
                    Picker("", selection: $jpa.v) { Text("SQL").tag(false); Text("JPA entities (Java)").tag(true) }
                        .pickerStyle(.segmented).labelsHidden().frame(width: 260)
                    if jpa.v {
                        Toggle("Explain in comments", isOn: $s.javaOpts.explain).toggleStyle(.checkbox).font(.system(size: 12))
                    } else {
                        Picker("Dialect", selection: $dialect.v) { ForEach(SQLDialect.allCases) { Text($0.rawValue).tag($0) } }.frame(width: 260)
                    }
                }
            }
            if list.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "tablecells").font(.system(size: 34)).foregroundStyle(T.muted)
                    Text("There are no tables yet. Add an ER diagram first.").foregroundStyle(T.muted)
                    Button("Add Example ER Diagram") { s.sheet = nil; s.newDiagram(.erd, example: true) }.buttonStyle(PillStyle(prominent: true))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if jpa.v {
                FilesBrowser(files: files, selected: $sel.v, lang: .java)
            } else {
                CodeView(code: sql, lang: .sql)
            }
            HStack {
                Text("\(list.count) table\(list.count == 1 ? "" : "s")").font(.system(size: 12)).foregroundStyle(T.muted)
                Spacer()
                Button("Copy") {
                    let code = jpa.v ? ((files.first { $0.path == sel.v } ?? files.first)?.code ?? "") : sql
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(code, forType: .string)
                    s.flash("Copied")
                }
                .buttonStyle(PillStyle())
                .disabled(list.isEmpty)
                Button(jpa.v ? "Save Files…" : "Save .sql…") {
                    if jpa.v { JavaGen.save(files, s) }
                    else if let u = Exporter.savePanel(title, "sql") {
                        try? sql.write(to: u, atomically: true, encoding: .utf8)
                        s.flash("Saved \(u.lastPathComponent)")
                    }
                }
                .buttonStyle(PillStyle())
                .disabled(list.isEmpty)
                Button("Done") { s.sheet = nil }.buttonStyle(PillStyle(prominent: true)).keyboardShortcut(.defaultAction)
            }
        }
        .padding(22)
        .frame(width: 1000, height: 680)
        .onAppear {
            if let f = s.codeFocus, let file = files.first(where: { $0.node == f }) { sel.v = file.path }
        }
    }
}

enum ReverseSamples {
    static let java = """
    package library;

    import java.util.ArrayList;
    import java.util.List;

    public abstract class Item {
        protected String title;
        private int year;

        public abstract double lateFee(int days);
    }

    public class Book extends Item implements Borrowable {
        private String isbn;
        private Author author;

        public double lateFee(int days) { return days * 0.25; }
        public boolean borrow(Member member) { return true; }
    }

    public class Author {
        private String name;
        private final List<Book> books = new ArrayList<>();
    }

    public interface Borrowable {
        boolean borrow(Member member);
    }

    public class Member {
        private String name;
        private List<Book> borrowed;
        private MemberLevel level;
    }

    public enum MemberLevel { BASIC, SILVER, GOLD }
    """

    static let sql = """
    CREATE TABLE author (
        id INTEGER PRIMARY KEY,
        name VARCHAR(80) NOT NULL
    );

    CREATE TABLE book (
        id INTEGER PRIMARY KEY,
        title VARCHAR(200) NOT NULL,
        isbn CHAR(13) UNIQUE,
        author_id INTEGER NOT NULL REFERENCES author(id)
    );

    CREATE TABLE member (
        id INTEGER PRIMARY KEY,
        name VARCHAR(80) NOT NULL
    );

    CREATE TABLE loan (
        id INTEGER PRIMARY KEY,
        book_id INTEGER NOT NULL,
        member_id INTEGER NOT NULL,
        due DATE NOT NULL,
        FOREIGN KEY (book_id) REFERENCES book (id),
        FOREIGN KEY (member_id) REFERENCES member (id)
    );
    """
}

struct ReverseSheet: View {
    @ObservedObject var s: Store
    let sql: Bool
    @StateObject private var text = Box("")
    @StateObject private var status = Box("")

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SheetTitle(title: sql ? "Reverse engineer SQL" : "Reverse engineer Java",
                       subtitle: sql ? "Paste CREATE TABLE statements (or open .sql files). Blueprint draws the ER diagram with keys and relationships."
                                     : "Paste Java source or open .java files and folders. Fields become attributes or associations; extends and implements become arrows.")
            CodeEditor(text: $text.v)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(T.line, lineWidth: 0.5))
            HStack {
                Button(sql ? "Open .sql Files…" : "Open Files or Folder…") { load() }.buttonStyle(PillStyle())
                Button("Example") { text.v = sql ? ReverseSamples.sql : ReverseSamples.java }.buttonStyle(PillStyle())
                Button("Clear") { text.v = "" }.buttonStyle(PillStyle())
                Text(status.v).font(.system(size: 12)).foregroundStyle(T.orange)
                Spacer()
                Button("Cancel") { s.sheet = nil }.buttonStyle(PillStyle()).keyboardShortcut(.cancelAction)
                Button(sql ? "Create ER Diagram" : "Create Class Diagram") { build() }.buttonStyle(PillStyle(prominent: true)).keyboardShortcut(.defaultAction)
            }
        }
        .padding(22)
        .frame(width: 920, height: 640)
        .onAppear { if text.v.isEmpty { text.v = sql ? ReverseSamples.sql : ReverseSamples.java } }
    }

    func build() {
        if sql {
            let (d, n) = SQLParse.parse(text.v, name: "Reversed Database")
            guard n > 0 else { status.v = "No CREATE TABLE statements found."; return }
            s.sheet = nil
            s.addDiagram(d)
            s.flash("Found \(n) table\(n == 1 ? "" : "s")")
        } else {
            let (d, n) = JavaParser.diagram(from: text.v, name: "Reversed Classes")
            guard n > 0 else { status.v = "No classes, interfaces or enums found."; return }
            s.sheet = nil
            s.addDiagram(d)
            s.flash("Found \(n) type\(n == 1 ? "" : "s") and \(d.edges.count) relationship\(d.edges.count == 1 ? "" : "s")")
        }
    }

    func load() {
        let p = NSOpenPanel()
        p.allowsMultipleSelection = true
        p.canChooseDirectories = !sql
        p.allowedContentTypes = [UTType(filenameExtension: sql ? "sql" : "java") ?? .plainText, .plainText]
        guard p.runModal() == .OK else { return }
        var out: [String] = []
        let ext = sql ? "sql" : "java"
        for u in p.urls {
            var isDir: ObjCBool = false
            FileManager.default.fileExists(atPath: u.path, isDirectory: &isDir)
            if isDir.boolValue, let en = FileManager.default.enumerator(at: u, includingPropertiesForKeys: nil) {
                for case let f as URL in en where f.pathExtension == ext {
                    if let t = try? String(contentsOf: f, encoding: .utf8) { out.append(t) }
                    if out.count > 500 { break }
                }
            } else if let t = try? String(contentsOf: u, encoding: .utf8) {
                out.append(t)
            }
        }
        text.v = out.joined(separator: "\n\n")
        status.v = out.isEmpty ? "No .\(ext) files found." : ""
    }
}

struct ValidateSheet: View {
    @ObservedObject var s: Store

    var body: some View {
        let errors = s.issues.filter { $0.level == .error }.count
        let warnings = s.issues.filter { $0.level == .warning }.count
        let tips = s.issues.filter { $0.level == .tip }.count
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top) {
                SheetTitle(title: "Model check", subtitle: "Mistakes that would stop the Java compiler, plus tips about Java conventions. Click an item to show it.")
                Spacer()
                chip(errors, "errors", T.red)
                chip(warnings, "warnings", T.orange)
                chip(tips, "tips", T.yellow)
            }
            if s.issues.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "checkmark.seal.fill").font(.system(size: 44)).foregroundStyle(T.green)
                    Text("Everything looks right.").font(.system(size: 15, weight: .semibold))
                    Text("No problems in \(s.project.diagrams.count) diagram\(s.project.diagrams.count == 1 ? "" : "s").").foregroundStyle(T.muted)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(s.issues) { i in
                            Button {
                                s.sheet = nil
                                s.reveal(i.diagram, i.node)
                            } label: {
                                HStack(alignment: .top, spacing: 10) {
                                    Image(systemName: i.level == .error ? "xmark.octagon.fill" : i.level == .warning ? "exclamationmark.triangle.fill" : "lightbulb.fill")
                                        .foregroundStyle(i.level == .error ? T.red : i.level == .warning ? T.orange : T.yellow)
                                        .frame(width: 18)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(i.text).font(.system(size: 13)).fixedSize(horizontal: false, vertical: true).multilineTextAlignment(.leading)
                                        Text(i.diagramName).font(.system(size: 11)).foregroundStyle(T.muted)
                                    }
                                    Spacer()
                                }
                                .padding(10)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .card(0)
                        }
                    }
                }
            }
            HStack {
                Spacer()
                Button("Check Again") { s.issues = Validator.run(s.project) }.buttonStyle(PillStyle())
                Button("Done") { s.sheet = nil }.buttonStyle(PillStyle(prominent: true)).keyboardShortcut(.defaultAction)
            }
        }
        .padding(22)
        .frame(width: 760, height: 600)
    }

    func chip(_ n: Int, _ label: String, _ c: Color) -> some View {
        VStack(spacing: 0) {
            Text("\(n)").font(.system(size: 22, weight: .semibold)).monospacedDigit().foregroundStyle(n > 0 ? c : T.muted)
            Text(label).font(.system(size: 11)).foregroundStyle(T.muted)
        }
        .frame(width: 70)
    }
}

struct LearnSheet: View {
    @ObservedObject var s: Store
    @StateObject private var current = Box(Lessons.all.first { !Lessons.done.contains($0.id) }?.id ?? 1)
    @StateObject private var answer = Box<Int?>(nil)
    @StateObject private var done = Box(Lessons.done)
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let lesson = Lessons.all.first { $0.id == current.v } ?? Lessons.all[0]
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Learn Java").font(.system(size: 18, weight: .bold))
                ProgressView(value: Double(done.v.count), total: Double(Lessons.all.count)).tint(T.orange)
                Text("\(done.v.count) of \(Lessons.all.count) done").font(.system(size: 11)).foregroundStyle(T.muted)
                ScrollView {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(Lessons.all) { l in
                            Button {
                                current.v = l.id
                                answer.v = nil
                            } label: {
                                HStack(spacing: 8) {
                                    Image(systemName: done.v.contains(l.id) ? "checkmark.circle.fill" : l.icon)
                                        .font(.system(size: 12))
                                        .foregroundStyle(done.v.contains(l.id) ? T.green : T.accent)
                                        .frame(width: 18)
                                    Text("\(l.id). \(l.title)").font(.system(size: 12, weight: l.id == current.v ? .semibold : .regular)).lineLimit(1)
                                    Spacer()
                                }
                                .padding(.horizontal, 8)
                                .frame(height: 28)
                                .background(l.id == current.v ? T.accent.opacity(0.15) : Color.clear, in: RoundedRectangle(cornerRadius: 8))
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .frame(width: 250)
            .card(12)

            VStack(alignment: .leading, spacing: 12) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            Image(systemName: lesson.icon).font(.system(size: 20)).foregroundStyle(T.accent)
                            Text(lesson.title).font(.system(size: 22, weight: .bold))
                        }
                        Text(lesson.text).font(.system(size: 13.5)).lineSpacing(3).fixedSize(horizontal: false, vertical: true)
                        HStack(alignment: .top, spacing: 12) {
                            VStack(alignment: .leading, spacing: 6) {
                                SectionTitle(text: "UML")
                                Image(nsImage: Exporter.image(lesson.build(), fit: CGSize(width: 330, height: 280), dark: scheme == .dark))
                                    .frame(maxWidth: .infinity, minHeight: 120)
                                    .padding(8)
                                    .background(scheme == .dark ? Color(hex: 0x1B1D22) : Color(hex: 0xFCFCFD), in: RoundedRectangle(cornerRadius: 12))
                            }
                            .frame(maxWidth: .infinity)
                            VStack(alignment: .leading, spacing: 6) {
                                SectionTitle(text: "Java")
                                CodeView(code: lesson.java, lang: .java).frame(minHeight: 200, maxHeight: 300)
                            }
                            .frame(maxWidth: .infinity)
                        }
                        quiz(lesson)
                    }
                    .padding(.trailing, 4)
                }
                HStack {
                    Button("Open as Diagram") {
                        s.sheet = nil
                        s.addDiagram(Store.reidentified(lesson.build()))
                    }
                    .buttonStyle(PillStyle())
                    .help("Add this example to your project so you can change it and generate code")
                    Spacer()
                    if let next = Lessons.all.first(where: { $0.id == lesson.id + 1 }) {
                        Button("Next: \(next.title)") { current.v = next.id; answer.v = nil }.buttonStyle(PillStyle(prominent: true))
                    }
                    Button("Close") { s.sheet = nil }.buttonStyle(PillStyle()).keyboardShortcut(.cancelAction)
                }
            }
            .card(16)
        }
        .padding(16)
        .frame(width: 1080, height: 720)
    }

    @ViewBuilder
    func quiz(_ l: Lesson) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionTitle(text: "Quick check")
            Text(l.quiz.q).font(.system(size: 14, weight: .semibold))
            HStack(spacing: 8) {
                ForEach(Array(l.quiz.options.enumerated()), id: \.offset) { i, o in
                    let picked = answer.v == i
                    let right = i == l.quiz.answer
                    Button {
                        answer.v = i
                        if right {
                            var d = Lessons.done
                            d.insert(l.id)
                            Lessons.done = d
                            done.v = d
                        }
                    } label: {
                        Text(o).font(.system(size: 12.5, weight: .medium))
                            .padding(.horizontal, 12)
                            .frame(minHeight: 30)
                            .foregroundStyle(picked ? Color.white : T.ink)
                            .background(picked ? (right ? T.green : T.red) : Color.primary.opacity(0.07), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
            if let a = answer.v {
                HStack(spacing: 6) {
                    Image(systemName: a == l.quiz.answer ? "checkmark.circle.fill" : "arrow.counterclockwise.circle.fill")
                        .foregroundStyle(a == l.quiz.answer ? T.green : T.orange)
                    Text(a == l.quiz.answer ? "Right! \(l.quiz.why)" : "Not quite – try again.").font(.system(size: 12.5))
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.primary.opacity(0.04), in: RoundedRectangle(cornerRadius: 12))
    }
}

struct NewDiagramSheet: View {
    @ObservedObject var s: Store
    private let cols = [GridItem(.adaptive(minimum: 200), spacing: 12)]
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SheetTitle(title: "New diagram", subtitle: "Start blank, or from an example you can change.")
            ScrollView {
                LazyVGrid(columns: cols, spacing: 12) {
                    ForEach(DiagramType.allCases) { t in TypeCard(s: s, t: t) }
                }
            }
            HStack {
                Spacer()
                Button("Cancel") { s.sheet = nil }.buttonStyle(PillStyle()).keyboardShortcut(.cancelAction)
            }
        }
        .padding(22)
        .frame(width: 900, height: 640)
        .onChange(of: s.project.diagrams.count) { _, _ in s.sheet = nil }
    }
}

struct ShortcutsSheet: View {
    @ObservedObject var s: Store
    let rows: [(String, String)] = [
        ("Place a shape", "Click it in the toolbox, then click the canvas (⌥-click keeps the tool)"),
        ("Connect", "Drag the blue dot of a shape onto another shape – or onto empty canvas to make a new one"),
        ("Message (sequence)", "Drag down a lifeline's dashed line to another lifeline"),
        ("Rename", "Return, F2, double-click, or just start typing"),
        ("Add attribute / operation", "⌥⇧A / ⌥⇧O, or double-click an empty compartment"),
        ("Next member while typing", "Return after typing a new attribute adds another"),
        ("Mind map", "Tab adds a child topic, Return adds a sibling"),
        ("Bend a line", "Select it and drag the line; double-click a bend point to remove it"),
        ("Move / nudge", "Drag, or the arrow keys (⇧ for 10 points)"),
        ("Select several", "⇧-click or drag a rectangle on empty canvas"),
        ("Duplicate", "⌘D"),
        ("Undo / Redo", "⌘Z / ⇧⌘Z"),
        ("Zoom", "⌘+ / ⌘− / ⌘0, ⌥⌘0 to fit, pinch or ⌘-scroll"),
        ("Pan", "Scroll, or hold Space and drag"),
        ("Quick add", "Double-click empty canvas"),
        ("Java code", "⇧⌘J  ·  Reverse engineer Java: ⌥⌘J"),
        ("Check the model", "⇧⌘K"),
    ]
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SheetTitle(title: "Shortcuts and gestures", subtitle: "Everything also works from the menus and right-click menus.")
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(rows, id: \.0) { r in
                        HStack(alignment: .top) {
                            Text(r.0).font(.system(size: 13, weight: .semibold)).frame(width: 200, alignment: .leading)
                            Text(r.1).font(.system(size: 13)).foregroundStyle(T.muted).fixedSize(horizontal: false, vertical: true)
                            Spacer()
                        }
                        .padding(.vertical, 7)
                        Divider()
                    }
                }
            }
            HStack {
                Spacer()
                Button("Done") { s.sheet = nil }.buttonStyle(PillStyle(prominent: true)).keyboardShortcut(.defaultAction)
            }
        }
        .padding(22)
        .frame(width: 720, height: 600)
    }
}
