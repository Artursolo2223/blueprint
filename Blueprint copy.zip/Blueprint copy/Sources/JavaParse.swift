import Foundation

/// Reads Java source and builds a class diagram (instant reverse)
final class JavaParser {
    struct TypeDecl {
        var name: String
        var kind: String
        var isAbstract = false
        var pkg = ""
        var extends: [String] = []
        var implements: [String] = []
        var fields: [Member] = []
        var fieldHasNew: Set<String> = []
        var methods: [Member] = []
        var literals: [String] = []
    }

    static let modifiers: Set<String> = ["public", "private", "protected", "static", "final", "abstract", "sealed", "strictfp", "default",
                                         "synchronized", "native", "transient", "volatile"]

    private var t: [String] = []
    private var i = 0
    private var pkg = ""
    private(set) var types: [TypeDecl] = []

    init(_ src: String) {
        t = JavaParser.stripAnnotations(JavaParser.tokens(src))
    }

    // MARK: tokens

    static func tokens(_ src: String) -> [String] {
        var out: [String] = []
        let c = Array(src)
        let n = c.count
        var i = 0
        while i < n {
            let ch = c[i]
            if ch.isWhitespace { i += 1; continue }
            if ch == "/" && i + 1 < n && c[i + 1] == "/" {
                while i < n && c[i] != "\n" { i += 1 }
                continue
            }
            if ch == "/" && i + 1 < n && c[i + 1] == "*" {
                i += 2
                while i + 1 < n && !(c[i] == "*" && c[i + 1] == "/") { i += 1 }
                i += 2
                continue
            }
            if ch == "\"" {
                if i + 2 < n && c[i + 1] == "\"" && c[i + 2] == "\"" {
                    i += 3
                    while i + 2 < n && !(c[i] == "\"" && c[i + 1] == "\"" && c[i + 2] == "\"") { i += 1 }
                    i += 3
                } else {
                    i += 1
                    while i < n && c[i] != "\"" && c[i] != "\n" { if c[i] == "\\" { i += 1 }; i += 1 }
                    i += 1
                }
                out.append("\"\"")
                continue
            }
            if ch == "'" {
                i += 1
                while i < n && c[i] != "'" && c[i] != "\n" { if c[i] == "\\" { i += 1 }; i += 1 }
                i += 1
                out.append("' '")
                continue
            }
            if ch.isLetter || ch == "_" || ch == "$" {
                var s = ""
                while i < n && (c[i].isLetter || c[i].isNumber || c[i] == "_" || c[i] == "$") { s.append(c[i]); i += 1 }
                out.append(s)
                continue
            }
            if ch.isNumber {
                var s = ""
                while i < n && (c[i].isLetter || c[i].isNumber || c[i] == "." || c[i] == "_") { s.append(c[i]); i += 1 }
                out.append(s)
                continue
            }
            out.append(String(ch))
            i += 1
        }
        return out
    }

    /// drops @Annotations(...) but keeps @interface
    static func stripAnnotations(_ t: [String]) -> [String] {
        var out: [String] = []
        var i = 0
        while i < t.count {
            if t[i] == "@" && i + 1 < t.count && t[i + 1] != "interface" {
                i += 2
                while i + 1 < t.count && t[i] == "." { i += 2 }
                if i < t.count && t[i] == "(" {
                    var depth = 0
                    repeat {
                        if t[i] == "(" { depth += 1 }
                        if t[i] == ")" { depth -= 1 }
                        i += 1
                    } while i < t.count && depth > 0
                }
                continue
            }
            out.append(t[i])
            i += 1
        }
        return out
    }

    static func isIdent(_ s: String) -> Bool {
        guard let f = s.first else { return false }
        return f.isLetter || f == "_" || f == "$"
    }

    /// "Map", "<", "String", ",", "List", "<", "Order", ">", ">" -> "Map<String, List<Order>>"
    static func join(_ toks: [String]) -> String {
        var s = ""
        for (k, tok) in toks.enumerated() {
            if tok == "," { s += ", " }
            else if tok == "extends" || tok == "super" { s += " \(tok) " }
            else if tok == "." && k + 1 < toks.count && isIdent(toks[k + 1]) && s.last.map({ $0.isLetter || $0.isNumber }) == true {
                // drop package prefixes: java.util.List -> List
                if let r = s.range(of: "[A-Za-z_$][A-Za-z0-9_$]*$", options: .regularExpression), s[r].first!.isLowercase { s.removeSubrange(r) } else { s += "." }
            } else { s += tok }
        }
        return s
    }

    // MARK: parsing

    func parse() -> [TypeDecl] {
        while i < t.count {
            if t[i] == "package" {
                i += 1
                var s = ""
                while i < t.count && t[i] != ";" { s += t[i]; i += 1 }
                pkg = s
                i += 1
                continue
            }
            if t[i] == "import" {
                while i < t.count && t[i] != ";" { i += 1 }
                i += 1
                continue
            }
            if tryType() { continue }
            i += 1
        }
        return types
    }

    private func skipBalanced(_ open: String, _ close: String) {
        guard i < t.count, t[i] == open else { return }
        var depth = 0
        repeat {
            if t[i] == open { depth += 1 }
            if t[i] == close { depth -= 1 }
            i += 1
        } while i < t.count && depth > 0
    }

    private func tryType() -> Bool {
        var j = i
        var mods: Set<String> = []
        while j < t.count && (JavaParser.modifiers.contains(t[j]) || t[j] == "non" || (t[j] == "-" && j > i)) { mods.insert(t[j]); j += 1 }
        guard j + 1 < t.count else { return false }
        var kind = t[j]
        if kind == "@" && t[j + 1] == "interface" { kind = "interface"; j += 1 }
        guard ["class", "interface", "enum", "record"].contains(kind), JavaParser.isIdent(t[j + 1]) else { return false }
        if j > 0 && t[j - 1] == "." { return false }
        var decl = TypeDecl(name: t[j + 1], kind: kind, isAbstract: mods.contains("abstract"), pkg: pkg)
        i = j + 2
        if i < t.count && t[i] == "<" { skipBalanced("<", ">") }
        if kind == "record" && i < t.count && t[i] == "(" {
            let start = i + 1
            skipBalanced("(", ")")
            for p in JavaParser.splitTop(Array(t[start..<(i - 1)])) where p.count >= 2 {
                decl.fields.append(Member(name: p.last!, type: JavaParser.join(Array(p.dropLast())), vis: .priv, isFinal: true))
            }
        }
        while i < t.count && t[i] != "{" && t[i] != ";" {
            if t[i] == "extends" { i += 1; decl.extends = readTypeList() }
            else if t[i] == "implements" { i += 1; decl.implements = readTypeList() }
            else { i += 1 }
        }
        if i < t.count && t[i] == "{" {
            i += 1
            parseBody(&decl)
        }
        types.append(decl)
        return true
    }

    private func readTypeList() -> [String] {
        var out: [String] = []
        var cur: [String] = []
        var depth = 0
        while i < t.count {
            let tok = t[i]
            if depth == 0 && (tok == "{" || tok == "implements" || tok == "extends" || tok == "permits" || tok == ";") { break }
            if tok == "<" { depth += 1 }
            if tok == ">" { depth -= 1 }
            if depth == 0 && tok == "," {
                if !cur.isEmpty { out.append(JavaParser.baseName(cur)) }
                cur = []
            } else { cur.append(tok) }
            i += 1
        }
        if !cur.isEmpty { out.append(JavaParser.baseName(cur)) }
        return out
    }

    /// last identifier before any generics: java.util.List<X> -> List
    static func baseName(_ toks: [String]) -> String {
        var last = ""
        for tok in toks {
            if tok == "<" { break }
            if isIdent(tok) { last = tok }
        }
        return last
    }

    static func splitTop(_ toks: [String]) -> [[String]] {
        var out: [[String]] = []
        var cur: [String] = []
        var depth = 0
        for tok in toks {
            if tok == "<" || tok == "(" || tok == "[" || tok == "{" { depth += 1 }
            if tok == ">" || tok == ")" || tok == "]" || tok == "}" { depth -= 1 }
            if tok == "," && depth == 0 { out.append(cur); cur = [] } else { cur.append(tok) }
        }
        if !cur.isEmpty { out.append(cur) }
        return out
    }

    private func parseBody(_ decl: inout TypeDecl) {
        if decl.kind == "enum" {
            while i < t.count && t[i] != ";" && t[i] != "}" {
                if JavaParser.isIdent(t[i]) {
                    decl.literals.append(t[i])
                    i += 1
                    if i < t.count && t[i] == "(" { skipBalanced("(", ")") }
                    if i < t.count && t[i] == "{" { skipBalanced("{", "}") }
                } else {
                    i += 1
                }
            }
            if i < t.count && t[i] == ";" { i += 1 }
        }
        while i < t.count && t[i] != "}" {
            if t[i] == ";" { i += 1; continue }
            let save = i
            if tryType() { continue }
            i = save
            if t[i] == "{" { skipBalanced("{", "}"); continue }
            if t[i] == "static" && i + 1 < t.count && t[i + 1] == "{" { i += 1; skipBalanced("{", "}"); continue }
            var toks: [String] = []
            var paren = 0
            var sawEq = false
            var body = false
            while i < t.count {
                let tok = t[i]
                if tok == "(" { paren += 1 }
                if tok == ")" { paren -= 1 }
                if paren == 0 && tok == "=" && !sawEq && !toks.contains("(") { sawEq = true }
                if paren == 0 && tok == ";" { i += 1; break }
                if paren == 0 && tok == "{" {
                    if sawEq { skipBalanced("{", "}"); toks.append("{}"); continue }
                    skipBalanced("{", "}")
                    body = true
                    break
                }
                if paren == 0 && tok == "}" { break }
                toks.append(tok)
                i += 1
            }
            member(toks, body: body, into: &decl)
        }
        if i < t.count && t[i] == "}" { i += 1 }
    }

    private func member(_ toks: [String], body: Bool, into decl: inout TypeDecl) {
        var k = 0
        var mods: Set<String> = []
        while k < toks.count && JavaParser.modifiers.contains(toks[k]) { mods.insert(toks[k]); k += 1 }
        if k < toks.count && toks[k] == "<" {
            var depth = 0
            repeat {
                if toks[k] == "<" { depth += 1 }
                if toks[k] == ">" { depth -= 1 }
                k += 1
            } while k < toks.count && depth > 0
        }
        guard k < toks.count else { return }
        let iface = decl.kind == "interface"
        let vis: Visibility = mods.contains("public") ? .pub : mods.contains("private") ? .priv : mods.contains("protected") ? .prot : (iface ? .pub : .pkg)

        // the first "(" that isn't inside generics or an initializer
        var paren: Int? = nil
        var depth = 0
        for j in k..<toks.count {
            if toks[j] == "<" { depth += 1 }
            if toks[j] == ">" { depth -= 1 }
            if toks[j] == "=" { break }
            if toks[j] == "(" && depth == 0 { paren = j; break }
        }
        if let p = paren, p >= 1, p - 1 >= k {
            let name = toks[p - 1]
            let ret = Array(toks[k..<(p - 1)])
            let isCtor = ret.isEmpty && name == decl.name
            if ret.isEmpty && !isCtor { return }
            var close = p
            var d = 0
            for j in p..<toks.count {
                if toks[j] == "(" { d += 1 }
                if toks[j] == ")" { d -= 1; if d == 0 { close = j; break } }
            }
            let inner = close > p + 1 ? Array(toks[(p + 1)..<close]) : []
            let params = JavaParser.splitTop(inner).compactMap { raw -> String? in
                let p = raw.filter { $0 != "final" }
                guard let pn = p.last, p.count >= 2 else { return nil }
                return "\(pn): \(JavaParser.join(Array(p.dropLast())))"
            }
            var m = Member(name: name, type: isCtor ? "" : JavaParser.join(ret), vis: vis)
            m.isStatic = mods.contains("static")
            m.isFinal = mods.contains("final")
            m.isAbstract = mods.contains("abstract") || (iface && !body && !mods.contains("static") && !mods.contains("default"))
            m.params = params.joined(separator: ", ")
            decl.methods.append(m)
            return
        }

        // fields: Type a = 1, b;
        var j = k
        var typeToks: [String] = []
        guard j < toks.count, JavaParser.isIdent(toks[j]) else { return }
        typeToks.append(toks[j]); j += 1
        while j + 1 < toks.count && toks[j] == "." && JavaParser.isIdent(toks[j + 1]) { typeToks += [".", toks[j + 1]]; j += 2 }
        if j < toks.count && toks[j] == "<" {
            var dd = 0
            repeat {
                if toks[j] == "<" { dd += 1 }
                if toks[j] == ">" { dd -= 1 }
                typeToks.append(toks[j])
                j += 1
            } while j < toks.count && dd > 0
        }
        while j + 1 < toks.count && toks[j] == "[" && toks[j + 1] == "]" { typeToks += ["[", "]"]; j += 2 }
        let type = JavaParser.join(typeToks)
        for declr in JavaParser.splitTop(Array(toks[j...])) {
            guard let n = declr.first, JavaParser.isIdent(n) else { continue }
            var extra = ""
            var q = 1
            while q + 1 < declr.count && declr[q] == "[" && declr[q + 1] == "]" { extra += "[]"; q += 2 }
            var value = ""
            if q < declr.count && declr[q] == "=" {
                value = JavaParser.join(Array(declr[(q + 1)...])).replacingOccurrences(of: "newArrayList", with: "new ArrayList")
                if declr.contains("new") { decl.fieldHasNew.insert(n) }
                value = declr[(q + 1)...].joined(separator: " ")
                    .replacingOccurrences(of: " ( ", with: "(").replacingOccurrences(of: " )", with: ")").replacingOccurrences(of: "( )", with: "()")
                    .replacingOccurrences(of: " < > ", with: "<>").replacingOccurrences(of: " . ", with: ".").replacingOccurrences(of: " ,", with: ",")
                if value.count > 40 { value = String(value.prefix(37)) + "…" }
            }
            var m = Member(name: n, type: type + extra, vis: vis)
            m.isStatic = mods.contains("static") || iface
            m.isFinal = mods.contains("final") || iface
            m.value = value
            decl.fields.append(m)
        }
    }

    // MARK: building the diagram

    static let collections: Set<String> = ["List", "ArrayList", "LinkedList", "Set", "HashSet", "TreeSet", "LinkedHashSet", "Collection", "Iterable",
                                           "Queue", "Deque", "ArrayDeque", "Map", "HashMap", "TreeMap", "LinkedHashMap", "Stream", "Vector", "Stack"]

    /// which known class a type points at, and whether it is a collection of them
    static func target(_ type: String, _ known: Set<String>) -> (String, Bool)? {
        let words = type.split { !($0.isLetter || $0.isNumber || $0 == "_" || $0 == "$") }.map(String.init)
        guard let base = words.first else { return nil }
        if known.contains(base) { return (base, type.contains("[]")) }
        if collections.contains(base) || base == "Optional" {
            for w in words.dropFirst().reversed() where known.contains(w) { return (w, base != "Optional") }
        }
        return nil
    }

    static func diagram(_ types: [TypeDecl], name: String) -> Diagram {
        var d = Diagram(name: name, type: .classDiagram)
        var ids: [String: UUID] = [:]
        var unique: [TypeDecl] = []
        for t in types where ids[t.name] == nil {
            ids[t.name] = UUID()
            unique.append(t)
        }
        let known = Set(ids.keys)
        var edges: [Edge] = []
        var linked: Set<String> = []
        func link(_ a: String, _ b: String) -> Bool { linked.insert(a < b ? "\(a)|\(b)" : "\(b)|\(a)").inserted }

        for t in unique {
            let kind: NodeKind = t.kind == "interface" ? .interface : t.kind == "enum" ? .enumeration : .klass
            var n = Node(id: ids[t.name]!, kind: kind, frame: CGRect(x: 0, y: 0, width: 170, height: 80), name: t.name)
            n.isAbstract = t.isAbstract && kind == .klass
            if t.kind == "record" { n.stereotype = "record" }
            if kind == .enumeration { n.attrs = t.literals.map { Member(name: $0, vis: .pub) } }
            for f in t.fields {
                if let (target, many) = target(f.type, known), target != t.name || many {
                    let comp = t.fieldHasNew.contains(f.name) && many
                    var e = Edge(kind: comp ? .composition : .directed, from: n.id, to: ids[target]!)
                    e.toRole = f.name
                    e.toMult = many ? "0..*" : "1"
                    edges.append(e)
                    _ = link(t.name, target)
                    continue
                }
                if kind != .enumeration { n.attrs.append(f) }
            }
            n.ops = t.methods
            Store.fit(&n)
            d.nodes.append(n)
        }
        for t in unique {
            guard let me = ids[t.name] else { continue }
            let iface = t.kind == "interface"
            for s in t.extends where known.contains(s) {
                edges.append(Edge(kind: .generalization, from: me, to: ids[s]!))
                _ = link(t.name, s)
            }
            for s in t.implements where known.contains(s) {
                edges.append(Edge(kind: iface ? .generalization : .realization, from: me, to: ids[s]!))
                _ = link(t.name, s)
            }
        }
        // classes used in method signatures only: dependencies
        for t in unique {
            for m in t.methods {
                for type in [m.type] + UMLText.splitTop(m.params).map({ $0.components(separatedBy: ":").last ?? "" }) {
                    if let (target, _) = target(type.trimmed, known), target != t.name, link(t.name, target) {
                        edges.append(Edge(kind: .dependency, from: ids[t.name]!, to: ids[target]!))
                    }
                }
            }
        }
        d.edges = edges
        Layout.layered(&d, horizontal: false)
        return d
    }

    static func diagram(from source: String, name: String) -> (Diagram, Int) {
        let types = JavaParser(source).parse()
        return (diagram(types, name: name), types.count)
    }
}
