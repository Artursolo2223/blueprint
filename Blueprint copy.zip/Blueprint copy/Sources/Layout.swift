import AppKit

enum LayoutStyle: String, CaseIterable {
    case topDown, leftRight, grid

    var title: String {
        switch self {
        case .topDown: return "Hierarchical (top to bottom)"
        case .leftRight: return "Hierarchical (left to right)"
        case .grid: return "Grid"
        }
    }

    static func preferred(_ t: DiagramType) -> LayoutStyle {
        switch t {
        case .useCase, .bpmn, .erd, .dfd, .deployment, .component: return .leftRight
        default: return .topDown
        }
    }
}

enum Layout {
    static func apply(_ d: inout Diagram, _ s: LayoutStyle) {
        if s != .grid {
            if d.type == .sequence { sequence(&d); return }
            if d.type == .mindMap { mind(&d); return }
        }
        switch s {
        case .topDown: layered(&d, horizontal: false)
        case .leftRight: layered(&d, horizontal: true)
        case .grid: grid(&d)
        }
    }

    /// who sits inside which container before things move
    private static func members(_ d: Diagram) -> [(UUID, [UUID])] {
        d.nodes.filter { $0.kind.info.container }
            .sorted { $0.frame.width * $0.frame.height < $1.frame.width * $1.frame.height }
            .map { c in (c.id, d.nodes.filter { $0.id != c.id && !$0.kind.info.container && c.frame.contains($0.frame) }.map(\.id)) }
    }

    /// containers wrap what used to be inside them; empty ones go to the right
    private static func refit(_ d: inout Diagram, _ groups: [(UUID, [UUID])]) {
        var right = (d.nodes.filter { !$0.kind.info.container }.map(\.frame.maxX).max() ?? 0) + 60
        for (cid, ids) in groups {
            guard let ci = d.index(cid) else { continue }
            let inner = d.nodes.filter { ids.contains($0.id) }.map(\.frame)
            if inner.isEmpty {
                d.nodes[ci].frame.origin = CGPoint(x: right, y: 60)
                right += d.nodes[ci].frame.width + 40
                continue
            }
            var b = inner.reduce(CGRect.null) { $0.union($1) }
            let k = d.nodes[ci].kind
            let top: CGFloat = (k == .lane && d.nodes[ci].frame.height >= d.nodes[ci].frame.width) ? 44 : (k == .package || k == .boundary || k == .fragment ? 40 : 30)
            let left: CGFloat = (k == .pool || (k == .lane && d.nodes[ci].frame.width > d.nodes[ci].frame.height)) ? 50 : 30
            b = CGRect(x: b.minX - left, y: b.minY - top, width: b.width + left + 30, height: b.height + top + 30)
            d.nodes[ci].frame = b
        }
    }

    static func layered(_ d: inout Diagram, horizontal: Bool) {
        let groups = members(d)
        let free = d.nodes.filter { !$0.kind.info.container && !$0.kind.isNoteLike }
        guard !free.isEmpty else { return }
        var idx: [UUID: Int] = [:]
        for (i, n) in free.enumerated() { idx[n.id] = i }
        let n = free.count
        var out = Array(repeating: [Int](), count: n)
        for e in d.edges where e.kind != .anchor && e.kind != .bpmnAssoc {
            guard var a = idx[e.from], var b = idx[e.to], a != b else { continue }
            // parents above children
            if e.kind == .generalization || e.kind == .realization || e.kind == .extend { swap(&a, &b) }
            if !out[a].contains(b) { out[a].append(b) }
        }
        // drop edges that close a cycle
        var state = Array(repeating: 0, count: n)
        var dag = Array(repeating: [Int](), count: n)
        func dfs(_ v: Int) {
            state[v] = 1
            for w in out[v] where state[w] != 1 {
                dag[v].append(w)
                if state[w] == 0 { dfs(w) }
            }
            state[v] = 2
        }
        let startOrder = (0..<n).sorted { horizontal ? free[$0].frame.minX < free[$1].frame.minX : free[$0].frame.minY < free[$1].frame.minY }
        for v in startOrder where state[v] == 0 { dfs(v) }

        var preds = Array(repeating: [Int](), count: n)
        for v in 0..<n { for w in dag[v] { preds[w].append(v) } }
        var indeg = preds.map(\.count)
        var layer = Array(repeating: 0, count: n)
        var queue = startOrder.filter { indeg[$0] == 0 }
        var topo: [Int] = []
        while !queue.isEmpty {
            let v = queue.removeFirst()
            topo.append(v)
            for w in dag[v] {
                layer[w] = max(layer[w], layer[v] + 1)
                indeg[w] -= 1
                if indeg[w] == 0 { queue.append(w) }
            }
        }
        // sources sit right above their first child
        for v in topo.reversed() where preds[v].isEmpty && !dag[v].isEmpty {
            layer[v] = max(0, (dag[v].map { layer[$0] }.min() ?? 1) - 1)
        }
        let isolated = Set((0..<n).filter { preds[$0].isEmpty && dag[$0].isEmpty })
        let connected = (0..<n).filter { !isolated.contains($0) }
        let maxL = connected.map { layer[$0] }.max() ?? 0
        var layers = Array(repeating: [Int](), count: maxL + 1)
        for v in connected { layers[layer[v]].append(v) }
        for i in layers.indices {
            layers[i].sort { horizontal ? free[$0].frame.midY < free[$1].frame.midY : free[$0].frame.midX < free[$1].frame.midX }
        }
        var pos = Array(repeating: 0.0, count: n)
        for l in layers { for (i, v) in l.enumerated() { pos[v] = Double(i) } }
        if layers.count > 1 {
            for sweep in 0..<10 {
                let down = sweep % 2 == 0
                let range = down ? Array(1..<layers.count) : Array((0..<(layers.count - 1)).reversed())
                for li in range {
                    var bary: [Int: Double] = [:]
                    for v in layers[li] {
                        let nb = down ? preds[v] : dag[v]
                        bary[v] = nb.isEmpty ? pos[v] : nb.map { pos[$0] }.reduce(0, +) / Double(nb.count)
                    }
                    layers[li].sort { bary[$0]! < bary[$1]! }
                    for (i, v) in layers[li].enumerated() { pos[v] = Double(i) }
                }
            }
        }

        let gapMain: CGFloat = horizontal ? 110 : 80
        let gapCross: CGFloat = horizontal ? 40 : 50
        func mainSize(_ v: Int) -> CGFloat { horizontal ? free[v].frame.width : free[v].frame.height }
        func crossSize(_ v: Int) -> CGFloat { horizontal ? free[v].frame.height : free[v].frame.width }
        let layerMain = layers.map { $0.map(mainSize).max() ?? 0 }
        let layerCross = layers.map { l in l.map(crossSize).reduce(0, +) + gapCross * CGFloat(max(0, l.count - 1)) }
        let widest = layerCross.max() ?? 0
        var frames: [Int: CGRect] = [:]
        var m: CGFloat = 80
        for (li, l) in layers.enumerated() {
            var c: CGFloat = 80 + (widest - layerCross[li]) / 2
            for v in l {
                let f = free[v].frame
                let off = (layerMain[li] - mainSize(v)) / 2
                frames[v] = horizontal ? CGRect(x: m + off, y: c, width: f.width, height: f.height)
                                       : CGRect(x: c, y: m + off, width: f.width, height: f.height)
                c += crossSize(v) + gapCross
            }
            m += layerMain[li] + gapMain
        }
        // shapes without connectors go in rows after the rest
        if !isolated.isEmpty {
            let list = isolated.sorted { free[$0].name < free[$1].name }
            var x: CGFloat = 80
            var y: CGFloat = layers.isEmpty || connected.isEmpty ? 80 : (horizontal ? 80 + widest + 80 : m)
            var rowH: CGFloat = 0
            let limit = max(widest, 900)
            for v in list {
                let f = free[v].frame
                if x + f.width > 80 + limit && x > 80 { x = 80; y += rowH + 50; rowH = 0 }
                frames[v] = CGRect(x: x, y: y, width: f.width, height: f.height)
                x += f.width + 50
                rowH = max(rowH, f.height)
            }
        }
        for (v, f) in frames {
            if let i = d.index(free[v].id) { d.nodes[i].frame = f }
        }
        for i in d.edges.indices { d.edges[i].points = [] }
        placeNotes(&d)
        refit(&d, groups)
        normalize(&d)
    }

    /// notes go next to what they are attached to
    private static func placeNotes(_ d: inout Diagram) {
        var right = (d.nodes.filter { !$0.kind.isNoteLike && !$0.kind.info.container }.map(\.frame.maxX).max() ?? 0) + 60
        var freeY: CGFloat = 80
        for i in d.nodes.indices where d.nodes[i].kind.isNoteLike {
            let id = d.nodes[i].id
            if let e = d.edges.first(where: { ($0.from == id || $0.to == id) && ($0.kind == .anchor || $0.kind == .bpmnAssoc) }),
               let other = d.node(e.from == id ? e.to : e.from) {
                d.nodes[i].frame.origin = CGPoint(x: other.frame.maxX + 50, y: other.frame.minY - d.nodes[i].frame.height - 10)
                if d.nodes[i].frame.minY < 10 { d.nodes[i].frame.origin.y = other.frame.maxY + 20 }
            } else {
                d.nodes[i].frame.origin = CGPoint(x: right, y: freeY)
                freeY += d.nodes[i].frame.height + 30
            }
            right = max(right, d.nodes[i].frame.maxX + 40)
        }
    }

    static func normalize(_ d: inout Diagram) {
        let b = d.nodes.map(\.frame).reduce(CGRect.null) { $0.union($1) }
        guard !b.isNull else { return }
        let dx = 60 - b.minX, dy = 60 - b.minY
        for i in d.nodes.indices { d.nodes[i].frame = d.nodes[i].frame.offsetBy(dx: dx, dy: dy) }
        for i in d.edges.indices {
            d.edges[i].points = d.edges[i].points.map { CGPoint(x: $0.x + dx, y: $0.y + dy) }
            if let y = d.edges[i].y { d.edges[i].y = y + Double(dy) }
        }
    }

    static func grid(_ d: inout Diagram) {
        let items = d.nodes.filter { !$0.kind.info.container }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        guard !items.isEmpty else { return }
        let cols = Int(ceil(sqrt(Double(items.count))))
        let cw = (items.map(\.frame.width).max() ?? 100) + 50
        var rowH: [Int: CGFloat] = [:]
        for (i, n) in items.enumerated() { rowH[i / cols] = max(rowH[i / cols] ?? 0, n.frame.height) }
        var y: CGFloat = 60
        var rowY: [Int: CGFloat] = [:]
        for r in 0...((items.count - 1) / cols) { rowY[r] = y; y += (rowH[r] ?? 0) + 50 }
        for (i, n) in items.enumerated() {
            guard let ni = d.index(n.id) else { continue }
            d.nodes[ni].frame.origin = CGPoint(x: 60 + CGFloat(i % cols) * cw, y: rowY[i / cols] ?? 60)
        }
        for i in d.edges.indices { d.edges[i].points = [] }
    }

    static func sequence(_ d: inout Diagram) {
        let lifelines = d.nodes.filter { $0.kind.isLifeline }.sorted { $0.frame.minX < $1.frame.minX }
        guard !lifelines.isEmpty else { return }
        let top: CGFloat = 40
        let headerMax = lifelines.map { Geo.header($0).height }.max() ?? 40
        let msgs = d.edges.filter { $0.kind.isMessage }.sorted { ($0.y ?? 0) < ($1.y ?? 0) }
        var y = top + headerMax + 36
        var ys: [UUID: Double] = [:]
        for m in msgs {
            ys[m.id] = Double(y)
            y += m.from == m.to ? 56 : 42
        }
        let height = y + 40 - top
        // room for the longest label between neighbours
        let f = F(size: 11)
        var x: CGFloat = 50
        var placed: [UUID: CGRect] = [:]
        for (i, l) in lifelines.enumerated() {
            let w = max(l.frame.width, TextM.width(l.name + " : " + l.prop("classifier"), F(size: 12, bold: true)) + 24)
            placed[l.id] = CGRect(x: x, y: top, width: w, height: height)
            if i + 1 < lifelines.count {
                let nxt = lifelines[i + 1]
                let label = msgs.filter { Set([$0.from, $0.to]) == Set([l.id, nxt.id]) || ($0.from == l.id && $0.to == l.id) }
                    .map { TextM.width($0.name, f) + 40 }.max() ?? 0
                let nw = max(nxt.frame.width, 90)
                x += w + max(60, label - (w + nw) / 2 + 20)
            }
        }
        for (id, r) in placed {
            if let i = d.index(id) { d.nodes[i].frame = r }
        }
        for i in d.edges.indices {
            if let y = ys[d.edges[i].id] { d.edges[i].y = y }
            if d.edges[i].kind == .create, let yy = ys[d.edges[i].id], let ti = d.index(d.edges[i].to) {
                let bottom = d.nodes[ti].frame.maxY
                d.nodes[ti].frame.origin.y = CGFloat(yy) - Geo.header(d.nodes[ti]).height / 2
                d.nodes[ti].frame.size.height = bottom - d.nodes[ti].frame.minY
            }
        }
    }

    static func mind(_ d: inout Diagram) {
        guard let root = d.nodes.first(where: { $0.kind == .central }) ?? d.nodes.first else { return }
        var kids: [UUID: [UUID]] = [:]
        var seen: Set<UUID> = [root.id]
        var queue = [root.id]
        while !queue.isEmpty {
            let v = queue.removeFirst()
            for e in d.edges where e.kind == .branch && (e.from == v || e.to == v) {
                let w = e.from == v ? e.to : e.from
                if !seen.contains(w) {
                    seen.insert(w)
                    kids[v, default: []].append(w)
                    queue.append(w)
                }
            }
        }
        var frames: [UUID: CGRect] = [:]
        for n in d.nodes { frames[n.id] = n.frame }
        for (k, v) in kids { kids[k] = v.sorted { frames[$0]!.minY < frames[$1]!.minY } }
        let gap: CGFloat = 14
        var heights: [UUID: CGFloat] = [:]
        func height(_ v: UUID) -> CGFloat {
            let c = kids[v] ?? []
            let own = frames[v]!.height
            let sum = c.map(height).reduce(0, +) + gap * CGFloat(max(0, c.count - 1))
            let h = max(own, sum)
            heights[v] = h
            return h
        }
        func place(_ v: UUID, x: CGFloat, yc: CGFloat, dir: CGFloat) {
            var f = frames[v]!
            f.origin = CGPoint(x: dir > 0 ? x : x - f.width, y: yc - f.height / 2)
            frames[v] = f
            let c = kids[v] ?? []
            let total = c.map { heights[$0]! }.reduce(0, +) + gap * CGFloat(max(0, c.count - 1))
            var y = yc - total / 2
            for k in c {
                let h = heights[k]!
                place(k, x: dir > 0 ? f.maxX + 60 : f.minX - 60, yc: y + h / 2, dir: dir)
                y += h + gap
            }
        }
        let first = kids[root.id] ?? []
        var right: [UUID] = [], left: [UUID] = []
        let onRight = first.filter { frames[$0]!.midX >= root.frame.midX }
        if onRight.count == first.count || onRight.isEmpty {
            for (i, k) in first.enumerated() { if i < (first.count + 1) / 2 { right.append(k) } else { left.append(k) } }
        } else {
            right = onRight
            left = first.filter { !onRight.contains($0) }
        }
        for k in first { _ = height(k) }
        let rc = root.frame.center
        for (side, dir) in [(right, CGFloat(1)), (left, CGFloat(-1))] {
            let total = side.map { heights[$0]! }.reduce(0, +) + gap * 2 * CGFloat(max(0, side.count - 1))
            var y = rc.y - total / 2
            for k in side {
                let h = heights[k]!
                place(k, x: dir > 0 ? root.frame.maxX + 70 : root.frame.minX - 70, yc: y + h / 2, dir: dir)
                y += h + gap * 2
            }
        }
        for i in d.nodes.indices { if let f = frames[d.nodes[i].id] { d.nodes[i].frame = f } }
        for i in d.edges.indices { d.edges[i].points = [] }
        normalize(&d)
    }
}
