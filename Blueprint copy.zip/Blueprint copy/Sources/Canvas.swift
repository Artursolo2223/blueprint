import AppKit
import Combine
import SwiftUI

/// painter that draws nothing (hit testing needs a renderer but no pixels)
final class NullPainter: Painter {
    func fill(_ path: CGPath, _ c: NSColor) {}
    func stroke(_ path: CGPath, _ c: NSColor, _ w: CGFloat, dash: [CGFloat]) {}
    func text(_ s: String, _ p: CGPoint, _ f: F, _ c: NSColor, angle: CGFloat) {}
}

/// forwards shapes but skips text (tiny overview)
final class ShapesOnlyPainter: Painter {
    let base: Painter
    init(_ b: Painter) { base = b }
    func fill(_ path: CGPath, _ c: NSColor) { base.fill(path, c) }
    func stroke(_ path: CGPath, _ c: NSColor, _ w: CGFloat, dash: [CGFloat]) { base.stroke(path, c, w, dash: dash) }
    func text(_ s: String, _ p: CGPoint, _ f: F, _ c: NSColor, angle: CGFloat) {}
}

/// menu item that runs a closure
final class ActionItem: NSMenuItem {
    let handler: () -> Void
    init(_ title: String, key: String = "", image: NSImage? = nil, on: Bool = false, enabled: Bool = true, _ h: @escaping () -> Void) {
        handler = h
        super.init(title: title, action: #selector(run), keyEquivalent: key)
        target = self
        self.image = image
        state = on ? .on : .off
        isEnabled = enabled
    }
    required init(coder: NSCoder) { fatalError() }
    @objc func run() { handler() }
}

extension NSMenu {
    func sub(_ title: String, _ items: [NSMenuItem]) {
        let m = NSMenu(title: title)
        m.autoenablesItems = false
        items.forEach { m.addItem($0) }
        let it = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        it.submenu = m
        addItem(it)
    }
    func header(_ title: String) {
        let it = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        it.isEnabled = false
        addItem(it)
    }
}

final class EditorField: NSTextField {
    var multiline = false
}

final class CanvasView: NSView, NSTextFieldDelegate, NSMenuItemValidation {
    let store: Store
    private var subs: Set<AnyCancellable> = []
    private var pending = false

    enum Drag {
        case none
        case move(start: CGPoint, base: Diagram, moved: Bool, primary: UUID)
        case resize(id: UUID, handle: Int, start: CGPoint, orig: CGRect, base: Diagram)
        case marquee(start: CGPoint, now: CGPoint, base: Set<UUID>)
        case connect(from: UUID, kind: EdgeKind?, start: CGPoint, now: CGPoint, y: CGFloat?)
        case message(id: UUID, start: CGPoint, orig: Double, base: Diagram)
        case bend(edge: UUID, index: Int, base: Diagram)
        case pan(start: CGPoint, origin: CGPoint)
    }
    private var drag: Drag = .none
    private(set) var live: Diagram?
    private var guides: [(Bool, CGFloat)] = []
    private var hover: UUID?
    private var dropTarget: UUID?
    private var spaceDown = false

    enum EditTarget { case name(UUID), member(UUID, Bool, Int, Bool), edgeName(UUID) }
    private(set) var editor: EditorField?
    private var editTarget: EditTarget?

    init(store: Store) {
        self.store = store
        super.init(frame: NSRect(x: 0, y: 0, width: 2400, height: 1600))
        registerForDraggedTypes([.string])
        store.objectWillChange.sink { [weak self] _ in self?.refreshSoon() }.store(in: &subs)
        addTrackingArea(NSTrackingArea(rect: .zero, options: [.mouseMoved, .activeInKeyWindow, .inVisibleRect, .mouseEnteredAndExited], owner: self))
    }
    required init?(coder: NSCoder) { fatalError() }

    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { true }
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    var dia: Diagram? { live ?? store.diagram }
    var mag: CGFloat { enclosingScrollView?.magnification ?? 1 }
    var pal: Palette {
        switch store.canvasTheme {
        case 1: return .light
        case 2: return .dark
        default: return effectiveAppearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua ? .dark : .light
        }
    }

    func refreshSoon() {
        guard !pending else { return }
        pending = true
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.pending = false
            self.needsDisplay = true
            self.updateSize()
            self.enclosingScrollView?.backgroundColor = self.pal.paper
            self.store.overview?.needsDisplay = true
        }
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        enclosingScrollView?.backgroundColor = pal.paper
        needsDisplay = true
    }

    @objc func clipChanged() {
        updateSize()
        store.overview?.needsDisplay = true
    }

    @objc func magnified() {
        store.zoom = mag
        updateSize()
    }

    func updateSize() {
        guard let sv = enclosingScrollView else { return }
        let vis = sv.contentView.bounds.size
        let b = dia?.contentBounds ?? .null
        let w = max(b.isNull ? 0 : b.maxX + 900, vis.width, 1400)
        let h = max(b.isNull ? 0 : b.maxY + 900, vis.height, 1000)
        if abs(frame.width - w) > 1 || abs(frame.height - h) > 1 { setFrameSize(NSSize(width: w, height: h)) }
    }

    // MARK: drawing

    override func draw(_ dirty: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext else { return }
        let pal = self.pal
        ctx.setFillColor(pal.paper.cgColor)
        ctx.fill(dirty)
        guard let d = dia else { return }
        if store.showGrid { drawGrid(ctx, dirty, pal) }
        let painter = CGPainter(ctx)
        let r = Renderer(d, pal, painter)
        // shapes being hovered get a soft outline underneath
        if let h = hover, !store.selection.contains(h), let n = d.node(h), drag.isIdle {
            painter.stroke(Renderer.rrect(n.frame.insetBy(dx: -3, dy: -3), 4), pal.accent.withAlphaComponent(0.35), 2 / mag)
        }
        r.drawAll()
        drawSelection(d, r, painter, pal)
        drawOverlay(d, painter, pal)
    }

    private func drawGrid(_ ctx: CGContext, _ r: NSRect, _ pal: Palette) {
        let minor: CGFloat = mag < 0.5 ? 50 : 20
        let major: CGFloat = 100
        ctx.setLineWidth(1 / mag)
        for (step, col) in [(minor, pal.grid), (major, pal.gridMajor)] {
            ctx.setStrokeColor(col.cgColor)
            var x = floor(r.minX / step) * step
            while x <= r.maxX {
                ctx.move(to: CGPoint(x: x, y: r.minY)); ctx.addLine(to: CGPoint(x: x, y: r.maxY))
                x += step
            }
            var y = floor(r.minY / step) * step
            while y <= r.maxY {
                ctx.move(to: CGPoint(x: r.minX, y: y)); ctx.addLine(to: CGPoint(x: r.maxX, y: y))
                y += step
            }
            ctx.strokePath()
        }
    }

    private func handleSize() -> CGFloat { 7 / mag }

    static func handlePoints(_ r: CGRect) -> [CGPoint] {
        [CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.midX, y: r.minY), CGPoint(x: r.maxX, y: r.minY), CGPoint(x: r.maxX, y: r.midY),
         CGPoint(x: r.maxX, y: r.maxY), CGPoint(x: r.midX, y: r.maxY), CGPoint(x: r.minX, y: r.maxY), CGPoint(x: r.minX, y: r.midY)]
    }

    /// which resize handles a shape offers
    private func allowedHandles(_ n: Node) -> [Int] {
        if n.kind.autoSized { return [3, 7] }
        return Array(0..<8)
    }

    private func drawSelection(_ d: Diagram, _ r: Renderer, _ p: CGPainter, _ pal: Palette) {
        let acc = pal.accent
        for e in d.edges where store.selection.contains(e.id) {
            guard let rt = r.route(e) else { continue }
            p.stroke(rt.cgPath, acc.withAlphaComponent(0.25), 6 / mag)
            r.drawEdge(e, highlight: acc)
            let hs = handleSize()
            for q in [rt.start, rt.end] {
                p.fill(CGPath(ellipseIn: CGRect(x: q.x - hs / 2, y: q.y - hs / 2, width: hs, height: hs), transform: nil), acc)
            }
            for q in e.points {
                let rr = CGRect(x: q.x - hs / 2, y: q.y - hs / 2, width: hs, height: hs)
                p.fill(CGPath(rect: rr, transform: nil), .white)
                p.stroke(CGPath(rect: rr, transform: nil), acc, 1.2 / mag)
            }
        }
        let sel = d.nodes.filter { store.selection.contains($0.id) }
        for n in sel {
            p.stroke(CGPath(rect: selectionFrame(n), transform: nil), acc, 1.3 / mag, dash: sel.count > 1 ? [] : [4 / mag, 3 / mag])
        }
        if sel.count == 1, let n = sel.first, drag.isIdle || drag.isResize {
            let hs = handleSize()
            let pts = CanvasView.handlePoints(n.frame)
            for i in allowedHandles(n) {
                let q = pts[i]
                let rr = CGRect(x: q.x - hs / 2, y: q.y - hs / 2, width: hs, height: hs)
                p.fill(CGPath(rect: rr, transform: nil), .white)
                p.stroke(CGPath(rect: rr, transform: nil), acc, 1.2 / mag)
            }
        }
        // the round connector handle (drag it onto another shape, or onto empty canvas to create one)
        if drag.isIdle, store.tool == nil {
            for n in handleOwners(d) { drawConnectorHandle(n, p, pal) }
        }
    }

    private func selectionFrame(_ n: Node) -> CGRect {
        var f = n.frame
        if n.kind == .actor { f = f.insetBy(dx: -6, dy: 0) }
        return f.insetBy(dx: -3 / mag, dy: -3 / mag)
    }

    private func handleOwners(_ d: Diagram) -> [Node] {
        var out: [Node] = []
        if store.selection.count == 1, let id = store.selection.first, let n = d.node(id) { out.append(n) }
        if let h = hover, !out.contains(where: { $0.id == h }), let n = d.node(h) { out.append(n) }
        return out.filter { $0.kind != .text }
    }

    func connectorHandleCenter(_ n: Node) -> CGPoint {
        let r = n.kind.isLifeline ? Geo.header(n) : Geo.clipRect(n)
        return CGPoint(x: r.maxX + 13 / mag, y: r.minY - 1 / mag)
    }

    private func drawConnectorHandle(_ n: Node, _ p: CGPainter, _ pal: Palette) {
        let c = connectorHandleCenter(n)
        let rad = 8 / mag
        p.fill(CGPath(ellipseIn: CGRect(x: c.x - rad, y: c.y - rad, width: rad * 2, height: rad * 2), transform: nil), pal.accent)
        let a = CGMutablePath()
        let k = rad * 0.5
        a.move(to: CGPoint(x: c.x - k, y: c.y)); a.addLine(to: CGPoint(x: c.x + k, y: c.y))
        a.move(to: CGPoint(x: c.x + k * 0.2, y: c.y - k * 0.8)); a.addLine(to: CGPoint(x: c.x + k, y: c.y)); a.addLine(to: CGPoint(x: c.x + k * 0.2, y: c.y + k * 0.8))
        p.stroke(a, .white, 1.6 / mag)
    }

    private func drawOverlay(_ d: Diagram, _ p: CGPainter, _ pal: Palette) {
        let acc = pal.accent
        switch drag {
        case .marquee(let s, let now, _):
            let r = CGRect(x: min(s.x, now.x), y: min(s.y, now.y), width: abs(now.x - s.x), height: abs(now.y - s.y))
            p.fill(CGPath(rect: r, transform: nil), acc.withAlphaComponent(0.08))
            p.stroke(CGPath(rect: r, transform: nil), acc.withAlphaComponent(0.7), 1 / mag)
        case .connect(let from, _, _, let now, let y):
            guard let a = d.node(from) else { break }
            var start = Geo.clipRect(a).center
            var end = now
            if let y, d.type == .sequence, a.kind.isLifeline {
                start = CGPoint(x: a.frame.midX, y: y)
                end = CGPoint(x: now.x, y: y)
            }
            if let t = dropTarget, let tn = d.node(t) {
                p.stroke(CGPath(rect: tn.frame.insetBy(dx: -4 / mag, dy: -4 / mag), transform: nil), acc, 2 / mag)
                if !(y != nil && d.type == .sequence) { end = Geo.clipRect(tn).center }
            }
            p.stroke(Renderer.line(start, end), acc, 1.6 / mag, dash: [5 / mag, 4 / mag])
            p.fill(CGPath(ellipseIn: CGRect(x: end.x - 3 / mag, y: end.y - 3 / mag, width: 6 / mag, height: 6 / mag), transform: nil), acc)
        default: break
        }
        let vis = visibleRect
        for (vertical, v) in guides {
            let path = vertical ? Renderer.line(CGPoint(x: v, y: vis.minY), CGPoint(x: v, y: vis.maxY))
                                : Renderer.line(CGPoint(x: vis.minX, y: v), CGPoint(x: vis.maxX, y: v))
            p.stroke(path, NSColor(rgb: 0xE0457B), 1 / mag)
        }
    }

    // MARK: hit testing

    func hitNode(_ p: CGPoint, _ d: Diagram, excluding: UUID? = nil) -> Node? {
        let slop = 3 / mag
        for n in d.nodes.reversed() where n.id != excluding {
            switch n.kind {
            case .lifeline, .actorLifeline:
                if Geo.header(n).insetBy(dx: -slop, dy: -slop).contains(p) { return n }
                if abs(p.x - n.frame.midX) < 7 / mag + 3 && p.y >= n.frame.minY && p.y <= n.frame.maxY { return n }
            case .fork:
                if n.frame.insetBy(dx: -5 / mag, dy: -5 / mag).contains(p) { return n }
            default:
                var f = n.frame
                if n.kind.info.labelBelow && !n.name.isEmpty { f = f.union(CGRect(x: f.midX - 40, y: f.maxY, width: 80, height: 18)) }
                if f.insetBy(dx: -slop, dy: -slop).contains(p) { return n }
            }
        }
        return nil
    }

    func hitEdge(_ p: CGPoint, _ d: Diagram) -> Edge? {
        let r = Renderer(d, pal, NullPainter())
        let tol = 5 / mag + 1
        var best: (Edge, CGFloat)?
        for e in d.edges {
            guard let rt = r.route(e) else { continue }
            var dd = rt.distance(to: p)
            if !e.name.isEmpty && rt.middle.0.dist(p) < 14 { dd = min(dd, 1) }
            if dd < tol && dd < (best?.1 ?? .infinity) { best = (e, dd) }
        }
        return best?.0
    }

    private func handleHit(_ p: CGPoint, _ d: Diagram) -> Node? {
        guard store.tool == nil else { return nil }
        return handleOwners(d).first { connectorHandleCenter($0).dist(p) < 10 / mag }
    }

    private func resizeHit(_ p: CGPoint, _ d: Diagram) -> (UUID, Int)? {
        guard store.selection.count == 1, let id = store.selection.first, let n = d.node(id) else { return nil }
        let pts = CanvasView.handlePoints(n.frame)
        for i in allowedHandles(n) where pts[i].dist(p) < 6 / mag + 1 { return (id, i) }
        return nil
    }

    /// in sequence diagrams a message can land anywhere on a lifeline's column
    private func connectTarget(_ p: CGPoint, _ d: Diagram, from: UUID, message: Bool) -> Node? {
        if message {
            if let n = d.nodes.reversed().first(where: { $0.kind.isLifeline && p.x >= $0.frame.minX && p.x <= $0.frame.maxX && p.y >= $0.frame.minY - 20 && p.y <= $0.frame.maxY + 40 }) {
                return n
            }
        }
        return hitNode(p, d)
    }

    // MARK: mouse

    override func mouseDown(with ev: NSEvent) {
        window?.makeFirstResponder(self)
        commitEditing()
        guard let d = store.diagram else { return }
        let p = convert(ev.locationInWindow, from: nil)
        let shift = ev.modifierFlags.contains(.shift) || ev.modifierFlags.contains(.command)

        if spaceDown, let sv = enclosingScrollView {
            drag = .pan(start: ev.locationInWindow, origin: sv.contentView.bounds.origin)
            NSCursor.closedHand.set()
            return
        }
        if ev.clickCount == 2 { doubleClick(p, d); return }

        if let tool = store.tool {
            switch tool {
            case .node(let k):
                let id = store.addNode(k, at: p)
                if !ev.modifierFlags.contains(.option) { store.tool = nil }
                if let id, !k.unnamed && k != .fork { DispatchQueue.main.async { self.beginEditName(id) } }
            case .edge(let k):
                if let n = hitNode(p, d) {
                    let msg = d.type == .sequence && n.kind.isLifeline
                    drag = .connect(from: n.id, kind: k, start: p, now: p, y: msg ? p.y : nil)
                }
            }
            return
        }

        if let n = handleHit(p, d) {
            drag = .connect(from: n.id, kind: nil, start: p, now: p, y: nil)
            return
        }
        if let (id, h) = resizeHit(p, d), let n = d.node(id) {
            drag = .resize(id: id, handle: h, start: p, orig: n.frame, base: d)
            return
        }

        // bend points and message dragging on a selected connector
        let rr = Renderer(d, pal, NullPainter())
        for e in d.edges where store.selection.contains(e.id) {
            guard let rt = rr.route(e) else { continue }
            if e.y != nil && e.kind.isMessage && rt.distance(to: p) < 6 / mag + 1 {
                drag = .message(id: e.id, start: p, orig: e.y ?? 0, base: d)
                return
            }
            if let i = e.points.firstIndex(where: { $0.dist(p) < 6 / mag + 1 }) {
                drag = .bend(edge: e.id, index: i, base: d)
                return
            }
            if e.from != e.to && !e.kind.isMessage && rt.distance(to: p) < 5 / mag + 1 {
                var base = d
                guard let ei = base.edgeIndex(e.id) else { continue }
                var idx = 0
                switch e.routing {
                case .straight:
                    idx = min(rt.segment(near: p), e.points.count)
                    base.edges[ei].points.insert(p, at: idx)
                case .orthogonal:
                    if e.points.isEmpty { base.edges[ei].points = [p] } else {
                        idx = e.points.enumerated().min { $0.element.dist(p) < $1.element.dist(p) }?.offset ?? 0
                        base.edges[ei].points[idx] = p
                    }
                case .curved:
                    if e.points.isEmpty { base.edges[ei].points = [p] } else {
                        idx = e.points.enumerated().min { $0.element.dist(p) < $1.element.dist(p) }?.offset ?? 0
                    }
                }
                live = base
                drag = .bend(edge: e.id, index: idx, base: base)
                return
            }
        }

        if let e = hitEdge(p, d) {
            if shift {
                if store.selection.contains(e.id) { store.selection.remove(e.id) } else { store.selection.insert(e.id) }
            } else {
                store.selection = [e.id]
            }
            if e.kind.isMessage && e.y != nil { drag = .message(id: e.id, start: p, orig: e.y ?? 0, base: d) }
            return
        }

        if let n = hitNode(p, d) {
            // dragging down a lifeline's dashed line draws a message
            if d.type == .sequence && n.kind.isLifeline && !Geo.header(n).contains(p) && !shift {
                drag = .connect(from: n.id, kind: nil, start: p, now: p, y: p.y)
                return
            }
            if shift {
                if store.selection.contains(n.id) { store.selection.remove(n.id); return }
                store.selection.insert(n.id)
            } else if !store.selection.contains(n.id) {
                store.selection = [n.id]
            }
            drag = .move(start: p, base: d, moved: false, primary: n.id)
            return
        }

        if !shift { store.selection = [] }
        drag = .marquee(start: p, now: p, base: store.selection)
    }

    /// selected shapes plus everything inside selected containers
    private func movingSet(_ d: Diagram) -> Set<UUID> {
        var ids = Set(d.nodes.filter { store.selection.contains($0.id) }.map(\.id))
        var queue = d.nodes.filter { ids.contains($0.id) && $0.kind.info.container }
        while let c = queue.popLast() {
            for n in d.nodes where !ids.contains(n.id) && c.frame.contains(n.frame) && n.frame != c.frame {
                // only things drawn above the container belong to it
                if let ci = d.index(c.id), let ni = d.index(n.id), ni > ci || !n.kind.info.container {
                    ids.insert(n.id)
                    if n.kind.info.container { queue.append(n) }
                }
            }
        }
        return ids
    }

    private func snapped(_ v: CGFloat) -> CGFloat {
        store.snap ? (v / store.gridSize).rounded() * store.gridSize : v
    }

    override func mouseDragged(with ev: NSEvent) {
        let p = convert(ev.locationInWindow, from: nil)
        if case .pan = drag {} else { autoscroll(with: ev) }
        switch drag {
        case .none:
            break

        case .pan(let start, let origin):
            // start is in window coordinates (y up), the page is flipped (y down)
            guard let sv = enclosingScrollView else { break }
            let now = ev.locationInWindow
            let o = CGPoint(x: max(0, origin.x - (now.x - start.x) / mag), y: max(0, origin.y + (now.y - start.y) / mag))
            sv.contentView.scroll(to: o)
            sv.reflectScrolledClipView(sv.contentView)

        case .move(let start, let base, _, let primary):
            let moving = movingSet(base)
            var dx = p.x - start.x, dy = p.y - start.y
            guides = []
            if let prim = base.node(primary) {
                let target = prim.frame.offsetBy(dx: dx, dy: dy)
                let others = base.nodes.filter { !moving.contains($0.id) && !$0.kind.info.container }.map(\.frame)
                    .filter { abs($0.midY - target.midY) < 900 && abs($0.midX - target.midX) < 1400 }
                let tol = 5 / mag
                var bx: (CGFloat, CGFloat)?, by: (CGFloat, CGFloat)?
                for o in others {
                    for a in [target.minX, target.midX, target.maxX] {
                        for b in [o.minX, o.midX, o.maxX] where abs(b - a) < tol && abs(b - a) < abs(bx?.0 ?? .infinity) { bx = (b - a, b) }
                    }
                    for a in [target.minY, target.midY, target.maxY] {
                        for b in [o.minY, o.midY, o.maxY] where abs(b - a) < tol && abs(b - a) < abs(by?.0 ?? .infinity) { by = (b - a, b) }
                    }
                }
                if let bx { dx += bx.0; guides.append((true, bx.1)) } else if store.snap { dx = snapped(prim.frame.minX + dx) - prim.frame.minX }
                if let by { dy += by.0; guides.append((false, by.1)) } else if store.snap { dy = snapped(prim.frame.minY + dy) - prim.frame.minY }
            }
            // keep everything on the page
            let minX = base.nodes.filter { moving.contains($0.id) }.map(\.frame.minX).min() ?? 0
            let minY = base.nodes.filter { moving.contains($0.id) }.map(\.frame.minY).min() ?? 0
            dx = max(dx, -minX)
            dy = max(dy, -minY)
            var d = base
            for i in d.nodes.indices where moving.contains(d.nodes[i].id) {
                d.nodes[i].frame = d.nodes[i].frame.offsetBy(dx: dx, dy: dy)
            }
            for i in d.edges.indices {
                let e = d.edges[i]
                let both = moving.contains(e.from) && moving.contains(e.to)
                if both { d.edges[i].points = e.points.map { CGPoint(x: $0.x + dx, y: $0.y + dy) } }
                if let y = e.y, both || store.selection.contains(e.id) { d.edges[i].y = y + Double(dy) }
            }
            live = d
            drag = .move(start: start, base: base, moved: true, primary: primary)
            needsDisplay = true

        case .resize(let id, let h, let start, let orig, let base):
            guard let i = base.index(id) else { break }
            let n = base.nodes[i]
            let minS = Store.minSize(n)
            var r = orig
            let dx = p.x - start.x, dy = p.y - start.y
            if [0, 6, 7].contains(h) { r.origin.x = snapped(orig.minX + dx); r.size.width = orig.maxX - r.minX }
            if [2, 3, 4].contains(h) { r.size.width = snapped(orig.maxX + dx) - orig.minX }
            if [0, 1, 2].contains(h) { r.origin.y = snapped(orig.minY + dy); r.size.height = orig.maxY - r.minY }
            if [4, 5, 6].contains(h) { r.size.height = snapped(orig.maxY + dy) - orig.minY }
            if ev.modifierFlags.contains(.shift) && orig.height > 0 && !n.kind.autoSized {
                let ratio = orig.width / orig.height
                r.size.height = r.width / ratio
            }
            if r.width < minS.width { if [0, 6, 7].contains(h) { r.origin.x = orig.maxX - minS.width }; r.size.width = minS.width }
            if r.height < minS.height { if [0, 1, 2].contains(h) { r.origin.y = orig.maxY - minS.height }; r.size.height = minS.height }
            if n.kind.autoSized { r.size.height = orig.height; r.origin.y = orig.minY }
            r.origin.x = max(0, r.minX); r.origin.y = max(0, r.minY)
            var d = base
            d.nodes[i].frame = r
            live = d
            needsDisplay = true

        case .marquee(let s, _, let baseSel):
            drag = .marquee(start: s, now: p, base: baseSel)
            let r = CGRect(x: min(s.x, p.x), y: min(s.y, p.y), width: abs(p.x - s.x), height: abs(p.y - s.y))
            if let d = store.diagram {
                var sel = baseSel
                for n in d.nodes where r.contains(n.frame) { sel.insert(n.id) }
                let rr = Renderer(d, pal, NullPainter())
                for e in d.edges { if let rt = rr.route(e), r.contains(rt.bounds) { sel.insert(e.id) } }
                if sel != store.selection { store.selection = sel }
            }
            needsDisplay = true

        case .connect(let from, let kind, let s, _, let y):
            drag = .connect(from: from, kind: kind, start: s, now: p, y: y)
            if let d = store.diagram {
                let t = connectTarget(p, d, from: from, message: y != nil && d.type == .sequence)
                dropTarget = (t?.id == from && p.dist(s) < 30) ? nil : t?.id
            }
            needsDisplay = true

        case .message(let id, let start, let orig, let base):
            guard let i = base.edgeIndex(id) else { break }
            var d = base
            let ny = max(10, snapped(CGFloat(orig) + p.y - start.y))
            d.edges[i].y = Double(ny)
            live = d
            needsDisplay = true

        case .bend(let eid, let idx, let base):
            guard let i = base.edgeIndex(eid) else { break }
            var d = base
            if d.edges[i].routing == .curved && d.edges[i].points.count == 1 && idx == 0 {
                d.edges[i].points[0] = p
            } else if idx < d.edges[i].points.count {
                d.edges[i].points[idx] = CGPoint(x: snapped(p.x), y: snapped(p.y))
            }
            live = d
            needsDisplay = true
        }
    }

    override func mouseUp(with ev: NSEvent) {
        let p = convert(ev.locationInWindow, from: nil)
        let was = drag
        drag = .none
        guides = []
        defer { dropTarget = nil; needsDisplay = true }
        switch was {
        case .move(_, _, let moved, _):
            if moved, let l = live { store.commit(l) }
        case .resize, .bend:
            if let l = live { store.commit(l) }
        case .message(let id, _, _, _):
            if var l = live, let e = l.edges.first(where: { $0.id == id }) {
                Store.growLifelines(&l, to: CGFloat(e.y ?? 0))
                store.commit(l)
            }
        case .pan:
            NSCursor.arrow.set()
        case .connect(let from, let kind, let start, _, let y):
            guard let d = store.diagram, let src = d.node(from) else { break }
            let msg = y != nil && d.type == .sequence && src.kind.isLifeline
            let target = connectTarget(p, d, from: from, message: msg)
            if let t = target {
                if t.id == from && p.dist(start) < 30 { break }
                if msg && !t.kind.isLifeline { break }
                let k = kind ?? d.type.defaultEdge(src, t)
                store.addEdge(k, from: from, to: t.id, y: msg ? y : nil)
                if case .edge = store.tool, !ev.modifierFlags.contains(.option) { store.tool = nil }
            } else if p.dist(start) > 20 {
                showCatalog(at: p, from: from, kind: kind, y: msg ? y : nil)
            }
        default:
            break
        }
        live = nil
    }

    override func otherMouseDown(with ev: NSEvent) {
        guard let sv = enclosingScrollView else { return }
        drag = .pan(start: ev.locationInWindow, origin: sv.contentView.bounds.origin)
        NSCursor.closedHand.set()
    }
    override func otherMouseDragged(with ev: NSEvent) { mouseDragged(with: ev) }
    override func otherMouseUp(with ev: NSEvent) { drag = .none; NSCursor.arrow.set() }

    override func mouseMoved(with ev: NSEvent) {
        guard let d = store.diagram else { return }
        let p = convert(ev.locationInWindow, from: nil)
        var h = hitNode(p, d)?.id
        // keep the hovered shape while the mouse is on its connector handle
        if let cur = hover, let n = d.node(cur), connectorHandleCenter(n).dist(p) < 14 / mag { h = cur }
        if h != hover {
            hover = h
            needsDisplay = true
        }
        if spaceDown { NSCursor.openHand.set() }
        else if store.tool != nil { NSCursor.crosshair.set() }
        else if handleHit(p, d) != nil { NSCursor.pointingHand.set() }
        else if let (_, i) = resizeHit(p, d) { (i == 1 || i == 5 ? NSCursor.resizeUpDown : i == 3 || i == 7 ? NSCursor.resizeLeftRight : NSCursor.crosshair).set() }
        else { NSCursor.arrow.set() }
    }

    override func mouseExited(with ev: NSEvent) {
        if hover != nil { hover = nil; needsDisplay = true }
    }

    // MARK: double click, catalog, context menus

    private func doubleClick(_ p: CGPoint, _ d: Diagram) {
        if let e = hitEdge(p, d) {
            if let i = e.points.firstIndex(where: { $0.dist(p) < 7 / mag }) {
                store.updateEdge(e.id) { $0.points.remove(at: i) }
            } else {
                beginEditEdge(e.id)
            }
            return
        }
        if let n = hitNode(p, d) {
            let rel = p.y - n.frame.minY
            if n.kind.isClassifier {
                let L = ClassLayout.of(n)
                if let (op, i) = L.row(at: rel, attrs: n.attrs.count, ops: n.ops.count) { beginEditMember(n.id, op: op, index: i); return }
                if rel > L.headerH {
                    store.selection = [n.id]
                    store.addMember(op: L.showOps && rel >= L.opTop)
                    return
                }
            } else if n.kind == .entity {
                let L = EntityLayout.of(n)
                if let i = L.row(at: rel, count: n.attrs.count) { beginEditMember(n.id, op: false, index: i); return }
                if rel > L.headerH { store.selection = [n.id]; store.addMember(op: false); return }
            } else if n.kind.isLifeline && !Geo.header(n).contains(p) {
                return
            }
            beginEditName(n.id)
            return
        }
        let menu = NSMenu()
        menu.autoenablesItems = false
        menu.header("Add to diagram")
        for k in d.type.nodes {
            menu.addItem(ActionItem(k.title, image: Thumbs.node(k, pal.dark, size: 18)) { [weak self] in
                guard let self, let id = self.store.addNode(k, at: p) else { return }
                if !k.unnamed { self.beginEditName(id) }
            })
        }
        menu.popUp(positioning: nil, at: p, in: self)
    }

    /// dropping a connector on empty canvas offers the shapes it could lead to
    private func showCatalog(at p: CGPoint, from: UUID, kind: EdgeKind?, y: CGFloat?) {
        guard let d = store.diagram else { return }
        let menu = NSMenu()
        menu.autoenablesItems = false
        menu.header(kind.map { "New shape with \($0.title)" } ?? "Create and connect")
        for k in d.type.nodes {
            menu.addItem(ActionItem(k.title, image: Thumbs.node(k, pal.dark, size: 18)) { [weak self] in
                self?.store.addConnected(k, from: from, at: p, edge: kind, y: y)
            })
        }
        menu.popUp(positioning: nil, at: p, in: self)
    }

    static let fills: [(String, String?)] = [("Default", nil), ("Blue", "#DCE8FD"), ("Green", "#D6F2E2"), ("Yellow", "#FFF3BF"), ("Orange", "#FFE0C2"),
                                               ("Red", "#FDD9D9"), ("Pink", "#FBDDF0"), ("Purple", "#E8DDFD"), ("Teal", "#D2EFF2"), ("Gray", "#E6E8EC"), ("White", "#FFFFFF")]

    static func swatch(_ hex: String?) -> NSImage {
        NSImage(size: NSSize(width: 14, height: 14), flipped: false) { r in
            let path = NSBezierPath(roundedRect: r.insetBy(dx: 1, dy: 1), xRadius: 3, yRadius: 3)
            (hex.map { NSColor(hex: $0) } ?? NSColor.clear).setFill()
            path.fill()
            NSColor.gray.setStroke()
            path.stroke()
            if hex == nil {
                let l = NSBezierPath()
                l.move(to: NSPoint(x: 2, y: 2)); l.line(to: NSPoint(x: 12, y: 12))
                NSColor.systemRed.setStroke()
                l.stroke()
            }
            return true
        }
    }

    override func menu(for ev: NSEvent) -> NSMenu? {
        guard let d = store.diagram else { return nil }
        commitEditing()
        let p = convert(ev.locationInWindow, from: nil)
        let menu = NSMenu()
        menu.autoenablesItems = false
        let s = store

        if let e = hitEdge(p, d) {
            if !s.selection.contains(e.id) { s.selection = [e.id] }
            menu.addItem(ActionItem("Edit Label") { [weak self] in self?.beginEditEdge(e.id) })
            let kinds = d.type.edges
            menu.sub("Type", kinds.map { k in ActionItem(k.title, on: k == e.kind) { s.updateEdge(e.id) { $0.kind = k } } })
            if !e.kind.isMessage {
                menu.sub("Routing", Routing.allCases.map { r in ActionItem(r.title, on: r == e.routing) { s.updateEdge(e.id) { $0.routing = r; $0.points = [] } } })
            }
            if e.kind == .relationship {
                let presets: [(String, String, String)] = [("One to one (1 : 1)", "1", "1"), ("One to many (1 : N)", "1", "0..*"), ("One to one-or-more", "1", "1..*"),
                                                           ("Zero-or-one to many", "0..1", "0..*"), ("Many to one (N : 1)", "0..*", "1")]
                menu.sub("Cardinality", presets.map { pr in ActionItem(pr.0, on: e.fromMult == pr.1 && e.toMult == pr.2) { s.updateEdge(e.id) { $0.fromMult = pr.1; $0.toMult = pr.2 } } })
            }
            if e.kind.hasEnds && e.kind != .relationship {
                let mults = ["", "1", "0..1", "*", "0..*", "1..*"]
                menu.sub("Source Multiplicity", mults.map { m in ActionItem(m.isEmpty ? "None" : m, on: e.fromMult == m) { s.updateEdge(e.id) { $0.fromMult = m } } })
                menu.sub("Target Multiplicity", mults.map { m in ActionItem(m.isEmpty ? "None" : m, on: e.toMult == m) { s.updateEdge(e.id) { $0.toMult = m } } })
            }
            menu.addItem(ActionItem("Reverse Direction") {
                s.updateEdge(e.id) { x in
                    swap(&x.from, &x.to); swap(&x.fromMult, &x.toMult); swap(&x.fromRole, &x.toRole)
                    x.points.reverse()
                }
            })
            if !e.points.isEmpty { menu.addItem(ActionItem("Reset Path") { s.updateEdge(e.id) { $0.points = [] } }) }
            menu.addItem(.separator())
            menu.addItem(ActionItem("Delete") { s.deleteSelection() })
            return menu
        }

        if let n = hitNode(p, d) {
            if !s.selection.contains(n.id) { s.selection = [n.id] }
            let multi = s.selection.count > 1
            if !multi {
                menu.addItem(ActionItem("Rename") { [weak self] in self?.beginEditName(n.id) })
                if n.kind == .klass || n.kind == .interface || n.kind == .enumeration {
                    menu.addItem(ActionItem(n.kind == .enumeration ? "Add Literal" : "Add Attribute") { s.addMember(op: false) })
                    menu.addItem(ActionItem("Add Operation") { s.addMember(op: true) })
                    if n.kind == .klass { menu.addItem(ActionItem("Abstract", on: n.isAbstract) { s.updateNode(n.id) { $0.isAbstract.toggle() } }) }
                    menu.addItem(ActionItem("Show Java Code…") { s.codeFocus = n.id; s.sheet = .java })
                }
                if n.kind == .object { menu.addItem(ActionItem("Add Slot") { s.addMember(op: false) }) }
                if n.kind == .entity {
                    menu.addItem(ActionItem("Add Column") { s.addMember(op: false) })
                    menu.addItem(ActionItem("Show SQL…") { s.codeFocus = n.id; s.sheet = .sql })
                }
                if d.type == .mindMap && (n.kind == .topic || n.kind == .central) {
                    menu.addItem(ActionItem("Add Child Topic  (Tab)") { s.mindAdd(child: true) })
                    if n.kind == .topic { menu.addItem(ActionItem("Add Sibling Topic  (Return)") { s.mindAdd(child: false) }) }
                }
                if n.kind == .fragment {
                    let ops = ["loop", "alt", "opt", "par", "break", "critical", "neg", "ref"]
                    menu.sub("Operator", ops.map { o in ActionItem(o, on: n.prop("operator") == o) { s.updateNode(n.id) { $0.props["operator"] = o } } })
                }
                if [.startEvent, .interEvent, .endEvent].contains(n.kind) {
                    let trig = [("None", ""), ("Message", "message"), ("Timer", "timer"), ("Error", "error")]
                    menu.sub("Trigger", trig.map { t in ActionItem(t.0, on: n.prop("trigger") == t.1) { s.updateNode(n.id) { $0.props["trigger"] = t.1 } } })
                }
                if n.kind == .history {
                    menu.addItem(ActionItem("Deep History", on: n.prop("deep") == "true") { s.updateNode(n.id) { $0.props["deep"] = $0.prop("deep") == "true" ? "false" : "true" } })
                }
                menu.addItem(.separator())
            }
            menu.sub("Fill Colour", CanvasView.fills.map { f in
                ActionItem(f.0, image: CanvasView.swatch(f.1)) {
                    let ids = s.selection
                    s.edit { d in for i in d.nodes.indices where ids.contains(d.nodes[i].id) { d.nodes[i].fill = f.1 } }
                }
            })
            if multi {
                menu.sub("Align", [("Left", 0), ("Centre", 1), ("Right", 2), ("Top", 3), ("Middle", 4), ("Bottom", 5)].map { a in ActionItem(a.0) { s.align(a.1) } })
                menu.sub("Distribute", [ActionItem("Horizontally") { s.distribute(horizontal: true) }, ActionItem("Vertically") { s.distribute(horizontal: false) }])
            }
            menu.addItem(ActionItem("Bring to Front") { s.order(0) })
            menu.addItem(ActionItem("Send to Back") { s.order(3) })
            menu.addItem(.separator())
            menu.addItem(ActionItem("Duplicate") { s.duplicate() })
            menu.addItem(ActionItem("Copy") { s.copySelection() })
            menu.addItem(ActionItem("Cut") { s.cutSelection() })
            menu.addItem(ActionItem("Delete") { s.deleteSelection() })
            return menu
        }

        s.selection = []
        menu.addItem(ActionItem("Paste", enabled: s.canPaste) { s.paste() })
        menu.sub("Add", d.type.nodes.map { k in
            ActionItem(k.title, image: Thumbs.node(k, pal.dark, size: 18)) { [weak self] in
                guard let id = s.addNode(k, at: p) else { return }
                if !k.unnamed { self?.beginEditName(id) }
            }
        })
        menu.addItem(ActionItem("Select All") { s.selectAll() })
        menu.addItem(.separator())
        menu.sub("Auto Layout", LayoutStyle.allCases.map { st in ActionItem(st.title) { s.autoLayout(st) } })
        menu.addItem(ActionItem("Zoom to Fit") { [weak self] in self?.zoomToFit() })
        menu.addItem(ActionItem("Show Grid", on: s.showGrid) { s.showGrid.toggle() })
        menu.addItem(ActionItem("Snap to Grid", on: s.snap) { s.snap.toggle() })
        menu.addItem(.separator())
        menu.addItem(ActionItem("Export Diagram as PNG…") { Exporter.exportCurrent(s, .png) })
        return menu
    }

    // MARK: keyboard

    override func keyDown(with ev: NSEvent) {
        let flags = ev.modifierFlags.intersection([.command, .option, .control, .shift])
        let step: CGFloat = flags.contains(.shift) ? 10 : (store.snap ? store.gridSize : 1)
        let d = store.diagram
        switch ev.keyCode {
        case 51, 117:
            store.deleteSelection()
        case 123: store.nudge(-step, 0)
        case 124: store.nudge(step, 0)
        case 125: store.nudge(0, step)
        case 126: store.nudge(0, -step)
        case 36, 76:
            if d?.type == .mindMap && store.selection.count == 1 && store.selectedNodes.first?.kind == .topic {
                store.mindAdd(child: false)
            } else if store.selection.count == 1, let id = store.selection.first {
                if store.node(id) != nil { beginEditName(id) } else if store.edge(id) != nil { beginEditEdge(id) }
            }
        case 48:
            if d?.type == .mindMap && store.selection.count == 1 {
                store.mindAdd(child: true)
            } else if let d, !d.nodes.isEmpty {
                // Tab walks through the shapes
                let cur = store.selection.first.flatMap { d.index($0) } ?? -1
                let next = flags.contains(.shift) ? (cur - 1 + d.nodes.count) % d.nodes.count : (cur + 1) % d.nodes.count
                store.selection = [d.nodes[next].id]
                scrollToSelection()
            }
        case 53:
            if store.tool != nil { store.tool = nil } else { store.selection = [] }
        case 49:
            spaceDown = true
            NSCursor.openHand.set()
        case 120:
            if let id = store.selection.first, store.node(id) != nil { beginEditName(id) }
        default:
            if flags == [.option, .shift] && ev.keyCode == 0 { store.addMember(op: false); return }
            if flags == [.option, .shift] && ev.keyCode == 31 { store.addMember(op: true); return }
            // start typing on a selected shape to rename it
            if flags.isEmpty || flags == [.shift], store.selection.count == 1, let id = store.selection.first, let n = store.node(id),
               let ch = ev.characters, ch.count == 1, ch.rangeOfCharacter(from: .alphanumerics) != nil, !n.kind.unnamed {
                beginEditName(id, replacing: ch)
                return
            }
            super.keyDown(with: ev)
        }
    }

    override func keyUp(with ev: NSEvent) {
        if ev.keyCode == 49 {
            spaceDown = false
            NSCursor.arrow.set()
        } else {
            super.keyUp(with: ev)
        }
    }

    // MARK: edit menu actions (text fields handle these themselves while editing)

    @objc func undo(_ sender: Any?) { store.undo() }
    @objc func redo(_ sender: Any?) { store.redo() }
    @objc func copy(_ sender: Any?) { store.copySelection() }
    @objc func cut(_ sender: Any?) { store.cutSelection() }
    @objc func paste(_ sender: Any?) { store.paste() }
    @objc func delete(_ sender: Any?) { store.deleteSelection() }
    @objc func duplicate(_ sender: Any?) { store.duplicate() }
    override func selectAll(_ sender: Any?) { store.selectAll() }

    func validateMenuItem(_ item: NSMenuItem) -> Bool {
        switch item.action {
        case #selector(undo(_:)): return store.canUndo
        case #selector(redo(_:)): return store.canRedo
        case #selector(copy(_:)), #selector(cut(_:)), #selector(delete(_:)), #selector(duplicate(_:)): return !store.selection.isEmpty
        case #selector(paste(_:)): return store.canPaste
        default: return true
        }
    }

    // MARK: drag and drop from the toolbox

    private func droppedKind(_ s: NSDraggingInfo) -> NodeKind? {
        guard let str = s.draggingPasteboard.string(forType: .string), str.hasPrefix("blueprint-node:") else { return nil }
        return NodeKind(rawValue: String(str.dropFirst("blueprint-node:".count)))
    }
    override func draggingEntered(_ s: NSDraggingInfo) -> NSDragOperation { droppedKind(s) != nil ? .copy : [] }
    override func draggingUpdated(_ s: NSDraggingInfo) -> NSDragOperation { droppedKind(s) != nil ? .copy : [] }
    override func performDragOperation(_ s: NSDraggingInfo) -> Bool {
        guard let k = droppedKind(s) else { return false }
        let p = convert(s.draggingLocation, from: nil)
        guard let id = store.addNode(k, at: p) else { return false }
        window?.makeFirstResponder(self)
        if !k.unnamed && k != .fork { DispatchQueue.main.async { self.beginEditName(id) } }
        return true
    }

    // MARK: inline editing

    func beginEditName(_ id: UUID, replacing: String? = nil) {
        guard let n = store.node(id) else { return }
        store.selection = [id]
        let r = n.frame
        let fs = CGFloat(n.fontSize ?? 12)
        var font = F(size: fs, bold: true).ns
        var text = n.name
        var rect: CGRect
        var multi = false
        var align: NSTextAlignment = .center
        switch n.kind {
        case .klass, .interface, .enumeration, .object:
            let L = ClassLayout.of(n)
            rect = CGRect(x: r.minX + 3, y: r.minY + L.headerH - 26, width: r.width - 6, height: 22)
            if n.kind == .object { text = L.name }
        case .entity:
            rect = CGRect(x: r.minX + 3, y: r.minY + EntityLayout.of(n).headerH / 2 - 11, width: r.width - 6, height: 22)
        case .lifeline:
            let h = Geo.header(n)
            let c = n.prop("classifier")
            text = c.isEmpty ? n.name : "\(n.name) : \(c)"
            rect = CGRect(x: h.minX + 2, y: h.midY - 11, width: max(h.width - 4, 140), height: 22)
        case .actor:
            rect = CGRect(x: r.midX - 70, y: r.maxY - Geo.actorLabel, width: 140, height: 22)
        case .actorLifeline:
            let h = Geo.header(n)
            let c = n.prop("classifier")
            text = c.isEmpty ? n.name : "\(n.name) : \(c)"
            rect = CGRect(x: h.midX - 70, y: h.maxY - 22, width: 140, height: 22)
        case .note, .annotation, .text:
            rect = r.insetBy(dx: 4, dy: 4)
            multi = true
            align = n.kind == .text ? .center : .left
            font = F(size: fs - 0.5).ns
        case .package:
            rect = CGRect(x: r.minX + 2, y: r.minY, width: max(140, r.width * 0.6), height: 22)
        case .boundary, .fragment:
            rect = CGRect(x: r.minX + 40, y: r.minY + 4, width: r.width - 80, height: 22)
        case .lane, .pool:
            rect = r.width > r.height ? CGRect(x: r.minX + 34, y: r.minY + 4, width: 200, height: 22) : CGRect(x: r.minX + 4, y: r.minY + 4, width: r.width - 8, height: 22)
        case .state:
            rect = CGRect(x: r.minX + 6, y: r.minY + 3, width: r.width - 12, height: 22)
        case .node3d, .device, .execEnv:
            rect = CGRect(x: r.minX + 4, y: r.minY + 14, width: r.width - 20, height: 22)
            align = .left
        default:
            if n.kind.info.labelBelow || n.kind == .history {
                rect = CGRect(x: r.midX - 80, y: r.maxY + 2, width: 160, height: 22)
            } else {
                rect = CGRect(x: r.minX + 4, y: r.midY - 11, width: max(r.width - 8, 120), height: 22)
                if rect.width > r.width { rect.origin.x = r.midX - rect.width / 2 }
            }
            font = F(size: fs, bold: n.kind == .central).ns
        }
        showEditor(replacing ?? text, rect, .name(id), multi: multi, align: align, font: font, selectAll: replacing == nil)
    }

    func beginEditMember(_ id: UUID, op: Bool, index: Int, isNew: Bool = true) {
        guard let n = store.node(id) else { return }
        store.selection = [id]
        let r = n.frame
        let list = op ? n.ops : n.attrs
        guard index < list.count else { return }
        let m = list[index]
        let fs = CGFloat(n.fontSize ?? 12)
        var rect: CGRect
        var text: String
        let showVis = n.kind == .klass || n.kind == .interface
        if n.kind == .entity {
            let L = EntityLayout.of(n)
            rect = CGRect(x: r.minX + L.keyW - 3, y: r.minY + L.headerH + 3 + CGFloat(index) * L.rowH - 1, width: max(r.width - L.keyW, 170), height: L.rowH + 2)
            text = UMLText.attrEdit(m, kind: .entity)
        } else {
            let L = ClassLayout.of(n)
            let top = op ? L.opTop : L.attrTop
            rect = CGRect(x: r.minX + 4, y: r.minY + top + 4 + CGFloat(index) * L.rowH - 2, width: max(r.width - 8, 200), height: L.rowH + 4)
            text = op ? UMLText.opEdit(m) : UMLText.attrEdit(m, kind: n.kind)
            if showVis { text = "\(m.vis.rawValue) \(text)" }
        }
        showEditor(text, rect, .member(id, op, index, false), multi: false, align: .left, font: F(size: fs - 0.5).ns, selectAll: true)
        if isNew, case .member(let a, let b, let c, _) = editTarget { editTarget = .member(a, b, c, true) }
    }

    func beginEditEdge(_ id: UUID) {
        guard let d = store.diagram, let e = d.edges.first(where: { $0.id == id }) else { return }
        let r = Renderer(d, pal, NullPainter())
        guard let rt = r.route(e) else { return }
        store.selection = [id]
        var mid = rt.middle.0
        if e.kind.isMessage && d.type == .sequence { mid = CGPoint(x: (rt.pts[0].x + rt.pts[1].x) / 2, y: rt.pts[0].y - 10) }
        showEditor(e.name, CGRect(x: mid.x - 90, y: mid.y - 11, width: 180, height: 22), .edgeName(id), multi: false, align: .center, font: F(size: 11).ns, selectAll: true)
    }

    private func showEditor(_ text: String, _ rect: CGRect, _ target: EditTarget, multi: Bool, align: NSTextAlignment, font: NSFont, selectAll: Bool) {
        cancelEditing()
        let f = EditorField(frame: rect.integral)
        f.multiline = multi
        f.stringValue = text
        f.font = font
        f.alignment = align
        f.isBezeled = false
        f.isBordered = false
        f.drawsBackground = true
        f.backgroundColor = pal.paper
        f.textColor = pal.ink
        f.focusRingType = .none
        f.wantsLayer = true
        f.layer?.borderColor = pal.accent.cgColor
        f.layer?.borderWidth = 1.5
        f.layer?.cornerRadius = 3
        f.usesSingleLineMode = !multi
        f.cell?.wraps = multi
        f.cell?.isScrollable = !multi
        f.delegate = self
        addSubview(f)
        editor = f
        editTarget = target
        window?.makeFirstResponder(f)
        if let ed = f.currentEditor() {
            if selectAll { ed.selectAll(nil) } else { ed.selectedRange = NSRange(location: (text as NSString).length, length: 0) }
        }
    }

    var isEditing: Bool { editor != nil }

    func control(_ control: NSControl, textView: NSTextView, doCommandBy sel: Selector) -> Bool {
        guard let f = editor else { return false }
        if sel == #selector(NSResponder.insertNewline(_:)) {
            if f.multiline && !(NSApp.currentEvent?.modifierFlags.contains(.command) ?? false) {
                textView.insertNewlineIgnoringFieldEditor(nil)
                return true
            }
            commitEditing(chain: true)
            return true
        }
        if sel == #selector(NSResponder.cancelOperation(_:)) {
            cancelEditing()
            window?.makeFirstResponder(self)
            return true
        }
        if sel == #selector(NSResponder.insertTab(_:)) {
            let mind = store.diagram?.type == .mindMap
            commitEditing()
            if mind { store.mindAdd(child: true) }
            return true
        }
        return false
    }

    func controlTextDidEndEditing(_ n: Notification) {
        if editor != nil { commitEditing() }
    }

    func cancelEditing() {
        guard let f = editor, let t = editTarget else { return }
        editor = nil
        editTarget = nil
        f.removeFromSuperview()
        // a new, untouched member is dropped again
        if case .member(let id, let op, let i, let isNew) = t, isNew, let n = store.node(id) {
            let list = op ? n.ops : n.attrs
            if i < list.count { store.updateNode(id) { if op { $0.ops.remove(at: i) } else { $0.attrs.remove(at: i) } } }
        }
    }

    func commitEditing(chain: Bool = false) {
        guard let f = editor, let t = editTarget else { return }
        editor = nil
        editTarget = nil
        let text = f.stringValue
        f.removeFromSuperview()
        if window?.firstResponder == nil || window?.firstResponder is NSText { window?.makeFirstResponder(self) }
        switch t {
        case .name(let id):
            guard let n = store.node(id) else { return }
            if n.kind == .object || n.kind.isLifeline {
                let parts = text.split(separator: ":", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
                let name = parts.first ?? ""
                let cls = text.contains(":") && parts.count > 1 ? parts[1] : n.prop("classifier")
                if name != n.name || cls != n.prop("classifier") {
                    store.updateNode(id) { $0.name = name; $0.props["classifier"] = cls }
                }
            } else if text != n.name {
                store.updateNode(id) { $0.name = text }
            }
        case .member(let id, let op, let i, let isNew):
            guard let n = store.node(id) else { return }
            let list = op ? n.ops : n.attrs
            guard i < list.count else { return }
            if text.trimmed.isEmpty {
                store.updateNode(id) { if op { $0.ops.remove(at: i) } else { $0.attrs.remove(at: i) } }
                return
            }
            let m = UMLText.apply(text, to: list[i], op: op, kind: n.kind)
            store.updateNode(id) { if op { $0.ops[i] = m } else { $0.attrs[i] = m } }
            // Return after typing a new member starts the next one straight away
            if chain && isNew { store.addMember(op: op) }
        case .edgeName(let id):
            if store.edge(id)?.name != text { store.updateEdge(id) { $0.name = text } }
        }
    }

    // MARK: zoom and scrolling

    override func scrollWheel(with ev: NSEvent) {
        if ev.modifierFlags.contains(.command) || ev.modifierFlags.contains(.control) {
            let p = convert(ev.locationInWindow, from: nil)
            let f = exp(ev.scrollingDeltaY * (ev.hasPreciseScrollingDeltas ? 0.008 : 0.08))
            setZoom(mag * f, center: p)
        } else {
            super.scrollWheel(with: ev)
        }
    }

    func setZoom(_ m: CGFloat, center: CGPoint? = nil) {
        guard let sv = enclosingScrollView else { return }
        updateSize()
        sv.setMagnification(max(0.1, min(4, m)), centeredAt: center ?? visibleRect.center)
        store.zoom = sv.magnification
        updateSize()
        store.overview?.needsDisplay = true
    }

    func zoomIn() { setZoom(mag * 1.25) }
    func zoomOut() { setZoom(mag / 1.25) }
    func zoomActual() { setZoom(1) }

    func zoomToFit() {
        guard let sv = enclosingScrollView, let d = store.diagram else { return }
        let b = d.contentBounds
        if b.isNull {
            sv.magnification = 1
            sv.contentView.scroll(to: .zero)
            store.zoom = 1
            return
        }
        let vis = sv.contentView.frame.size
        let m = max(0.1, min(vis.width / (b.width + 80), vis.height / (b.height + 80), 1.25))
        sv.magnification = m
        updateSize()
        let visDoc = sv.contentView.bounds.size
        let o = CGPoint(x: max(0, b.midX - visDoc.width / 2), y: max(0, b.midY - visDoc.height / 2))
        sv.contentView.scroll(to: o)
        sv.reflectScrolledClipView(sv.contentView)
        store.zoom = m
        store.overview?.needsDisplay = true
    }

    func scrollToSelection() {
        guard let d = store.diagram else { return }
        let r = d.nodes.filter { store.selection.contains($0.id) }.map(\.frame).reduce(CGRect.null) { $0.union($1) }
        guard !r.isNull else { return }
        updateSize()
        let vis = visibleRect
        if !vis.contains(r) {
            let o = CGPoint(x: max(0, r.midX - vis.width / 2), y: max(0, r.midY - vis.height / 2))
            scroll(o)
        }
        needsDisplay = true
    }

    func center(on p: CGPoint) {
        let vis = visibleRect
        scroll(CGPoint(x: max(0, p.x - vis.width / 2), y: max(0, p.y - vis.height / 2)))
        store.overview?.needsDisplay = true
    }

    func saveViewState() {
        guard let id = store.currentId, let sv = enclosingScrollView else { return }
        store.viewState[id] = (sv.contentView.bounds.origin, sv.magnification)
    }

    func restoreViewState() {
        DispatchQueue.main.async { [weak self] in
            guard let self, let sv = self.enclosingScrollView else { return }
            self.live = nil
            self.updateSize()
            if let id = self.store.currentId, let (o, m) = self.store.viewState[id] {
                sv.magnification = m
                self.updateSize()
                sv.contentView.scroll(to: o)
                sv.reflectScrolledClipView(sv.contentView)
                self.store.zoom = m
            } else if let d = self.store.diagram, !d.nodes.isEmpty {
                self.zoomToFit()
                if self.mag > 1 { self.setZoom(1) }
            } else {
                sv.magnification = 1
                sv.contentView.scroll(to: .zero)
                self.store.zoom = 1
            }
            self.needsDisplay = true
            self.store.overview?.needsDisplay = true
        }
    }
}

extension CanvasView.Drag {
    var isIdle: Bool { if case .none = self { return true }; return false }
    var isResize: Bool { if case .resize = self { return true }; return false }
}

// MARK: - the overview in the corner of the canvas

final class OverviewView: NSView {
    weak var store: Store?
    override var isFlipped: Bool { true }

    private var mapping: (CGRect, CGFloat, CGPoint)? // content bounds, scale, offset

    override func draw(_ dirty: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext, let s = store, let c = s.canvas, let d = c.dia else { return }
        let pal = c.pal
        let box = bounds
        ctx.setFillColor(pal.paper.cgColor)
        ctx.fill(box)
        var b = d.contentBounds
        let vis = c.visibleRect
        b = b.isNull ? vis : b.union(vis)
        b = b.insetBy(dx: -20, dy: -20)
        let scale = min((box.width - 10) / b.width, (box.height - 10) / b.height)
        let off = CGPoint(x: (box.width - b.width * scale) / 2, y: (box.height - b.height * scale) / 2)
        mapping = (b, scale, off)
        ctx.saveGState()
        ctx.translateBy(x: off.x, y: off.y)
        ctx.scaleBy(x: scale, y: scale)
        ctx.translateBy(x: -b.minX, y: -b.minY)
        Renderer(d, pal, ShapesOnlyPainter(CGPainter(ctx))).drawAll()
        ctx.restoreGState()
        let v = CGRect(x: off.x + (vis.minX - b.minX) * scale, y: off.y + (vis.minY - b.minY) * scale, width: vis.width * scale, height: vis.height * scale)
        ctx.setFillColor(pal.accent.withAlphaComponent(0.10).cgColor)
        ctx.fill(v)
        ctx.setStrokeColor(pal.accent.cgColor)
        ctx.setLineWidth(1.2)
        ctx.stroke(v.insetBy(dx: 0.6, dy: 0.6))
    }

    private func jump(_ ev: NSEvent) {
        guard let (b, scale, off) = mapping, let c = store?.canvas else { return }
        let p = convert(ev.locationInWindow, from: nil)
        c.center(on: CGPoint(x: b.minX + (p.x - off.x) / scale, y: b.minY + (p.y - off.y) / scale))
    }
    override func mouseDown(with ev: NSEvent) { jump(ev) }
    override func mouseDragged(with ev: NSEvent) { jump(ev) }
}

struct CanvasHost: NSViewRepresentable {
    let store: Store

    func makeNSView(context: Context) -> NSScrollView {
        let sv = CanvasHost.makeScrollView(store)
        DispatchQueue.main.async { sv.window?.makeFirstResponder(sv.documentView) }
        return sv
    }

    static func makeScrollView(_ store: Store) -> NSScrollView {
        let sv = NSScrollView()
        sv.hasHorizontalScroller = true
        sv.hasVerticalScroller = true
        sv.autohidesScrollers = true
        sv.scrollerStyle = .overlay
        sv.allowsMagnification = true
        sv.minMagnification = 0.1
        sv.maxMagnification = 4
        sv.borderType = .noBorder
        let c = CanvasView(store: store)
        sv.documentView = c
        sv.backgroundColor = c.pal.paper
        store.canvas = c
        sv.contentView.postsBoundsChangedNotifications = true
        NotificationCenter.default.addObserver(c, selector: #selector(CanvasView.clipChanged), name: NSView.boundsDidChangeNotification, object: sv.contentView)
        NotificationCenter.default.addObserver(c, selector: #selector(CanvasView.magnified), name: NSScrollView.didEndLiveMagnifyNotification, object: sv)
        NotificationCenter.default.addObserver(c, selector: #selector(CanvasView.clipChanged), name: NSView.frameDidChangeNotification, object: sv)
        c.restoreViewState()
        return sv
    }

    func updateNSView(_ sv: NSScrollView, context: Context) {}
}

struct OverviewHost: NSViewRepresentable {
    let store: Store
    func makeNSView(context: Context) -> OverviewView {
        let o = OverviewView()
        o.store = store
        store.overview = o
        return o
    }
    func updateNSView(_ o: OverviewView, context: Context) { o.needsDisplay = true }
}
