import AppKit

/// small helper for building diagrams in code
final class DB {
    var d: Diagram
    init(_ name: String, _ t: DiagramType, doc: String = "") { d = Diagram(name: name, type: t, doc: doc) }

    @discardableResult
    func n(_ k: NodeKind, _ name: String, _ x: CGFloat, _ y: CGFloat, w: CGFloat? = nil, h: CGFloat? = nil,
           a: [String] = [], o: [String] = [], st: String = "", abstract: Bool = false, props: [String: String] = [:],
           doc: String = "", fill: String? = nil) -> UUID {
        let s = k.info.size
        var node = Node(kind: k, frame: CGRect(x: x, y: y, width: w ?? s.width, height: h ?? s.height), name: name)
        node.stereotype = st
        node.isAbstract = abstract
        node.props = props
        node.doc = doc
        node.fill = fill
        switch k {
        case .entity: node.attrs = a.map { UMLText.column($0) }
        case .enumeration: node.attrs = a.map { Member(name: $0, vis: .pub) }
        case .object:
            node.attrs = a.map { s in
                let p = s.split(separator: "=", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
                return Member(name: p[0], vis: .pub, value: p.count > 1 ? p[1] : "")
            }
        default: node.attrs = a.map { UMLText.attr($0) }
        }
        node.ops = o.map { UMLText.op($0) }
        // class boxes without a given width hug their contents
        if w == nil && k.autoSized { node.frame.size.width = 0 }
        Store.fit(&node)
        if k.info.container {
            let i = d.nodes.firstIndex { !$0.kind.info.container } ?? d.nodes.count
            d.nodes.insert(node, at: i)
        } else {
            d.nodes.append(node)
        }
        return node.id
    }

    @discardableResult
    func e(_ k: EdgeKind, _ a: UUID, _ b: UUID, _ name: String = "", fm: String = "", tm: String = "", fr: String = "", tr: String = "",
           y: CGFloat? = nil, r: Routing? = nil, via: [CGPoint] = []) -> UUID {
        var e = Edge(kind: k, from: a, to: b, name: name, fromRole: fr, toRole: tr, fromMult: fm, toMult: tm)
        e.routing = r ?? (k == .branch ? .curved : d.type.routing)
        e.points = via
        if let y { e.y = Double(y) }
        d.edges.append(e)
        return e.id
    }
}

enum Samples {
    static func make(_ t: DiagramType) -> Diagram {
        switch t {
        case .classDiagram: return shopClasses()
        case .useCase: return atm()
        case .sequence: return placeOrder()
        case .activity: return processOrder()
        case .stateMachine: return orderStates()
        case .component: return components()
        case .deployment: return deployment()
        case .package: return packages()
        case .object: return objects()
        case .erd: return shopDatabase()
        case .flowchart: return login()
        case .bpmn: return fulfilment()
        case .mindMap: return learningJava()
        case .dfd: return dataFlow()
        }
    }

    static func shopClasses() -> Diagram {
        let b = DB("Online Shop", .classDiagram, doc: "The classes behind a small web shop. Try Tools ▸ Generate Java Code.")
        let customer = b.n(.klass, "Customer", 60, 60, a: ["- name : String", "- email : String", "- static customerCount : int = 0"],
                           o: ["+ placeOrder(products: List<Product>) : Order", "+ getOrders() : List<Order>"], doc: "Someone who buys things in the shop.")
        let order = b.n(.klass, "Order", 440, 60, a: ["- id : long", "- date : LocalDate", "- status : OrderStatus"],
                        o: ["+ total() : double", "+ addLine(product: Product, quantity: int) : void"])
        let status = b.n(.enumeration, "OrderStatus", 830, 60, a: ["NEW", "PAID", "SHIPPED", "DELIVERED"])
        let payment = b.n(.klass, "Payment", 60, 340, a: ["# amount : double"], o: ["+ abstract pay() : boolean"], abstract: true)
        let line = b.n(.klass, "OrderLine", 440, 340, a: ["- quantity : int"], o: ["+ subtotal() : double"])
        let product = b.n(.klass, "Product", 810, 340, a: ["- name : String", "- price : double"], o: ["+ getPrice() : double", "+ discount(percent: int) : double"])
        let card = b.n(.klass, "CreditCardPayment", 20, 560, a: ["- cardNumber : String"], o: ["+ pay() : boolean"])
        let paypal = b.n(.klass, "PayPalPayment", 250, 560, a: ["- account : String"], o: ["+ pay() : boolean"])
        let disc = b.n(.interface, "Discountable", 810, 560, o: ["+ discount(percent: int) : double"])
        let note = b.n(.note, "Composition (filled diamond): an OrderLine can't exist without its Order.", 470, 560, w: 200, h: 64)
        b.e(.association, customer, order, "places", fm: "1", tm: "0..*")
        b.e(.composition, order, line, fm: "1", tm: "1..*", tr: "lines")
        b.e(.directed, line, product, tm: "1")
        b.e(.directed, order, payment, tm: "0..1")
        b.e(.generalization, card, payment)
        b.e(.generalization, paypal, payment)
        b.e(.realization, product, disc)
        b.e(.dependency, order, status)
        b.e(.anchor, note, line)
        return b.d
    }

    static func atm() -> Diagram {
        let b = DB("ATM", .useCase, doc: "What people can do with a cash machine.")
        b.n(.boundary, "ATM System", 220, 40, w: 430, h: 450)
        let customer = b.n(.actor, "Customer", 90, 170)
        let tech = b.n(.actor, "Technician", 90, 370)
        let bank = b.n(.actor, "Bank", 740, 200)
        let withdraw = b.n(.useCase, "Withdraw Cash", 250, 90)
        let deposit = b.n(.useCase, "Deposit Money", 250, 180)
        let balance = b.n(.useCase, "Check Balance", 250, 270)
        let refill = b.n(.useCase, "Refill Machine", 250, 390)
        let auth = b.n(.useCase, "Authenticate", 470, 200)
        let receipt = b.n(.useCase, "Print Receipt", 470, 80)
        b.e(.association, customer, withdraw)
        b.e(.association, customer, deposit)
        b.e(.association, customer, balance)
        b.e(.association, tech, refill)
        b.e(.include, withdraw, auth)
        b.e(.include, deposit, auth)
        b.e(.include, balance, auth)
        b.e(.extend, receipt, withdraw)
        b.e(.association, auth, bank)
        return b.d
    }

    static func placeOrder() -> Diagram {
        let b = DB("Place Order", .sequence, doc: "Each arrow is a method call. Read from top to bottom.")
        let cust = b.n(.actorLifeline, "customer", 40, 40, w: 90, h: 600)
        let ui = b.n(.lifeline, "", 190, 40, w: 120, h: 600, props: ["classifier": "ShopUI"])
        let svc = b.n(.lifeline, "", 380, 40, w: 130, h: 600, props: ["classifier": "OrderService"])
        let order = b.n(.lifeline, "order", 600, 200, w: 110, h: 440, props: ["classifier": "Order"])
        let gw = b.n(.lifeline, "", 760, 40, w: 150, h: 600, props: ["classifier": "PaymentGateway"])
        b.n(.fragment, "paid | payment failed", 290, 400, w: 450, h: 150, props: ["operator": "alt"])
        b.e(.message, cust, ui, "checkout()", y: 140)
        b.e(.message, ui, svc, "placeOrder(cart)", y: 180)
        b.e(.create, svc, order, "new Order(cart)", y: 220)
        b.e(.message, svc, svc, "validate(cart)", y: 270)
        b.e(.message, svc, gw, "charge(total)", y: 330)
        b.e(.reply, gw, svc, "ok", y: 370)
        b.e(.message, svc, order, "markPaid()", y: 440)
        b.e(.asyncMessage, svc, ui, "showError()", y: 525)
        b.e(.reply, svc, ui, "confirmation", y: 570)
        b.e(.reply, ui, cust, "receipt", y: 605)
        return b.d
    }

    static func processOrder() -> Diagram {
        let b = DB("Process Order", .activity, doc: "Swimlanes show who does each step. A decision is an if/else, fork and join run steps at the same time.")
        b.n(.lane, "Customer", 40, 40, w: 220, h: 680)
        b.n(.lane, "Shop", 260, 40, w: 260, h: 680)
        b.n(.lane, "Warehouse", 520, 40, w: 240, h: 680)
        let start = b.n(.initial, "", 137, 90)
        let place = b.n(.action, "Place order", 80, 140)
        let check = b.n(.action, "Check stock", 320, 140)
        let dec = b.n(.decision, "", 368, 232)
        let notify = b.n(.action, "Notify customer", 80, 303)
        let ff = b.n(.flowFinal, "", 136, 420)
        let fork = b.n(.fork, "", 330, 336, w: 370, h: 8)
        let charge = b.n(.action, "Charge card", 320, 400)
        let pack = b.n(.action, "Pack items", 570, 400)
        let join = b.n(.fork, "", 330, 506, w: 370, h: 8)
        let ship = b.n(.action, "Ship order", 570, 560)
        let end = b.n(.final, "", 625, 650)
        b.e(.controlFlow, start, place)
        b.e(.controlFlow, place, check)
        b.e(.controlFlow, check, dec)
        b.e(.controlFlow, dec, fork, "[in stock]")
        b.e(.controlFlow, dec, notify, "[out of stock]")
        b.e(.controlFlow, notify, ff)
        b.e(.controlFlow, fork, charge)
        b.e(.controlFlow, fork, pack)
        b.e(.controlFlow, charge, join)
        b.e(.controlFlow, pack, join)
        b.e(.controlFlow, join, ship)
        b.e(.controlFlow, ship, end)
        return b.d
    }

    static func orderStates() -> Diagram {
        let b = DB("Order Lifecycle", .stateMachine, doc: "In Java a state machine is often an enum field plus a switch on events.")
        let start = b.n(.initial, "", 60, 161)
        let new = b.n(.state, "New", 130, 143)
        let paid = b.n(.state, "Paid", 380, 135, w: 170, h: 78, props: ["entry": "sendReceipt()"])
        let shipped = b.n(.state, "Shipped", 640, 135, w: 170, h: 78, props: ["do": "trackParcel()"])
        let delivered = b.n(.state, "Delivered", 655, 320)
        let cancelled = b.n(.state, "Cancelled", 130, 320)
        let end1 = b.n(.final, "", 710, 460)
        let end2 = b.n(.final, "", 185, 460)
        b.e(.transition, start, new)
        b.e(.transition, new, paid, "pay / chargeCard()")
        b.e(.transition, paid, shipped, "ship")
        b.e(.transition, shipped, delivered, "deliver")
        b.e(.transition, new, cancelled, "cancel")
        b.e(.transition, paid, cancelled, "cancel [refund ok]")
        b.e(.transition, delivered, end1)
        b.e(.transition, cancelled, end2)
        return b.d
    }

    static func components() -> Diagram {
        let b = DB("Web Shop Components", .component)
        let ui = b.n(.component, "Web UI", 40, 80)
        let api = b.n(.provided, "OrderAPI", 300, 109)
        let orders = b.n(.component, "Order Service", 400, 80)
        let pay = b.n(.component, "Payment Service", 400, 300)
        let data = b.n(.component, "Data Access", 740, 80)
        let gw = b.n(.interface, "PaymentGateway", 740, 300, o: ["+ charge(amount: double) : boolean"])
        let jar = b.n(.artifact, "shop.jar", 40, 300)
        b.e(.realization, orders, api)
        b.e(.dependency, ui, api)
        b.e(.dependency, orders, data, "«use»")
        b.e(.dependency, orders, pay)
        b.e(.dependency, pay, gw)
        b.e(.dependency, jar, ui, "«manifest»")
        return b.d
    }

    static func deployment() -> Diagram {
        let b = DB("Deployment", .deployment)
        let pc = b.n(.device, "Customer PC", 40, 80, w: 210, h: 150)
        b.n(.execEnv, "Web Browser", 60, 140, w: 160, h: 70)
        let web = b.n(.node3d, "Web Server", 340, 40, w: 290, h: 240)
        b.n(.execEnv, "JVM 21", 360, 100, w: 240, h: 160)
        b.n(.artifact, "shop.jar", 385, 160, w: 170, h: 70)
        let db = b.n(.node3d, "Database Server", 720, 60, w: 240, h: 200)
        b.n(.execEnv, "PostgreSQL 16", 740, 130, w: 190, h: 90)
        b.e(.association, pc, web, "HTTPS")
        b.e(.association, web, db, "JDBC")
        return b.d
    }

    static func packages() -> Diagram {
        let b = DB("Layers", .package, doc: "Each package becomes a Java package (a folder). Dependencies become import statements.")
        let ui = b.n(.package, "ui", 60, 60, w: 300, h: 170)
        b.n(.klass, "MainWindow", 110, 120, w: 140)
        let svc = b.n(.package, "service", 60, 300, w: 300, h: 170)
        b.n(.klass, "OrderService", 110, 360, w: 140)
        let model = b.n(.package, "model", 460, 300, w: 330, h: 170)
        b.n(.klass, "Order", 490, 360, w: 120)
        b.n(.klass, "Customer", 640, 360, w: 120)
        let db = b.n(.package, "persistence", 460, 60, w: 330, h: 170)
        b.n(.klass, "OrderRepository", 520, 120, w: 170)
        b.e(.importDep, ui, svc)
        b.e(.importDep, svc, model)
        b.e(.importDep, db, model)
        b.e(.dependency, svc, db)
        return b.d
    }

    static func objects() -> Diagram {
        let b = DB("Order Snapshot", .object, doc: "Objects are instances of classes: what exists in memory after new ...().")
        let alice = b.n(.object, "alice", 60, 60, a: ["name = \"Alice\"", "email = \"alice@mail.com\""], props: ["classifier": "Customer"])
        let o = b.n(.object, "order42", 380, 60, a: ["id = 42", "status = PAID"], props: ["classifier": "Order"])
        let l1 = b.n(.object, "line1", 300, 260, a: ["quantity = 2"], props: ["classifier": "OrderLine"])
        let l2 = b.n(.object, "line2", 520, 260, a: ["quantity = 1"], props: ["classifier": "OrderLine"])
        let book = b.n(.object, "book", 280, 430, a: ["name = \"Java Book\"", "price = 39.95"], props: ["classifier": "Product"])
        let pen = b.n(.object, "pen", 540, 430, a: ["name = \"Pen\"", "price = 2.50"], props: ["classifier": "Product"])
        b.e(.association, alice, o)
        b.e(.association, o, l1)
        b.e(.association, o, l2)
        b.e(.association, l1, book)
        b.e(.association, l2, pen)
        return b.d
    }

    static func shopDatabase() -> Diagram {
        let b = DB("Shop Database", .erd, doc: "Tables, keys and relationships. Try Tools ▸ Generate SQL, or the JPA tab for Java entity classes.")
        let customer = b.n(.entity, "customer", 40, 60, a: ["PK id : INTEGER", "name : VARCHAR(100) NN", "email : VARCHAR(120) NN UQ"])
        let orders = b.n(.entity, "orders", 360, 60, a: ["PK id : INTEGER", "FK customer_id : INTEGER -> customer.id NN", "order_date : DATE NN", "status : VARCHAR(20)"])
        let line = b.n(.entity, "order_line", 360, 290, a: ["PK id : INTEGER", "FK order_id : INTEGER -> orders.id NN", "FK product_id : INTEGER -> product.id NN", "quantity : INTEGER NN"])
        let product = b.n(.entity, "product", 700, 290, a: ["PK id : INTEGER", "name : VARCHAR(100) NN", "price : DECIMAL(10,2) NN"])
        b.e(.relationship, customer, orders, fm: "1", tm: "0..*", r: .orthogonal)
        b.e(.relationship, orders, line, fm: "1", tm: "1..*", r: .orthogonal)
        b.e(.relationship, product, line, fm: "1", tm: "0..*", r: .orthogonal)
        return b.d
    }

    static func login() -> Diagram {
        let b = DB("Login", .flowchart)
        let start = b.n(.terminator, "Start", 170, 30)
        let input = b.n(.io, "Enter name and password", 135, 110, w: 200)
        let look = b.n(.process, "Look up user", 165, 210)
        let ok = b.n(.fDecision, "Password correct?", 155, 305, w: 160, h: 90)
        let dash = b.n(.process, "Open dashboard", 165, 440)
        let end = b.n(.terminator, "End", 170, 540)
        let err = b.n(.process, "Show error", 430, 320)
        b.e(.flow, start, input)
        b.e(.flow, input, look)
        b.e(.flow, look, ok)
        b.e(.flow, ok, dash, "yes")
        b.e(.flow, ok, err, "no")
        b.e(.flow, err, input, via: [CGPoint(x: 500, y: 140)])
        b.e(.flow, dash, end)
        return b.d
    }

    static func fulfilment() -> Diagram {
        let b = DB("Order Fulfilment", .bpmn)
        let shop = b.n(.pool, "Shop", 40, 40, w: 900, h: 330)
        _ = shop
        b.n(.lane, "Sales", 70, 40, w: 870, h: 160)
        b.n(.lane, "Warehouse", 70, 200, w: 870, h: 170)
        let cust = b.n(.pool, "Customer", 40, 420, w: 900, h: 110)
        let start = b.n(.startEvent, "Order received", 110, 102, props: ["trigger": "message"])
        let check = b.n(.task, "Check order", 190, 85, w: 120, h: 70)
        let gw = b.n(.xorGateway, "Valid?", 360, 97)
        let reject = b.n(.task, "Reject order", 460, 85, w: 120, h: 70)
        let endR = b.n(.endEvent, "Rejected", 650, 102)
        let pack = b.n(.task, "Pack goods", 460, 250, w: 120, h: 70)
        let ship = b.n(.task, "Ship goods", 630, 250, w: 120, h: 70)
        let endS = b.n(.endEvent, "Shipped", 810, 267)
        b.e(.sequenceFlow, start, check)
        b.e(.sequenceFlow, check, gw)
        b.e(.sequenceFlow, gw, reject, "no")
        b.e(.sequenceFlow, reject, endR)
        b.e(.sequenceFlow, gw, pack, "yes")
        b.e(.sequenceFlow, pack, ship)
        b.e(.sequenceFlow, ship, endS)
        b.e(.messageFlow, ship, cust, "parcel")
        return b.d
    }

    static func learningJava() -> Diagram {
        let b = DB("Learning Java", .mindMap)
        let c = b.n(.central, "Learning Java", 420, 280)
        func branch(_ name: String, _ right: Bool, _ kids: [String]) {
            let t = b.n(.topic, name, right ? 700 : 200, 100, w: 120)
            b.e(.branch, c, t)
            for k in kids {
                let s = b.n(.topic, k, right ? 900 : 20, 100, w: 130)
                b.e(.branch, t, s)
            }
        }
        branch("Basics", true, ["Variables & types", "if / else & loops", "Methods"])
        branch("Objects", true, ["Classes", "Inheritance", "Interfaces"])
        branch("Tools", false, ["JDK", "IntelliJ IDEA", "Maven / Gradle"])
        branch("Practice", false, ["Small exercises", "A real project", "Read others' code"])
        Layout.mind(&b.d)
        return b.d
    }

    static func dataFlow() -> Diagram {
        let b = DB("Online Ordering (level 0)", .dfd)
        let cust = b.n(.external, "Customer", 40, 150)
        let proc = b.n(.dfdProcess, "1.0 Process Order", 320, 120, w: 130, h: 130)
        let ship = b.n(.dfdProcess, "2.0 Ship Order", 620, 120, w: 130, h: 130)
        let orders = b.n(.dfdStore, "D1 Orders", 470, 360, w: 170)
        let products = b.n(.dfdStore, "D2 Products", 120, 360, w: 170)
        let wh = b.n(.external, "Warehouse", 880, 154)
        b.e(.dataFlow, cust, proc, "order details")
        b.e(.dataFlow, proc, cust, "confirmation", via: [CGPoint(x: 250, y: 290)])
        b.e(.dataFlow, products, proc, "prices")
        b.e(.dataFlow, proc, orders, "new order")
        b.e(.dataFlow, orders, ship, "order")
        b.e(.dataFlow, ship, wh, "picking list")
        return b.d
    }

    /// a starter project with a few of the examples
    static func starterProject() -> Project {
        var p = Project(name: "Shop Example")
        p.diagrams = [shopClasses(), atm(), placeOrder(), shopDatabase()]
        return p
    }
}
